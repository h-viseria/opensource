use tauri::{AppHandle, Emitter, Manager, State};

use crate::ai::{self, ChatTurn, GenerateResult};
use crate::browser::{
    self, ActionResult, BrowserState, InspectResult, PageInfo, ScreenshotResult, ScrollDirection,
};
use crate::models::{self, ModelProgress, ModelSelectResponse, ModelsListResponse};
use crate::research::{self, OmniboxDecision};
use crate::saved::{self, SavedPage};
use crate::settings::AppSettings;
use crate::state::{AgentLimits, AppState, PendingNav};
use crate::blocklist::{self, BlocklistStatus};
use crate::visit_history::{self, VisitEntry};
use crate::download_log::{self, DownloadEntry};

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LayoutSync {
    pub toolbar_height: f64,
    pub sidebar_width: f64,
    pub sidebar_open: bool,
}

#[derive(Debug, Clone, serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CleanViewState {
    pub active: bool,
}

#[derive(Debug, Clone, serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AdBlockStatusResponse {
    pub enabled: bool,
    pub rule_hosts: u32,
    pub updated_at: u64,
    pub sources: Vec<String>,
}

fn with_browser(
    app: &AppHandle,
    state: &AppState,
    op: impl FnOnce(&tauri::Webview) -> Result<(), String>,
) -> Result<BrowserState, String> {
    let browser = state
        .browser(app)?
        .ok_or_else(|| "Browser view is not ready".to_string())?;
    op(&browser)?;
    let snapshot = state.snapshot(&browser);
    browser::emit_state(app, &snapshot);
    Ok(snapshot)
}

#[tauri::command]
pub async fn browser_navigate(
    app: AppHandle,
    state: State<'_, AppState>,
    url: String,
) -> Result<BrowserState, String> {
    let parsed = browser::parse_navigate_input(&url, &state.settings().search)?;
    state.set_pending(PendingNav::New);
    with_browser(&app, &state, |webview| {
        webview.navigate(parsed.clone()).map_err(|err| err.to_string())
    })
}

#[tauri::command]
pub async fn browser_back(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<BrowserState, String> {
    state.set_pending(PendingNav::Back);
    with_browser(&app, &state, |webview| {
        webview
            .eval("window.history.back()")
            .map_err(|err| err.to_string())
    })
}

#[tauri::command]
pub async fn browser_forward(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<BrowserState, String> {
    state.set_pending(PendingNav::Forward);
    with_browser(&app, &state, |webview| {
        webview
            .eval("window.history.forward()")
            .map_err(|err| err.to_string())
    })
}

#[tauri::command]
pub async fn browser_reload(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<BrowserState, String> {
    state.set_pending(PendingNav::Reload);
    with_browser(&app, &state, |webview| {
        webview
            .eval("window.location.reload()")
            .map_err(|err| err.to_string())
    })
}

#[tauri::command]
pub async fn browser_state(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<BrowserState, String> {
    let browser = state
        .browser(&app)?
        .ok_or_else(|| "Browser view is not ready".to_string())?;
    Ok(state.snapshot(&browser))
}

#[tauri::command]
pub async fn layout_sync(
    app: AppHandle,
    state: State<'_, AppState>,
    layout: LayoutSync,
) -> Result<(), String> {
    state.set_layout(layout.toolbar_height, layout.sidebar_width, layout.sidebar_open);
    state.apply_layout(&app)
}

#[tauri::command]
pub async fn models_list(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<ModelsListResponse, String> {
    let dir = models::models_dir(&app)?;
    models::list_models(
        &app,
        &dir,
        state.selected_model(),
        state.loaded_model(),
    )
}

#[tauri::command]
pub async fn models_select(
    app: AppHandle,
    state: State<'_, AppState>,
    model_id: String,
) -> Result<ModelSelectResponse, String> {
    let spec = models::find(&app, &model_id)?;
    let dir = models::models_dir(&app)?;
    let downloaded = spec.is_downloaded(&dir);
    state.set_selected_model(Some(spec.id.clone()));
    Ok(ModelSelectResponse {
        selected_id: spec.id.clone(),
        needs_download: !downloaded,
        download_enabled: models::download_enabled(),
        message: if downloaded {
            format!(
                "{} is on this device. PicoSurf will load it next.",
                spec.display_name
            )
        } else {
            format!(
                "{} is {}. Confirm to download it over HTTPS and verify SHA-256.",
                spec.display_name,
                crate::platform::hardware::format_bytes(spec.size_bytes())
            )
        },
    })
}

fn emit_chrome<T: serde::Serialize + Clone>(app: &AppHandle, event: &str, payload: T) {
    if let Some(chrome) = app.get_webview("chrome") {
        let _ = chrome.emit(event, payload);
    }
}

#[tauri::command]
pub async fn models_download(
    app: AppHandle,
    state: State<'_, AppState>,
    model_id: String,
) -> Result<ModelsListResponse, String> {
    let spec = models::find(&app, &model_id)?;
    let dir = models::models_dir(&app)?;
    state.begin_download();
    let cancel = state.download_cancel();
    let app_progress = app.clone();
    let spec_download = spec.clone();
    let dir_download = dir.clone();
    tauri::async_runtime::spawn_blocking(move || {
        spec_download.download(&dir_download, &cancel, |received, total| {
            models::emit_progress(
                &app_progress,
                &ModelProgress {
                    model_id: spec_download.id.clone(),
                    phase: "download".into(),
                    received,
                    total,
                    message: format!("Downloading {}…", spec_download.display_name),
                },
            );
        })
    })
    .await
    .map_err(|err| err.to_string())??;
    emit_chrome(
        &app,
        "model-progress",
        ModelProgress {
            model_id: spec.id.clone(),
            phase: "verify".into(),
            received: spec.size_bytes(),
            total: spec.size_bytes(),
            message: "Verifying SHA-256…".into(),
        },
    );
    spec.verify_all(&dir)?;
    models_list(app, state).await
}

#[tauri::command]
pub async fn models_cancel(state: State<'_, AppState>) -> Result<(), String> {
    state.cancel_download();
    state.request_inference_stop();
    Ok(())
}

#[tauri::command]
pub async fn models_load(
    app: AppHandle,
    state: State<'_, AppState>,
    model_id: String,
) -> Result<ModelsListResponse, String> {
    let spec = models::find(&app, &model_id)?;
    let dir = models::models_dir(&app)?;
    let path = spec.verify_all(&dir)?;
    let total = spec.size_bytes();
    emit_chrome(
        &app,
        "model-progress",
        ModelProgress {
            model_id: spec.id.clone(),
            phase: "load".into(),
            received: 0,
            total,
            message: format!("Loading {} into memory… this can take a minute.", spec.display_name),
        },
    );
    state.begin_download();
    let cancel = state.download_cancel();
    let id = spec.id.clone();
    let app_handle = app.clone();
    tauri::async_runtime::spawn_blocking(move || {
        let managed = app_handle.state::<AppState>();
        let mut last_pct = -1i32;
        managed.with_engine(|engine| {
            engine.load_model(&id, &path, {
                let app_handle = app_handle.clone();
                let id = id.clone();
                move |progress| {
                    if cancel.load(std::sync::atomic::Ordering::Relaxed) {
                        return false;
                    }
                    let pct = (progress * 100.0).floor() as i32;
                    if pct != last_pct {
                        last_pct = pct;
                        let received = (progress as f64 * total as f64) as u64;
                        emit_chrome(
                            &app_handle,
                            "model-progress",
                            ModelProgress {
                                model_id: id.clone(),
                                phase: "load".into(),
                                received,
                                total,
                                message: format!("Loading into memory… {pct}%"),
                            },
                        );
                    }
                    true
                }
            })
        })?
    })
    .await
    .map_err(|err| err.to_string())??;
    emit_chrome(
        &app,
        "model-progress",
        ModelProgress {
            model_id: spec.id.clone(),
            phase: "load".into(),
            received: total,
            total,
            message: "Model is in memory.".into(),
        },
    );
    state.set_selected_model(Some(spec.id));
    models_list(app, state).await
}

#[tauri::command]
pub async fn models_unload(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<ModelsListResponse, String> {
    state.with_engine(|engine| engine.unload())?;
    models_list(app, state).await
}

#[tauri::command]
pub async fn ai_generate(
    app: AppHandle,
    state: State<'_, AppState>,
    messages: Vec<ChatTurn>,
    attach_page: Option<bool>,
) -> Result<GenerateResult, String> {
    if state.loaded_model().is_none() {
        return Err("Load a local model first.".into());
    }
    if crate::ai::agent::has_session()? {
        return Err("A page task is waiting. Confirm or stop it first.".into());
    }
    if state.is_generating() {
        return Err("The model is already generating.".into());
    }
    let page = if attach_page.unwrap_or(false) {
        emit_chrome(
            &app,
            "ai-status",
            serde_json::json!({
                "phase": "reading_page",
                "message": "Reading page…"
            }),
        );
        let webview = browser_view(&app, &state)?;
        Some(browser::read_page(&webview)?)
    } else {
        None
    };
    emit_chrome(
        &app,
        "ai-status",
        serde_json::json!({
            "phase": "generating",
            "message": if page.is_some() {
                "Answering from the current page…"
            } else {
                "Answering…"
            }
        }),
    );
    state.set_generating(true);
    let app_handle = app.clone();
    let result = tauri::async_runtime::spawn_blocking(move || {
        let managed = app_handle.state::<AppState>();
        managed.with_engine(|engine| {
            engine.generate(&messages, page.as_ref(), |token| {
                emit_chrome(
                    &app_handle,
                    "ai-token",
                    serde_json::json!({ "text": token }),
                );
            })
        })?
    })
    .await;
    state.set_generating(false);
    let result = result.map_err(|err| err.to_string())??;
    emit_chrome(
        &app,
        "ai-status",
        serde_json::json!({
            "phase": "done",
            "message": result.message.clone()
        }),
    );
    emit_chrome(&app, "ai-done", &result);
    Ok(result)
}

#[tauri::command]
pub async fn ai_task(
    app: AppHandle,
    state: State<'_, AppState>,
    goal: String,
) -> Result<ai::agent::AgentOutcome, String> {
    let goal = goal.trim().to_string();
    if goal.is_empty() {
        return Err("Type a task first.".into());
    }
    if goal.chars().count() > 4000 {
        return Err("That message is too long.".into());
    }
    if state.loaded_model().is_none() {
        return Err("Load a local model first.".into());
    }
    if state.is_generating() {
        return Err("The model is already generating.".into());
    }
    state.set_generating(true);
    let result = ai::agent::start(app, goal).await;
    state.set_generating(false);
    result
}

#[tauri::command]
pub async fn ai_confirm(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<ai::agent::AgentOutcome, String> {
    if state.loaded_model().is_none() {
        return Err("Load a local model first.".into());
    }
    if state.is_generating() {
        return Err("The model is already generating.".into());
    }
    state.set_generating(true);
    let result = ai::agent::confirm(app).await;
    state.set_generating(false);
    result
}

#[tauri::command]
pub async fn ai_stop(app: AppHandle, state: State<'_, AppState>) -> Result<(), String> {
    ai::agent::cancel(&app)?;
    state.request_inference_stop();
    state.set_generating(false);
    Ok(())
}

#[tauri::command]
pub fn agent_limits_get(state: State<'_, AppState>) -> Result<AgentLimits, String> {
    Ok(state.agent_limits())
}

#[tauri::command]
pub fn agent_limits_set(
    app: AppHandle,
    state: State<'_, AppState>,
    limits: AgentLimits,
) -> Result<AgentLimits, String> {
    let saved = state.set_agent_limits(limits);
    let _ = state.persist_settings(&app);
    Ok(saved)
}

#[tauri::command]
pub fn settings_get(state: State<'_, AppState>) -> Result<AppSettings, String> {
    Ok(state.settings())
}

#[tauri::command]
pub fn settings_set(
    app: AppHandle,
    state: State<'_, AppState>,
    settings: AppSettings,
) -> Result<AppSettings, String> {
    let saved = state.apply_settings(settings)?;
    state.persist_settings(&app)?;
    blocklist::refresh_flow_allowlist(&app);
    Ok(saved)
}

#[tauri::command]
pub fn omnibox_interpret(
    state: State<'_, AppState>,
    input: String,
) -> Result<OmniboxDecision, String> {
    let trimmed = input.trim().to_string();
    if trimmed.is_empty() {
        return Err("Enter an address or search".into());
    }
    Ok(research::interpret_omnibox(
        &trimmed,
        state.settings().ai_enabled,
        state.settings().assistant_mode,
    ))
}

#[tauri::command]
pub fn assistant_mode_get(state: State<'_, AppState>) -> Result<String, String> {
    Ok(state.settings().assistant_mode.id().to_string())
}

#[tauri::command]
pub fn assistant_mode_set(
    app: AppHandle,
    state: State<'_, AppState>,
    mode: String,
    custom_flow_id: Option<String>,
) -> Result<String, String> {
    let mut settings = state.settings();
    settings.assistant_mode = crate::settings::AssistantMode::from_id(&mode);
    settings.custom_flow_id = custom_flow_id
        .map(|id| id.trim().to_string())
        .filter(|id| !id.is_empty());
    if settings.assistant_mode.is_custom() && settings.custom_flow_id.is_none() {
        return Err("Pick a custom agent flow in DevTools.".into());
    }
    let saved = state.apply_settings(settings)?;
    state.persist_settings(&app)?;
    blocklist::refresh_flow_allowlist(&app);
    Ok(saved.assistant_mode.id().to_string())
}

#[tauri::command]
pub fn agent_flows_list(app: AppHandle) -> Result<Vec<crate::agent_flows::AgentFlowSummary>, String> {
    crate::agent_flows::list(&app)
}

#[tauri::command]
pub fn agent_flows_get(app: AppHandle, id: String) -> Result<Option<crate::agent_flows::AgentFlow>, String> {
    crate::agent_flows::get(&app, &id)
}

#[tauri::command]
pub fn agent_flows_save(app: AppHandle, flow: crate::agent_flows::AgentFlow) -> Result<crate::agent_flows::AgentFlow, String> {
    let saved = crate::agent_flows::upsert(&app, flow)?;
    blocklist::refresh_flow_allowlist(&app);
    Ok(saved)
}

#[tauri::command]
pub fn agent_flows_delete(app: AppHandle, id: String) -> Result<(), String> {
    crate::agent_flows::delete(&app, &id)?;
    blocklist::refresh_flow_allowlist(&app);
    Ok(())
}

#[tauri::command]
pub fn history_list(
    app: AppHandle,
    query: Option<String>,
    limit: Option<u32>,
) -> Result<Vec<VisitEntry>, String> {
    visit_history::list(
        &app,
        query.as_deref().unwrap_or(""),
        limit.unwrap_or(50).clamp(1, 100) as usize,
    )
}

#[tauri::command]
pub async fn history_clear(app: AppHandle) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || visit_history::clear(&app))
        .await
        .map_err(|err| err.to_string())?
}

#[tauri::command]
pub fn history_enabled_get(state: State<'_, AppState>) -> Result<bool, String> {
    Ok(state.settings().history_enabled)
}

#[tauri::command]
pub fn history_enabled_set(
    app: AppHandle,
    state: State<'_, AppState>,
    enabled: bool,
) -> Result<bool, String> {
    let mut settings = state.settings();
    settings.history_enabled = enabled;
    if !enabled {
        settings.ai_history_enabled = false;
    }
    let saved = state.apply_settings(settings)?;
    state.persist_settings(&app)?;
    Ok(saved.history_enabled)
}

#[tauri::command]
pub fn history_ai_enabled_get(state: State<'_, AppState>) -> Result<bool, String> {
    Ok(state.settings().ai_history_enabled)
}

#[tauri::command]
pub fn history_ai_enabled_set(
    app: AppHandle,
    state: State<'_, AppState>,
    enabled: bool,
) -> Result<bool, String> {
    let mut settings = state.settings();
    if enabled && !settings.history_enabled {
        return Err("Enable browsing history before allowing AI access.".into());
    }
    settings.ai_history_enabled = enabled;
    let saved = state.apply_settings(settings)?;
    state.persist_settings(&app)?;
    Ok(saved.ai_history_enabled)
}

#[tauri::command]
pub fn downloads_list(app: AppHandle, limit: Option<u32>) -> Result<Vec<DownloadEntry>, String> {
    download_log::list(&app, limit.unwrap_or(50).clamp(1, 100) as usize)
}

#[tauri::command]
pub async fn downloads_clear(app: AppHandle) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || download_log::clear(&app))
        .await
        .map_err(|err| err.to_string())?
}

#[tauri::command]
pub fn saved_list(app: AppHandle) -> Result<Vec<SavedPage>, String> {
    let path = saved::file_path(&app)?;
    Ok(saved::load(&path))
}

#[tauri::command]
pub fn saved_search(app: AppHandle, query: String) -> Result<Vec<SavedPage>, String> {
    let path = saved::file_path(&app)?;
    let pages = saved::load(&path);
    Ok(saved::search(&pages, &query))
}

#[tauri::command]
pub async fn save_with_ai(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<ai::agent::AgentOutcome, String> {
    if !state.settings().save_with_ai_enabled {
        return Err("Save with AI is turned off in settings.".into());
    }
    if state.loaded_model().is_none() {
        return Err("Load a local model first.".into());
    }
    if crate::ai::agent::has_session()? {
        return Err("A page task is waiting. Confirm or stop it first.".into());
    }
    if state.is_generating() {
        return Err("The model is already generating.".into());
    }
    state.set_generating(true);
    let result = ai::agent::start(app, "Save this page with AI".into()).await;
    state.set_generating(false);
    result
}

fn browser_view(app: &AppHandle, state: &AppState) -> Result<tauri::Webview, String> {
    state
        .browser(app)?
        .ok_or_else(|| "Browser view is not ready".to_string())
}

fn emit_clean_view(app: &AppHandle, active: bool) {
    if let Some(chrome) = app.get_webview("chrome") {
        let _ = chrome.emit(
            "clean-view-changed",
            CleanViewState { active },
        );
    }
}

pub fn stop_clean_view_session(app: &AppHandle, state: &AppState) {
    if let Ok(webview) = browser_view(app, state) {
        let _ = browser::clean_view_stop(&webview);
    }
    if state.clean_view_active() {
        state.set_clean_view_active(false);
        emit_clean_view(app, false);
    }
}

#[tauri::command]
pub fn clean_view_start(app: AppHandle, state: State<'_, AppState>) -> Result<CleanViewState, String> {
    let webview = browser_view(&app, &state)?;
    let active = browser::clean_view_start(&webview)?;
    state.set_clean_view_active(active);
    emit_clean_view(&app, active);
    Ok(CleanViewState { active })
}

#[tauri::command]
pub fn clean_view_stop(app: AppHandle, state: State<'_, AppState>) -> Result<CleanViewState, String> {
    stop_clean_view_session(&app, &state);
    Ok(CleanViewState { active: false })
}

#[tauri::command]
pub fn ad_block_status(app: AppHandle, state: State<'_, AppState>) -> Result<AdBlockStatusResponse, String> {
    let shared = blocklist::shared_state(&app);
    let status = shared.status();
    Ok(AdBlockStatusResponse {
        enabled: state.settings().ad_block_enabled,
        rule_hosts: status.rule_hosts,
        updated_at: status.updated_at,
        sources: status.sources,
    })
}

#[tauri::command]
pub async fn ad_block_refresh(app: AppHandle) -> Result<BlocklistStatus, String> {
    let shared = blocklist::shared_state(&app);
    tauri::async_runtime::spawn_blocking(move || blocklist::refresh_filters(&app, &shared))
        .await
        .map_err(|err| err.to_string())?
        .map(|meta| BlocklistStatus {
            rule_hosts: meta.rule_hosts,
            updated_at: meta.updated_at,
            sources: meta.sources,
        })
}

#[tauri::command]
pub fn clean_view_status(app: AppHandle, state: State<'_, AppState>) -> Result<CleanViewState, String> {
    let webview = browser_view(&app, &state)?;
    let active = browser::clean_view_status(&webview).unwrap_or(false);
    if active != state.clean_view_active() {
        state.set_clean_view_active(active);
        emit_clean_view(&app, active);
    }
    Ok(CleanViewState { active })
}

fn page_snapshot(state: &AppState) -> Result<PageInfo, String> {
    state.with_page(|page| browser::page_info(page))
}

#[tauri::command]
pub fn browser_inspect(app: AppHandle, state: State<'_, AppState>) -> Result<InspectResult, String> {
    let webview = browser_view(&app, &state)?;
    let draft = browser::collect_inspect(&webview)?;
    state.with_page(|page| browser::commit_inspect(page, draft))
}

#[tauri::command]
pub fn browser_page_info(state: State<'_, AppState>) -> Result<PageInfo, String> {
    page_snapshot(&state)
}

#[tauri::command]
pub fn browser_click(
    app: AppHandle,
    state: State<'_, AppState>,
    element_id: u32,
    generation: u64,
    confirmed: Option<bool>,
) -> Result<ActionResult, String> {
    let webview = browser_view(&app, &state)?;
    let record = state.with_page(|page| {
        browser::resolve_element(page, &webview, element_id, generation)
    })??;
    let page = page_snapshot(&state)?;
    browser::click(&webview, &record, confirmed.unwrap_or(false), page)
}

#[tauri::command]
pub fn browser_type(
    app: AppHandle,
    state: State<'_, AppState>,
    element_id: u32,
    generation: u64,
    text: String,
) -> Result<ActionResult, String> {
    let webview = browser_view(&app, &state)?;
    let record = state.with_page(|page| {
        browser::resolve_element(page, &webview, element_id, generation)
    })??;
    let page = page_snapshot(&state)?;
    browser::type_text(&webview, &record, &text, page)
}

#[tauri::command]
pub fn browser_scroll(
    app: AppHandle,
    state: State<'_, AppState>,
    direction: ScrollDirection,
) -> Result<ActionResult, String> {
    let webview = browser_view(&app, &state)?;
    let page = page_snapshot(&state)?;
    browser::scroll(&webview, direction, page)
}

#[tauri::command]
pub fn browser_screenshot(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<ScreenshotResult, String> {
    let webview = browser_view(&app, &state)?;
    browser::screenshot(&webview, false, None)
}
