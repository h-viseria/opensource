use serde_json::Value;
use tauri::{AppHandle, Manager};

use super::prompt;
use super::{ChatTurn, InferenceEngine};
use crate::security;
use crate::settings::AssistantMode;
use crate::state::AppState;

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct AgentTaskPlan {
    pub open_url: Option<String>,
    pub search_query: Option<String>,
    pub product_query: Option<String>,
    pub add_to_cart: bool,
    pub buy_now: bool,
    pub steps: Vec<String>,
    pub task_complete: bool,
    pub status_message: Option<String>,
}

impl AgentTaskPlan {
    pub fn from_heuristic(goal: &str) -> Self {
        let parsed = security::parse_task_plan(goal);
        Self {
            open_url: security::extract_open_target(goal),
            search_query: parsed.search_query,
            product_query: parsed.product_query,
            add_to_cart: parsed.add_to_cart,
            buy_now: parsed.buy_now,
            steps: Vec::new(),
            task_complete: false,
            status_message: None,
        }
    }

    pub fn guided_search_query(&self) -> Option<&str> {
        self.search_query.as_deref()
    }

    pub fn product_pick_query(&self) -> Option<&str> {
        self.product_query
            .as_deref()
            .or(self.search_query.as_deref())
    }

    pub fn needs_work_after_search(&self) -> bool {
        self.add_to_cart || self.buy_now || self.product_query.is_some()
    }
}

pub async fn prepare_task_plan(app: &AppHandle, goal: &str) -> Result<AgentTaskPlan, String> {
    let mode = app.state::<AppState>().settings().assistant_mode;
    if mode == AssistantMode::Agent {
        plan_with_ai(app, goal, prompt::AGENT_PLAN_PROMPT).await
    } else {
        Ok(AgentTaskPlan::from_heuristic(goal))
    }
}

async fn plan_with_ai(
    app: &AppHandle,
    goal: &str,
    system_prompt: &str,
) -> Result<AgentTaskPlan, String> {
    let fallback = AgentTaskPlan::from_heuristic(goal);
    let managed = app.state::<AppState>();
    if managed.loaded_model().is_none() {
        return Ok(fallback);
    }

    let turns = vec![ChatTurn {
        role: "user".into(),
        content: format!("USER TASK:\n{goal}\n\nReply with one JSON object."),
    }];
    let app_handle = app.clone();
    let prompt_owned = system_prompt.to_string();
    let generated = tauri::async_runtime::spawn_blocking(move || {
        let managed = app_handle.state::<AppState>();
        managed.with_engine(|engine: &mut InferenceEngine| {
            engine.generate_cfg(&turns, None, &prompt_owned, 240, 0.15, |_| {})
        })?
    })
    .await
    .map_err(|err| err.to_string())??;

    if generated.stopped {
        return Ok(fallback);
    }

    Ok(parse_plan_json(&generated.text, goal).unwrap_or(fallback))
}

pub fn parse_plan_json(raw: &str, goal: &str) -> Option<AgentTaskPlan> {
    let value = extract_json(raw)?;
    let mut plan = AgentTaskPlan::from_heuristic(goal);
    apply_plan_value(&value, &mut plan);
    Some(plan)
}

pub fn merge_plan_from_json(raw: &str, base: AgentTaskPlan) -> Option<AgentTaskPlan> {
    let value = extract_json(raw)?;
    let mut plan = base;
    apply_plan_value(&value, &mut plan);
    Some(plan)
}

fn apply_plan_value(value: &Value, plan: &mut AgentTaskPlan) {
    if let Some(steps) = value.get("steps").and_then(Value::as_array) {
        plan.steps = steps
            .iter()
            .filter_map(|item| item.as_str())
            .map(str::trim)
            .filter(|step| step.len() >= 3)
            .map(|step| step.chars().take(120).collect::<String>())
            .take(8)
            .collect();
    }

    apply_optional_url(value, "openUrl", &mut plan.open_url);
    apply_optional_text(value, "searchQuery", &mut plan.search_query, sanitize_search_query);
    apply_optional_text(value, "productQuery", &mut plan.product_query, |raw| {
        let trimmed = raw.trim();
        if trimmed.len() >= 2 {
            Some(trimmed.chars().take(120).collect())
        } else {
            None
        }
    });

    if let Some(flag) = value.get("addToCart").and_then(Value::as_bool) {
        plan.add_to_cart = flag;
    }
    if let Some(flag) = value.get("buyNow").and_then(Value::as_bool) {
        plan.buy_now = flag;
    }
    if let Some(flag) = value.get("taskComplete").and_then(Value::as_bool) {
        plan.task_complete = flag;
    }
    if let Some(msg) = value.get("statusMessage").and_then(Value::as_str) {
        let trimmed = msg.trim();
        if !trimmed.is_empty() && !trimmed.eq_ignore_ascii_case("null") {
            plan.status_message = Some(trimmed.chars().take(240).collect());
        }
    }

}

fn apply_optional_url(value: &Value, key: &str, target: &mut Option<String>) {
    let Some(raw) = value.get(key) else {
        return;
    };
    if raw.is_null() {
        *target = None;
        return;
    }
    let Some(text) = raw.as_str() else {
        return;
    };
    let trimmed = text.trim();
    if trimmed.is_empty() || trimmed.eq_ignore_ascii_case("null") {
        *target = None;
        return;
    }
    if let Ok(url) = security::normalize_navigation_url(trimmed) {
        *target = Some(url.to_string());
    }
}

fn apply_optional_text(
    value: &Value,
    key: &str,
    target: &mut Option<String>,
    sanitize: impl Fn(&str) -> Option<String>,
) {
    let Some(raw) = value.get(key) else {
        return;
    };
    if raw.is_null() {
        *target = None;
        return;
    }
    let Some(text) = raw.as_str() else {
        return;
    };
    let trimmed = text.trim();
    if trimmed.is_empty() || trimmed.eq_ignore_ascii_case("null") {
        *target = None;
        return;
    }
    if let Some(clean) = sanitize(trimmed) {
        *target = Some(clean);
    }
}

fn sanitize_search_query(raw: &str) -> Option<String> {
    let lower = raw.to_ascii_lowercase();
    if lower.contains("add to cart")
        || lower.contains("add to basket")
        || lower.contains("buy now")
        || security::parse_url_or_host(raw).ok().flatten().is_some()
    {
        return None;
    }
    security::extract_search_query(&format!("search for {raw}"))
        .or_else(|| {
            let trimmed = raw.trim();
            if trimmed.chars().count() >= 2 && trimmed.chars().count() <= 120 {
                Some(trimmed.to_string())
            } else {
                None
            }
        })
}

fn extract_json(raw: &str) -> Option<Value> {
    let trimmed = raw.trim();
    if let Ok(value) = serde_json::from_str::<Value>(trimmed) {
        return Some(value);
    }
    let start = trimmed.find('{')?;
    let end = trimmed.rfind('}')?;
    serde_json::from_str(&trimmed[start..=end]).ok()
}

pub fn page_matches_open_target(page_url: &str, open_url: &str) -> bool {
    let Ok(current) = url::Url::parse(page_url) else {
        return false;
    };
    let Ok(target) = url::Url::parse(open_url) else {
        return false;
    };
    let current_host = normalize_host(current.host_str().unwrap_or(""));
    let target_host = normalize_host(target.host_str().unwrap_or(""));
    if current_host.is_empty() || target_host.is_empty() {
        return false;
    }
    current_host == target_host
        || current_host.ends_with(&format!(".{target_host}"))
        || target_host.ends_with(&format!(".{current_host}"))
}

pub fn page_is_search_portal(page_url: &str) -> bool {
    let Ok(current) = url::Url::parse(page_url) else {
        return false;
    };
    let host = current.host_str().unwrap_or("");
    crate::search::is_trusted_search_host(host)
}

fn normalize_host(host: &str) -> String {
    host.trim()
        .trim_start_matches("www.")
        .to_ascii_lowercase()
}

pub fn should_skip_guided_search(page_url: &str, plan: &AgentTaskPlan) -> bool {
    if let Some(open) = plan.open_url.as_deref() {
        if !page_matches_open_target(page_url, open) {
            return true;
        }
    } else if page_is_search_portal(page_url) && plan.search_query.is_some() {
        return true;
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn host_match_ignores_www() {
        assert!(page_matches_open_target(
            "https://www.amazon.com/s?k=milk",
            "https://amazon.com/"
        ));
    }

    #[test]
    fn skip_guided_on_search_engine_when_plan_has_site() {
        let plan = AgentTaskPlan {
            open_url: Some("https://www.amazon.com/".into()),
            search_query: Some("milk".into()),
            ..Default::default()
        };
        assert!(should_skip_guided_search(
            "https://duckduckgo.com/?q=amazon",
            &plan,
        ));
    }

    #[test]
    fn merge_clears_search_when_null() {
        let base = AgentTaskPlan {
            search_query: Some("milk".into()),
            ..Default::default()
        };
        let merged = merge_plan_from_json(r#"{"searchQuery":null,"steps":["Pick product"]}"#, base)
            .unwrap();
        assert!(merged.search_query.is_none());
        assert_eq!(merged.steps.len(), 1);
    }
}
