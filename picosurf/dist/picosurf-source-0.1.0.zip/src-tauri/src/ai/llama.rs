use std::num::NonZeroU32;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, OnceLock};

use crate::ai::prompt;
use crate::browser::UntrustedPage;
use encoding_rs::UTF_8;
use llama_cpp_2::context::params::LlamaContextParams;
use llama_cpp_2::llama_backend::LlamaBackend;
use llama_cpp_2::llama_batch::LlamaBatch;
use llama_cpp_2::model::params::LlamaModelParams;
use llama_cpp_2::model::{AddBos, LlamaChatMessage, LlamaModel};
use llama_cpp_2::sampling::LlamaSampler;
use serde::{Deserialize, Serialize};

const MAX_NEW_TOKENS: i32 = 384;
const MAX_CTX: u32 = 4096;
const N_BATCH: usize = 512;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatTurn {
    pub role: String,
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GenerateResult {
    pub text: String,
    pub stopped: bool,
    pub message: String,
    pub used_page: bool,
    pub page_origin: String,
}

pub struct InferenceEngine {
    model_id: Option<String>,
    model: Option<LlamaModel>,
    stop: Arc<AtomicBool>,
}

impl InferenceEngine {
    pub fn new(stop: Arc<AtomicBool>) -> Self {
        Self {
            model_id: None,
            model: None,
            stop,
        }
    }
}

impl Default for InferenceEngine {
    fn default() -> Self {
        Self::new(Arc::new(AtomicBool::new(false)))
    }
}

fn backend() -> Result<&'static LlamaBackend, String> {
    static BACKEND: OnceLock<Result<LlamaBackend, String>> = OnceLock::new();
    match BACKEND.get_or_init(|| LlamaBackend::init().map_err(|err| err.to_string())) {
        Ok(backend) => Ok(backend),
        Err(err) => Err(err.clone()),
    }
}

impl InferenceEngine {
    pub fn is_loaded(&self) -> bool {
        self.model.is_some()
    }

    pub fn loaded_id(&self) -> Option<String> {
        self.model_id.clone()
    }

    pub fn model_info(&self) -> Option<(String, u64, u32)> {
        let id = self.model_id.clone()?;
        let model = self.model.as_ref()?;
        Some((id, model.n_params(), model.n_layer()))
    }

    pub fn request_stop(&self) {
        self.stop.store(true, Ordering::Relaxed);
    }

    pub fn stop_requested(&self) -> bool {
        self.stop.load(Ordering::Relaxed)
    }

    pub fn unload(&mut self) {
        self.model = None;
        self.model_id = None;
        self.stop.store(false, Ordering::Relaxed);
    }

    pub fn load_model(
        &mut self,
        id: &str,
        path: &Path,
        on_progress: impl FnMut(f32) -> bool + 'static,
    ) -> Result<(), String> {
        let backend = backend()?;
        let params = LlamaModelParams::default().with_progress_callback(on_progress);
        let model = LlamaModel::load_from_file(backend, path, &params).map_err(|err| {
            let text = err.to_string();
            if text.to_ascii_lowercase().contains("null") {
                "Model load was cancelled.".into()
            } else {
                format!("Could not load GGUF: {err}")
            }
        })?;
        self.model = Some(model);
        self.model_id = Some(id.to_string());
        self.stop.store(false, Ordering::Relaxed);
        Ok(())
    }

    pub fn generate(
        &mut self,
        turns: &[ChatTurn],
        page: Option<&UntrustedPage>,
        on_token: impl FnMut(&str),
    ) -> Result<GenerateResult, String> {
        self.generate_cfg(
            turns,
            page,
            prompt::SYSTEM_PROMPT,
            MAX_NEW_TOKENS,
            0.7,
            on_token,
        )
    }

    pub fn generate_cfg(
        &mut self,
        turns: &[ChatTurn],
        page: Option<&UntrustedPage>,
        system: &str,
        max_new_tokens: i32,
        temperature: f32,
        mut on_token: impl FnMut(&str),
    ) -> Result<GenerateResult, String> {
        let backend = backend()?;
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| "No model is loaded.".to_string())?;
        self.stop.store(false, Ordering::Relaxed);

        let mut page_owned = page.cloned();
        let (tokens, used_page) = loop {
            let composed = prompt::compose_turns(turns, page_owned.as_ref())?;
            let prompt_text = build_prompt(model, &composed, system)?;
            let tokens = model
                .str_to_token(&prompt_text, AddBos::Never)
                .map_err(|err| format!("Could not tokenize prompt: {err}"))?;
            if tokens.is_empty() {
                return Err("The prompt was empty after tokenization.".into());
            }
        if (tokens.len() as u32) + (max_new_tokens as u32) + 8 < MAX_CTX {
                break (tokens, page_owned.is_some());
            }
            match page_owned.as_mut() {
                Some(item) if item.text.len() >= 400 => {
                    let keep = item.text.len() / 2;
                    item.text.truncate(keep);
                }
                _ => {
                    return Err("That conversation is too long for this model context.".into());
                }
            }
        };

        let threads = std::thread::available_parallelism()
            .map(|value| value.get().min(4) as i32)
            .unwrap_or(2);
        let ctx_params = LlamaContextParams::default()
            .with_n_ctx(Some(NonZeroU32::new(MAX_CTX).unwrap()))
            .with_n_batch(N_BATCH as u32)
            .with_n_ubatch(N_BATCH as u32)
            .with_n_threads(threads)
            .with_n_threads_batch(threads);
        let mut ctx = model
            .new_context(backend, ctx_params)
            .map_err(|err| format!("Could not create inference context: {err}"))?;

        let mut batch = LlamaBatch::new(N_BATCH, 1);
        let last_index = tokens.len() - 1;
        let mut pos = 0i32;
        for chunk in tokens.chunks(N_BATCH) {
            batch.clear();
            for (offset, token) in chunk.iter().copied().enumerate() {
                let at = pos + offset as i32;
                batch
                    .add(token, at, &[0], at as usize == last_index)
                    .map_err(|err| {
                        format!(
                            "Could not decode the prompt ({err}). Try a shorter question or turn off Include current page."
                        )
                    })?;
            }
            ctx.decode(&mut batch)
                .map_err(|err| format!("Prompt decode failed: {err}"))?;
            pos += chunk.len() as i32;
            if self.stop.load(Ordering::Relaxed) {
                return Ok(GenerateResult {
                    text: String::new(),
                    stopped: true,
                    message: "Stopped.".into(),
                    used_page,
                    page_origin: String::new(),
                });
            }
        }

        let mut sampler = LlamaSampler::chain_simple([
            LlamaSampler::temp(temperature),
            LlamaSampler::top_p(0.9, 1),
            LlamaSampler::dist(1234),
        ]);
        let mut decoder = UTF_8.new_decoder();
        let mut n_cur = pos;
        let mut text = String::new();
        let mut generated = 0i32;
        let mut stopped = false;

        while generated < max_new_tokens {
            if self.stop.load(Ordering::Relaxed) {
                stopped = true;
                break;
            }
            let token = sampler.sample(&ctx, batch.n_tokens() - 1);
            sampler.accept(token);
            if model.is_eog_token(token) {
                break;
            }
            let piece = model
                .token_to_piece(token, &mut decoder, true, None)
                .unwrap_or_default();
            if !piece.is_empty() {
                text.push_str(&piece);
                on_token(&piece);
            }
            batch.clear();
            batch
                .add(token, n_cur, &[0], true)
                .map_err(|err| err.to_string())?;
            ctx.decode(&mut batch)
                .map_err(|err| format!("Decode failed: {err}"))?;
            n_cur += 1;
            generated += 1;
        }

        Ok(GenerateResult {
            stopped,
            message: if stopped {
                "Generation stopped.".into()
            } else {
                "Done.".into()
            },
            text,
            used_page,
            page_origin: page_owned
                .as_ref()
                .map(|item| item.origin.clone())
                .unwrap_or_default(),
        })
    }
}

fn build_prompt(model: &LlamaModel, turns: &[ChatTurn], system: &str) -> Result<String, String> {
    let mut messages = vec![LlamaChatMessage::new("system".into(), system.into())
        .map_err(|err| err.to_string())?];
    for turn in turns {
        let role = if turn.role == "assistant" {
            "assistant"
        } else {
            "user"
        };
        let content = turn.content.trim();
        if content.is_empty() {
            continue;
        }
        messages.push(
            LlamaChatMessage::new(role.into(), content.into()).map_err(|err| err.to_string())?,
        );
    }
    if messages.len() < 2 {
        return Err("Type a message first.".into());
    }
    if let Ok(template) = model.chat_template(None) {
        return model
            .apply_chat_template(&template, &messages, true)
            .map_err(|err| err.to_string());
    }
    Ok(fallback_chatml(turns, system))
}

fn fallback_chatml(turns: &[ChatTurn], system: &str) -> String {
    let mut out = String::from("<|im_start|>system\n");
    out.push_str(system);
    out.push_str("<|im_end|>\n");
    for turn in turns {
        let role = if turn.role == "assistant" {
            "assistant"
        } else {
            "user"
        };
        out.push_str("<|im_start|>");
        out.push_str(role);
        out.push('\n');
        out.push_str(turn.content.trim());
        out.push_str("<|im_end|>\n");
    }
    out.push_str("<|im_start|>assistant\n");
    out
}
