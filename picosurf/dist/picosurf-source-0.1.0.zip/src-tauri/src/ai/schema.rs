use serde_json::Value;

use crate::browser::WaitCondition;
use crate::browser::ScrollDirection;
use crate::security;

const FORBIDDEN_KEYS: &[&str] = &[
    "javascript",
    "js",
    "script",
    "code",
    "selector",
    "css",
    "xpath",
    "file",
    "path",
    "shell",
    "command",
    "eval",
    "innerhtml",
    "execute",
];

const ALLOWED_KEYS: &[&str] = &[
    "action",
    "url",
    "elementId",
    "element_id",
    "text",
    "direction",
    "message",
    "key",
    "option",
    "query",
    "x",
    "y",
    "condition",
    "value",
    "timeoutMs",
    "accept",
    "promptText",
    "fullPage",
];

const MAX_TYPE_CHARS: usize = 500;
const MAX_KEY_CHARS: usize = 40;
const MAX_QUERY_CHARS: usize = 120;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ProposedAction {
    Inspect,
    Navigate { url: String },
    Click { element_id: u32 },
    ClickAt { x: i32, y: i32 },
    Type { element_id: u32, text: String },
    Clear { element_id: u32 },
    Check { element_id: u32 },
    Uncheck { element_id: u32 },
    SelectOption { element_id: u32, option: String },
    PressKey { element_id: Option<u32>, key: String },
    Focus { element_id: u32 },
    Hover { element_id: u32 },
    Scroll { direction: ScrollDirection },
    WaitFor {
        condition: WaitCondition,
        value: String,
        timeout_ms: u64,
    },
    DomSearch { query: String },
    DomSnippet { element_id: u32 },
    Screenshot { full_page: bool },
    HandleDialog { accept: bool, prompt_text: Option<String> },
    Back,
    Forward,
    Reload,
    Done { message: String },
    Ask { message: String },
}

impl ProposedAction {
    pub fn kind(&self) -> &'static str {
        match self {
            Self::Inspect => "inspect",
            Self::Navigate { .. } => "navigate",
            Self::Click { .. } => "click",
            Self::ClickAt { .. } => "click_at",
            Self::Type { .. } => "type",
            Self::Clear { .. } => "clear",
            Self::Check { .. } => "check",
            Self::Uncheck { .. } => "uncheck",
            Self::SelectOption { .. } => "select_option",
            Self::PressKey { .. } => "press_key",
            Self::Focus { .. } => "focus",
            Self::Hover { .. } => "hover",
            Self::Scroll { .. } => "scroll",
            Self::WaitFor { .. } => "wait_for",
            Self::DomSearch { .. } => "dom_search",
            Self::DomSnippet { .. } => "dom_snippet",
            Self::Screenshot { .. } => "screenshot",
            Self::HandleDialog { .. } => "handle_dialog",
            Self::Back => "back",
            Self::Forward => "forward",
            Self::Reload => "reload",
            Self::Done { .. } => "done",
            Self::Ask { .. } => "ask",
        }
    }

    pub fn is_navigation(&self) -> bool {
        matches!(self, Self::Navigate { .. } | Self::Back | Self::Forward | Self::Reload)
    }

    pub fn should_settle(&self) -> bool {
        matches!(
            self,
            Self::Navigate { .. }
                | Self::Click { .. }
                | Self::ClickAt { .. }
                | Self::Type { .. }
                | Self::Clear { .. }
                | Self::Check { .. }
                | Self::Uncheck { .. }
                | Self::SelectOption { .. }
                | Self::PressKey { .. }
                | Self::Focus { .. }
                | Self::Hover { .. }
                | Self::Back
                | Self::Forward
                | Self::Reload
                | Self::HandleDialog { .. }
        )
    }

    pub fn summary(&self) -> String {
        match self {
            Self::Inspect => "Inspect the page".into(),
            Self::Navigate { url } => format!("Open {url}"),
            Self::Click { element_id } => format!("Click element #{element_id}"),
            Self::ClickAt { x, y } => format!("Click at ({x}, {y})"),
            Self::Type { element_id, text } => {
                format!("Type into #{element_id}: {}", clip(text, 40))
            }
            Self::Clear { element_id } => format!("Clear element #{element_id}"),
            Self::Check { element_id } => format!("Check element #{element_id}"),
            Self::Uncheck { element_id } => format!("Uncheck element #{element_id}"),
            Self::SelectOption { element_id, option } => {
                format!("Select '{option}' on #{element_id}")
            }
            Self::PressKey { element_id, key } => match element_id {
                Some(id) => format!("Press {key} on #{id}"),
                None => format!("Press {key}"),
            },
            Self::Focus { element_id } => format!("Focus element #{element_id}"),
            Self::Hover { element_id } => format!("Hover element #{element_id}"),
            Self::Scroll { direction } => format!("Scroll {direction:?}").to_lowercase(),
            Self::WaitFor { condition, value, .. } => {
                format!("Wait for {condition:?} '{value}'").to_lowercase()
            }
            Self::DomSearch { query } => format!("Search DOM for '{}'", clip(query, 40)),
            Self::DomSnippet { element_id } => format!("Read DOM snippet for #{element_id}"),
            Self::Screenshot { full_page } => {
                if *full_page {
                    "Capture full-page screenshot".into()
                } else {
                    "Capture viewport screenshot".into()
                }
            }
            Self::HandleDialog { accept, .. } => {
                if *accept {
                    "Accept script dialog".into()
                } else {
                    "Dismiss script dialog".into()
                }
            }
            Self::Back => "Go back".into(),
            Self::Forward => "Go forward".into(),
            Self::Reload => "Reload the page".into(),
            Self::Done { message } => message.clone(),
            Self::Ask { message } => message.clone(),
        }
    }
}

pub fn parse_action(raw: &str) -> Result<ProposedAction, String> {
    let value = extract_json_object(raw)?;
    let obj = value
        .as_object()
        .ok_or_else(|| "Model output was not a JSON object.".to_string())?;

    for key in obj.keys() {
        let lower = key.to_ascii_lowercase();
        if FORBIDDEN_KEYS.contains(&lower.as_str()) {
            return Err(format!("Rejected disallowed field '{key}'."));
        }
        if !ALLOWED_KEYS
            .iter()
            .any(|allowed| allowed.eq_ignore_ascii_case(key))
        {
            return Err(format!("Rejected unknown field '{key}'."));
        }
    }

    let action = obj
        .get("action")
        .and_then(Value::as_str)
        .ok_or_else(|| "Missing action field.".to_string())?
        .to_ascii_lowercase();

    match action.as_str() {
        "inspect" => Ok(ProposedAction::Inspect),
        "navigate" => {
            let raw_url = string_field(obj, "url")?;
            let url = security::normalize_navigation_url(&raw_url)?;
            Ok(ProposedAction::Navigate {
                url: url.to_string(),
            })
        }
        "click" => Ok(ProposedAction::Click {
            element_id: element_id(obj)?,
        }),
        "click_at" => Ok(ProposedAction::ClickAt {
            x: coord_field(obj, "x")?,
            y: coord_field(obj, "y")?,
        }),
        "type" => {
            let text = string_field(obj, "text")?;
            if text.chars().any(|ch| ch == '\0') {
                return Err("Typed text contained a forbidden character.".into());
            }
            if text.len() > MAX_TYPE_CHARS {
                return Err("Typed text is too long.".into());
            }
            Ok(ProposedAction::Type {
                element_id: element_id(obj)?,
                text,
            })
        }
        "clear" => Ok(ProposedAction::Clear {
            element_id: element_id(obj)?,
        }),
        "check" => Ok(ProposedAction::Check {
            element_id: element_id(obj)?,
        }),
        "uncheck" => Ok(ProposedAction::Uncheck {
            element_id: element_id(obj)?,
        }),
        "select_option" => Ok(ProposedAction::SelectOption {
            element_id: element_id(obj)?,
            option: string_field(obj, "option")?,
        }),
        "press_key" => {
            let key = string_field(obj, "key")?;
            validate_key(&key)?;
            Ok(ProposedAction::PressKey {
                element_id: optional_element_id(obj)?,
                key,
            })
        }
        "focus" => Ok(ProposedAction::Focus {
            element_id: element_id(obj)?,
        }),
        "hover" => Ok(ProposedAction::Hover {
            element_id: element_id(obj)?,
        }),
        "scroll" => {
            let direction = string_field(obj, "direction")?.to_ascii_lowercase();
            let direction = match direction.as_str() {
                "up" => ScrollDirection::Up,
                "down" => ScrollDirection::Down,
                "left" => ScrollDirection::Left,
                "right" => ScrollDirection::Right,
                "top" => ScrollDirection::Top,
                "bottom" => ScrollDirection::Bottom,
                _ => return Err("Unknown scroll direction.".into()),
            };
            Ok(ProposedAction::Scroll { direction })
        }
        "wait_for" => {
            let condition = parse_wait_condition(&string_field(obj, "condition")?)?;
            let value = match condition {
                WaitCondition::Ready => string_field(obj, "value").unwrap_or_else(|_| "complete".into()),
                _ => string_field(obj, "value")?,
            };
            Ok(ProposedAction::WaitFor {
                condition,
                value,
                timeout_ms: timeout_field(obj),
            })
        }
        "dom_search" => {
            let query = string_field(obj, "query")?;
            if query.len() > MAX_QUERY_CHARS {
                return Err("DOM search query is too long.".into());
            }
            Ok(ProposedAction::DomSearch { query })
        }
        "dom_snippet" => Ok(ProposedAction::DomSnippet {
            element_id: element_id(obj)?,
        }),
        "screenshot" => Ok(ProposedAction::Screenshot {
            full_page: bool_field(obj, "fullPage").unwrap_or(false),
        }),
        "handle_dialog" => Ok(ProposedAction::HandleDialog {
            accept: bool_field(obj, "accept").unwrap_or(true),
            prompt_text: optional_string_field(obj, "promptText"),
        }),
        "back" => Ok(ProposedAction::Back),
        "forward" => Ok(ProposedAction::Forward),
        "reload" => Ok(ProposedAction::Reload),
        "done" => Ok(ProposedAction::Done {
            message: string_field(obj, "message").unwrap_or_else(|_| "Done.".into()),
        }),
        "ask" => Ok(ProposedAction::Ask {
            message: string_field(obj, "message")
                .unwrap_or_else(|_| "Need a bit more detail.".into()),
        }),
        other => Err(format!("Unknown action '{other}'.")),
    }
}

fn parse_wait_condition(raw: &str) -> Result<WaitCondition, String> {
    match raw.to_ascii_lowercase().as_str() {
        "url_contains" | "url" => Ok(WaitCondition::UrlContains),
        "title_contains" | "title" => Ok(WaitCondition::TitleContains),
        "ready" | "load" => Ok(WaitCondition::Ready),
        "element" | "element_visible" => Ok(WaitCondition::ElementVisible),
        other => Err(format!("Unknown wait condition '{other}'.")),
    }
}

fn validate_key(key: &str) -> Result<(), String> {
    if key.is_empty() || key.len() > MAX_KEY_CHARS {
        return Err("Key name is invalid.".into());
    }
    if !key
        .chars()
        .all(|ch| ch.is_ascii_alphanumeric() || "+-".contains(ch))
    {
        return Err("Key name contains unsupported characters.".into());
    }
    Ok(())
}

fn element_id(obj: &serde_json::Map<String, Value>) -> Result<u32, String> {
    obj.get("elementId")
        .or_else(|| obj.get("element_id"))
        .and_then(Value::as_u64)
        .filter(|id| *id > 0 && *id <= u32::MAX as u64)
        .map(|id| id as u32)
        .ok_or_else(|| "elementId must be a positive integer.".into())
}

fn optional_element_id(obj: &serde_json::Map<String, Value>) -> Result<Option<u32>, String> {
    if obj.get("elementId").is_none() && obj.get("element_id").is_none() {
        return Ok(None);
    }
    Ok(Some(element_id(obj)?))
}

fn coord_field(obj: &serde_json::Map<String, Value>, key: &str) -> Result<i32, String> {
    let value = obj
        .get(key)
        .and_then(Value::as_i64)
        .ok_or_else(|| format!("Missing {key}."))?;
    if !(0..=16_000).contains(&value) {
        return Err(format!("{key} is out of range."));
    }
    Ok(value as i32)
}

fn timeout_field(obj: &serde_json::Map<String, Value>) -> u64 {
    obj.get("timeoutMs")
        .and_then(Value::as_u64)
        .unwrap_or(5_000)
        .clamp(500, 30_000)
}

fn bool_field(obj: &serde_json::Map<String, Value>, key: &str) -> Option<bool> {
    obj.get(key).and_then(Value::as_bool)
}

fn string_field(obj: &serde_json::Map<String, Value>, key: &str) -> Result<String, String> {
    obj.get(key)
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_string)
        .ok_or_else(|| format!("Missing {key}."))
}

fn optional_string_field(obj: &serde_json::Map<String, Value>, key: &str) -> Option<String> {
    obj.get(key)
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_string)
}

fn extract_json_object(raw: &str) -> Result<Value, String> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Err("Model output was empty.".into());
    }
    if let Ok(value) = serde_json::from_str::<Value>(trimmed) {
        return Ok(value);
    }
    let start = trimmed.find('{').ok_or_else(|| "No JSON object in model output.".to_string())?;
    let end = trimmed
        .rfind('}')
        .ok_or_else(|| "No JSON object in model output.".to_string())?;
    if end <= start {
        return Err("Malformed JSON object.".into());
    }
    serde_json::from_str(&trimmed[start..=end]).map_err(|_| "Malformed JSON object.".into())
}

fn clip(text: &str, max: usize) -> String {
    let mut out = String::new();
    for ch in text.chars() {
        if out.len() + ch.len_utf8() > max {
            out.push('…');
            break;
        }
        out.push(ch);
    }
    out
}

pub fn needs_navigation_confirm(url: &str) -> bool {
    let lower = url.to_ascii_lowercase();
    ["login", "signin", "sign-in", "checkout", "payment", "password", "account/security"]
        .iter()
        .any(|needle| lower.contains(needle))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_click() {
        let action = parse_action(r#"{"action":"click","elementId":3}"#).unwrap();
        assert_eq!(action, ProposedAction::Click { element_id: 3 });
    }

    #[test]
    fn parses_press_key() {
        let action = parse_action(r#"{"action":"press_key","key":"Enter","elementId":2}"#).unwrap();
        assert_eq!(
            action,
            ProposedAction::PressKey {
                element_id: Some(2),
                key: "Enter".into()
            }
        );
    }

    #[test]
    fn parses_wait_for() {
        let action =
            parse_action(r#"{"action":"wait_for","condition":"url_contains","value":"example.com"}"#)
                .unwrap();
        assert!(matches!(
            action,
            ProposedAction::WaitFor {
                condition: WaitCondition::UrlContains,
                ..
            }
        ));
    }

    #[test]
    fn rejects_javascript_field() {
        assert!(parse_action(r#"{"action":"click","elementId":1,"javascript":"alert(1)"}"#).is_err());
    }

    #[test]
    fn rejects_unknown_action() {
        assert!(parse_action(r#"{"action":"execute_javascript","code":"1"}"#).is_err());
    }
}
