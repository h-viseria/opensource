mod llama;
pub(crate) mod prompt;
mod schema;
pub mod agent;

pub use llama::{ChatTurn, GenerateResult, InferenceEngine};

pub const PHASE: &str = "phase6-research";
