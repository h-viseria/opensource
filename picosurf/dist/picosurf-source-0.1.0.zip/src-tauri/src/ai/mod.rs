mod llama;
pub(crate) mod prompt;
mod schema;
pub mod agent;
pub(crate) mod task_plan;

pub use llama::{ChatTurn, GenerateResult, InferenceEngine};

pub const PHASE: &str = "phase6-research";
