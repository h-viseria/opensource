use serde_json::{json, Value};
use tauri::Webview;

use super::actions::{ActionResult, ElementRecord, PageInfo};
use super::eval::{eval_json, eval_json_cancel};

const DOM_SEARCH_JS: &str = include_str!("dom.js");
const SNIPPET_JS: &str = include_str!("snippet.js");

fn inject_payload(template: &str, payload: Value) -> String {
    template.replace("__PAYLOAD_JSON__", &payload.to_string())
}

pub(crate) fn clear_field(
    webview: &Webview,
    record: &ElementRecord,
    page: PageInfo,
) -> Result<ActionResult, String> {
    run_path_action(
        webview,
        record,
        json!({ "mode": "clear" }),
        "Cleared the field.",
        page,
    )
}

pub(crate) fn set_checked(
    webview: &Webview,
    record: &ElementRecord,
    checked: bool,
    page: PageInfo,
) -> Result<ActionResult, String> {
    let msg = if checked {
        "Checked the control."
    } else {
        "Unchecked the control."
    };
    run_path_action(
        webview,
        record,
        json!({ "mode": "check", "checked": checked }),
        msg,
        page,
    )
}

pub(crate) fn select_option(
    webview: &Webview,
    record: &ElementRecord,
    option: &str,
    page: PageInfo,
) -> Result<ActionResult, String> {
    run_path_action(
        webview,
        record,
        json!({ "mode": "select", "option": option }),
        "Selected the option.",
        page,
    )
}

pub(crate) fn focus_element(
    webview: &Webview,
    record: &ElementRecord,
    page: PageInfo,
) -> Result<ActionResult, String> {
    run_path_action(
        webview,
        record,
        json!({ "mode": "focus" }),
        "Focused the element.",
        page,
    )
}

pub(crate) fn hover_element(
    webview: &Webview,
    record: &ElementRecord,
    page: PageInfo,
) -> Result<ActionResult, String> {
    run_path_action(
        webview,
        record,
        json!({ "mode": "hover" }),
        "Hovered the element.",
        page,
    )
}

pub(crate) fn click_at(
    webview: &Webview,
    x: i32,
    y: i32,
    page: PageInfo,
) -> Result<ActionResult, String> {
    if !(0..=16_000).contains(&x) || !(0..=16_000).contains(&y) {
        return Err("Coordinates out of range.".into());
    }
    let script = format!(
        r#"(function(){{
          try {{
            const x = {x};
            const y = {y};
            const el = document.elementFromPoint(x, y);
            if (!el) return {{ ok: false, error: "No element at that point." }};
            el.scrollIntoView({{ block: "center", inline: "nearest" }});
            const target = document.elementFromPoint(x, y) || el;
            target.dispatchEvent(new MouseEvent("mouseover", {{ bubbles: true }}));
            target.dispatchEvent(new MouseEvent("mousedown", {{ bubbles: true, clientX: x, clientY: y }}));
            target.dispatchEvent(new MouseEvent("mouseup", {{ bubbles: true, clientX: x, clientY: y }}));
            target.click();
            return {{ ok: true }};
          }} catch (err) {{
            return {{ ok: false, error: String((err && err.message) || err) }};
          }}
        }})()"#
    );
    eval_json(webview, &script)?;
    Ok(ActionResult {
        executed: true,
        needs_confirmation: false,
        message: format!("Clicked at ({x}, {y})."),
        page,
    })
}

pub(crate) fn press_key(
    webview: &Webview,
    record: Option<&ElementRecord>,
    key: &str,
    page: PageInfo,
) -> Result<ActionResult, String> {
    let path = record.map(|item| json!(item.path));
    let script = format!(
        r#"(function(){{
          const payload = {payload};
          function atPath(path) {{
            let el = document.documentElement;
            for (const index of path) {{
              el = el.children[index];
              if (!el) return null;
            }}
            return el;
          }}
          function parseKey(name) {{
            const parts = String(name).split("+").map((p) => p.trim()).filter(Boolean);
            const keyPart = parts.pop() || "";
            const mods = {{ ctrl: false, alt: false, shift: false, meta: false }};
            for (const p of parts) {{
              const lower = p.toLowerCase();
              if (lower === "control" || lower === "ctrl") mods.ctrl = true;
              else if (lower === "alt") mods.alt = true;
              else if (lower === "shift") mods.shift = true;
              else if (lower === "meta" || lower === "win") mods.meta = true;
            }}
            const map = {{
              enter: {{ key: "Enter", code: "Enter", keyCode: 13 }},
              tab: {{ key: "Tab", code: "Tab", keyCode: 9 }},
              escape: {{ key: "Escape", code: "Escape", keyCode: 27 }},
              esc: {{ key: "Escape", code: "Escape", keyCode: 27 }},
              backspace: {{ key: "Backspace", code: "Backspace", keyCode: 8 }},
              delete: {{ key: "Delete", code: "Delete", keyCode: 46 }},
              space: {{ key: " ", code: "Space", keyCode: 32 }},
              arrowup: {{ key: "ArrowUp", code: "ArrowUp", keyCode: 38 }},
              arrowdown: {{ key: "ArrowDown", code: "ArrowDown", keyCode: 40 }},
              arrowleft: {{ key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 }},
              arrowright: {{ key: "ArrowRight", code: "ArrowRight", keyCode: 39 }},
              home: {{ key: "Home", code: "Home", keyCode: 36 }},
              end: {{ key: "End", code: "End", keyCode: 46 }},
            }};
            const lower = keyPart.toLowerCase();
            const base = map[lower] || {{ key: keyPart, code: keyPart, keyCode: keyPart.length ? keyPart.charCodeAt(0) : 0 }};
            return {{ ...base, ctrlKey: mods.ctrl, altKey: mods.alt, shiftKey: mods.shift, metaKey: mods.meta, bubbles: true, cancelable: true }};
          }}
          try {{
            let el = document.activeElement || document.body;
            if (payload.path) {{
              const found = atPath(payload.path);
              if (found) {{
                el = found;
                el.scrollIntoView({{ block: "center", inline: "nearest" }});
                if (typeof el.focus === "function") el.focus();
              }}
            }}
            const init = parseKey(payload.key);
            el.dispatchEvent(new KeyboardEvent("keydown", init));
            el.dispatchEvent(new KeyboardEvent("keyup", init));
            return {{ ok: true }};
          }} catch (err) {{
            return {{ ok: false, error: String((err && err.message) || err) }};
          }}
        }})()"#,
        payload = json!({ "path": path, "key": key })
    );
    eval_json(webview, &script)?;
    Ok(ActionResult {
        executed: true,
        needs_confirmation: false,
        message: format!("Pressed {key}."),
        page,
    })
}

pub(crate) fn dom_search(webview: &Webview, query: &str) -> Result<String, String> {
    if query.trim().is_empty() || query.len() > 120 {
        return Err("Search query must be 1-120 characters.".into());
    }
    let script = inject_payload(DOM_SEARCH_JS, json!({ "query": query.trim() }));
    let value = eval_json(webview, &script)?;
    let hits = value
        .get("hits")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();
    if hits.is_empty() {
        return Ok("No DOM matches for that query.".into());
    }
    let mut out = String::from("DOM search matches (untrusted page data):\n");
    for (index, hit) in hits.iter().take(10).enumerate() {
        let kind = hit
            .get("kind")
            .and_then(Value::as_str)
            .unwrap_or("node");
        let preview = hit
            .get("preview")
            .and_then(Value::as_str)
            .unwrap_or("");
        out.push_str(&format!("[D{}] {kind}: {preview}\n", index + 1));
    }
    Ok(out.trim().to_string())
}

pub(crate) fn dom_snippet(
    webview: &Webview,
    record: &ElementRecord,
) -> Result<String, String> {
    let script = inject_payload(SNIPPET_JS, json!({ "path": record.path }));
    let value = eval_json(webview, &script)?;
    let tag = value.get("tag").and_then(Value::as_str).unwrap_or("");
    let text = value.get("text").and_then(Value::as_str).unwrap_or("");
    let html = value.get("html").and_then(Value::as_str).unwrap_or("");
    Ok(format!(
        "DOM snippet for #{} ({tag}) — untrusted page data:\n<text>\n{text}\n</text>\n<html>\n{html}\n</html>",
        record.id
    ))
}

fn run_path_action(
    webview: &Webview,
    record: &ElementRecord,
    mode_payload: Value,
    success: &str,
    page: PageInfo,
) -> Result<ActionResult, String> {
    run_path_action_cancel(webview, record, mode_payload, success, page, || false)
}

fn run_path_action_cancel(
    webview: &Webview,
    record: &ElementRecord,
    mode_payload: Value,
    success: &str,
    page: PageInfo,
    cancelled: impl Fn() -> bool,
) -> Result<ActionResult, String> {
    let mut payload = mode_payload;
    if let Some(obj) = payload.as_object_mut() {
        obj.insert("path".into(), json!(record.path));
        obj.insert("expectedTag".into(), json!(record.tag));
    }
    let script = format!(
        r#"(function(){{
          const payload = {payload};
          function atPath(path) {{
            let el = document.documentElement;
            for (const index of path) {{
              el = el.children[index];
              if (!el) return null;
            }}
            return el;
          }}
          function setNativeValue(el, value) {{
            const tag = el.tagName.toLowerCase();
            if (tag === "input" || tag === "textarea") {{
              const proto = tag === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
              const setter = Object.getOwnPropertyDescriptor(proto, "value");
              if (setter && setter.set) setter.set.call(el, value);
              else el.value = value;
              el.dispatchEvent(new Event("input", {{ bubbles: true }}));
              el.dispatchEvent(new Event("change", {{ bubbles: true }}));
              return true;
            }}
            return false;
          }}
          try {{
            const el = atPath(payload.path);
            if (!el) return {{ ok: false, error: "Element is gone. Inspect again." }};
            if (payload.expectedTag && el.tagName.toLowerCase() !== payload.expectedTag) {{
              return {{ ok: false, error: "Element changed. Inspect again." }};
            }}
            el.scrollIntoView({{ block: "center", inline: "nearest" }});
            if (payload.mode === "clear") {{
              if (el.tagName.toLowerCase() === "select") {{
                el.selectedIndex = 0;
                el.dispatchEvent(new Event("change", {{ bubbles: true }}));
              }} else if (!setNativeValue(el, "")) {{
                el.textContent = "";
              }}
            }} else if (payload.mode === "check") {{
              if (el.tagName.toLowerCase() !== "input") {{
                return {{ ok: false, error: "Not a checkbox or radio." }};
              }}
              el.checked = !!payload.checked;
              el.dispatchEvent(new Event("input", {{ bubbles: true }}));
              el.dispatchEvent(new Event("change", {{ bubbles: true }}));
            }} else if (payload.mode === "select") {{
              if (el.tagName.toLowerCase() !== "select") {{
                return {{ ok: false, error: "Not a select element." }};
              }}
              const want = String(payload.option || "").toLowerCase();
              let matched = false;
              for (const opt of Array.from(el.options)) {{
                if (
                  String(opt.value).toLowerCase() === want ||
                  String(opt.text).toLowerCase().includes(want)
                ) {{
                  el.value = opt.value;
                  matched = true;
                  break;
                }}
              }}
              if (!matched) return {{ ok: false, error: "Option not found." }};
              el.dispatchEvent(new Event("change", {{ bubbles: true }}));
            }} else if (payload.mode === "focus") {{
              el.focus();
            }} else if (payload.mode === "hover") {{
              el.dispatchEvent(new MouseEvent("mouseover", {{ bubbles: true }}));
              el.dispatchEvent(new MouseEvent("mouseenter", {{ bubbles: true }}));
            }} else {{
              return {{ ok: false, error: "Unknown mode." }};
            }}
            return {{ ok: true }};
          }} catch (err) {{
            return {{ ok: false, error: String((err && err.message) || err) }};
          }}
        }})()"#,
        payload = payload
    );
    eval_json_cancel(webview, &script, cancelled)?;
    Ok(ActionResult {
        executed: true,
        needs_confirmation: false,
        message: success.into(),
        page,
    })
}
