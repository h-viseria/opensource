(function picosurfCleanViewBootstrap() {
  if (window.__picosurfCleanView) {
    return;
  }

  const MARKER = "data-picosurf-clean-view-ui";
  let active = false;
  let hovered = null;
  let overlay = null;
  let bound = false;

  function ensureOverlay() {
    if (overlay && overlay.isConnected) {
      return overlay;
    }
    overlay = document.createElement("div");
    overlay.setAttribute(MARKER, "overlay");
    Object.assign(overlay.style, {
      position: "fixed",
      pointerEvents: "none",
      zIndex: "2147483646",
      border: "2px solid #3b82f6",
      background: "rgba(59, 130, 246, 0.14)",
      boxSizing: "border-box",
      display: "none",
      borderRadius: "2px",
      transition: "left 80ms linear, top 80ms linear, width 80ms linear, height 80ms linear",
    });
    (document.documentElement || document.body).appendChild(overlay);
    return overlay;
  }

  function isUiNode(el) {
    return !!(el && el.closest && el.closest("[" + MARKER + "]"));
  }

  function isProtected(el) {
    return !el || el === document.documentElement || el === document.body;
  }

  function pickTarget(x, y) {
    const stack = document.elementsFromPoint(x, y) || [];
    for (const el of stack) {
      if (!(el instanceof Element)) continue;
      if (isUiNode(el)) continue;
      if (isProtected(el)) continue;
      return el;
    }
    return null;
  }

  function positionOverlay(el) {
    const box = ensureOverlay();
    const rect = el.getBoundingClientRect();
    box.style.display = "block";
    box.style.left = rect.left + "px";
    box.style.top = rect.top + "px";
    box.style.width = Math.max(rect.width, 1) + "px";
    box.style.height = Math.max(rect.height, 1) + "px";
    hovered = el;
  }

  function clearOverlay() {
    if (overlay) {
      overlay.style.display = "none";
    }
    hovered = null;
  }

  function hideElement(el) {
    el.style.setProperty("display", "none", "important");
    el.setAttribute("data-picosurf-clean-view-hidden", "1");
  }

  function onMouseMove(event) {
    if (!active) return;
    const el = pickTarget(event.clientX, event.clientY);
    if (!el) {
      clearOverlay();
      return;
    }
    if (el !== hovered) {
      positionOverlay(el);
    }
  }

  function onClick(event) {
    if (!active) return;
    const el = pickTarget(event.clientX, event.clientY);
    if (!el) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    hideElement(el);
    clearOverlay();
  }

  function onKeyDown(event) {
    if (!active) return;
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      stop();
    }
  }

  function onViewportChange() {
    if (active && hovered) {
      positionOverlay(hovered);
    }
  }

  function bind() {
    if (bound) return;
    document.addEventListener("mousemove", onMouseMove, true);
    document.addEventListener("click", onClick, true);
    document.addEventListener("keydown", onKeyDown, true);
    window.addEventListener("scroll", onViewportChange, true);
    window.addEventListener("resize", onViewportChange, true);
    bound = true;
  }

  function unbind() {
    if (!bound) return;
    document.removeEventListener("mousemove", onMouseMove, true);
    document.removeEventListener("click", onClick, true);
    document.removeEventListener("keydown", onKeyDown, true);
    window.removeEventListener("scroll", onViewportChange, true);
    window.removeEventListener("resize", onViewportChange, true);
    bound = false;
  }

  function start() {
    if (active) {
      return { ok: true, active: true };
    }
    active = true;
    bind();
    ensureOverlay();
    if (document.documentElement) {
      document.documentElement.style.cursor = "crosshair";
      document.documentElement.setAttribute("data-picosurf-clean-view", "active");
    }
    return { ok: true, active: true };
  }

  function stop() {
    if (!active) {
      return { ok: true, active: false };
    }
    active = false;
    unbind();
    clearOverlay();
    if (document.documentElement) {
      document.documentElement.style.cursor = "";
      document.documentElement.removeAttribute("data-picosurf-clean-view");
    }
    return { ok: true, active: false };
  }

  function status() {
    return { ok: true, active: active };
  }

  window.__picosurfCleanView = { start, stop, status };
})();
