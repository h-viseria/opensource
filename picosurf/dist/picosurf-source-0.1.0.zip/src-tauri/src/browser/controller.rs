use serde_json::{json, Value};
use tauri::Webview;

use super::actions::{
    is_dangerous_click, is_typeable, ActionResult, ElementRecord, InspectResult, PageInfo,
    ScrollDirection, UntrustedPage,
};
use super::eval::{self, eval_json};
use super::session::PageSession;

const EXTRACT_JS: &str = include_str!("extract.js");
const READ_JS: &str = include_str!("read.js");

pub(crate) struct InspectDraft {
    url: String,
    title: String,
    ready_state: String,
    lang: String,
    untrusted_text: String,
    records: Vec<ElementRecord>,
}

impl InspectDraft {
    pub(crate) fn has_visible_element(&self, element_id: u32) -> bool {
        self.records
            .iter()
            .any(|record| record.id == element_id && record.visible)
    }
}

pub(crate) fn collect_inspect(webview: &Webview) -> Result<InspectDraft, String> {
    collect_inspect_cancel(webview, || false)
}

pub(crate) fn collect_inspect_cancel(
    webview: &Webview,
    cancelled: impl Fn() -> bool,
) -> Result<InspectDraft, String> {
    let value = eval::eval_json_cancel(webview, EXTRACT_JS, cancelled)?;
    let url = string_field(&value, "url");
    let title = string_field(&value, "title");
    let ready_state = string_field(&value, "readyState");
    let lang = string_field(&value, "lang");
    let untrusted_text = string_field(&value, "untrustedText");
    let raw_elements = value
        .get("elements")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();

    let mut records = Vec::new();
    for (index, item) in raw_elements.into_iter().enumerate() {
        let path = item
            .get("path")
            .and_then(Value::as_array)
            .map(|parts| {
                parts
                    .iter()
                    .filter_map(Value::as_u64)
                    .map(|part| part as u32)
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        if path.is_empty() {
            continue;
        }
        let bounds = item.get("bounds").cloned().unwrap_or_else(|| json!({}));
        records.push(ElementRecord {
            id: (index as u32) + 1,
            tag: string_field(&item, "tag"),
            role: string_field(&item, "role"),
            text: string_field(&item, "text"),
            aria_label: string_field(&item, "ariaLabel"),
            placeholder: string_field(&item, "placeholder"),
            href: string_field(&item, "href"),
            enabled: item.get("enabled").and_then(Value::as_bool).unwrap_or(true),
            visible: item.get("visible").and_then(Value::as_bool).unwrap_or(true),
            bounds: super::actions::Bounds {
                x: number_field(&bounds, "x"),
                y: number_field(&bounds, "y"),
                width: number_field(&bounds, "width"),
                height: number_field(&bounds, "height"),
            },
            path,
            input_type: string_field(&item, "inputType"),
            name: string_field(&item, "name"),
            element_id: string_field(&item, "elementId"),
            class_name: string_field(&item, "className"),
            read_only: item.get("readOnly").and_then(Value::as_bool).unwrap_or(false),
            content_editable: item
                .get("contentEditable")
                .and_then(Value::as_bool)
                .unwrap_or(false),
            origin: String::new(),
            generation: 0,
        });
    }

    Ok(InspectDraft {
        url,
        title,
        ready_state,
        lang,
        untrusted_text,
        records,
    })
}

pub(crate) fn commit_inspect(session: &mut PageSession, draft: InspectDraft) -> InspectResult {
    session.replace(
        draft.url,
        draft.title,
        draft.ready_state,
        draft.lang,
        draft.untrusted_text,
        draft.records,
    );
    InspectResult {
        page: session.info(),
        elements: session.public_elements(),
    }
}

pub(crate) fn page_info(session: &PageSession) -> PageInfo {
    session.info()
}

pub(crate) fn collect_page_text(webview: &Webview) -> Result<UntrustedPage, String> {
    let value = eval_json(webview, READ_JS)?;
    let headings = value
        .get("headings")
        .and_then(Value::as_array)
        .map(|parts| {
            parts
                .iter()
                .filter_map(Value::as_str)
                .filter(|part| !part.is_empty())
                .collect::<Vec<_>>()
                .join(" | ")
        })
        .unwrap_or_default();
    let body = string_field(&value, "text");
    let mut text = if headings.is_empty() {
        body
    } else {
        format!("Headings: {headings}\n{body}")
    };
    text.truncate(12_000);
    if text.trim().is_empty() {
        return Err("This page has no readable text.".into());
    }
    Ok(UntrustedPage {
        url: string_field(&value, "url"),
        origin: string_field(&value, "origin"),
        title: string_field(&value, "title"),
        text,
    })
}

pub(crate) fn resolve_element(
    session: &PageSession,
    webview: &Webview,
    element_id: u32,
    generation: u64,
) -> Result<ElementRecord, String> {
    session
        .require(element_id, generation, &current_url(webview))
        .cloned()
}

pub(crate) fn click(
    webview: &Webview,
    record: &ElementRecord,
    confirmed: bool,
    page: PageInfo,
) -> Result<ActionResult, String> {
    click_cancel(webview, record, confirmed, page, || false)
}

pub(crate) fn click_cancel(
    webview: &Webview,
    record: &ElementRecord,
    confirmed: bool,
    page: PageInfo,
    cancelled: impl Fn() -> bool,
) -> Result<ActionResult, String> {
    if is_dangerous_click(record) && !confirmed {
        return Ok(ActionResult {
            executed: false,
            needs_confirmation: true,
            message: format!(
                "Confirm before clicking '{}' ({}).",
                display_name(record),
                record.tag
            ),
            page,
        });
    }
    let payload = json!({
        "path": record.path,
        "expectedTag": record.tag,
    });
    let script = format!(
        r#"(function(){{
            const payload = {payload};
            function atPath(path) {{
              let el = document.documentElement;
              for (const index of path) {{
                el = el.children[index];
                if (!el) return null;
              }}
              return el;
            }}
            try {{
              const el = atPath(payload.path);
              if (!el) return {{ ok: false, error: "Element is gone. Inspect the page again." }};
              if (payload.expectedTag && el.tagName.toLowerCase() !== payload.expectedTag) {{
                return {{ ok: false, error: "Element changed. Inspect the page again." }};
              }}
              const rect = el.getBoundingClientRect();
              if (rect.width < 1 || rect.height < 1) {{
                return {{ ok: false, error: "Element is not visible." }};
              }}
              el.scrollIntoView({{ block: "center", inline: "nearest" }});
              el.focus();
              el.click();
              return {{ ok: true, url: String(location.href) }};
            }} catch (err) {{
              return {{ ok: false, error: String((err && err.message) || err) }};
            }}
          }})()"#
    );
    eval::eval_json_cancel(webview, &script, cancelled)?;
    Ok(ActionResult {
        executed: true,
        needs_confirmation: false,
        message: format!("Clicked {}.", display_name(record)),
        page,
    })
}

pub(crate) fn type_text(
    webview: &Webview,
    record: &ElementRecord,
    text: &str,
    page: PageInfo,
) -> Result<ActionResult, String> {
    type_text_cancel(webview, record, text, page, false, || false)
}

pub(crate) fn type_text_cancel(
    webview: &Webview,
    record: &ElementRecord,
    text: &str,
    page: PageInfo,
    submit: bool,
    cancelled: impl Fn() -> bool,
) -> Result<ActionResult, String> {
    if text.len() > 8000 {
        return Err("That text is too long to type.".into());
    }
    if !is_typeable(record) {
        return Err("That element cannot accept typed text.".into());
    }
    let payload = json!({
        "path": record.path,
        "expectedTag": record.tag,
        "text": text,
        "submit": submit,
    });
    let script = format!(
        r#"(function(){{
            const payload = {payload};
            function atPath(path) {{
              let el = document.documentElement;
              for (const index of path) {{
                el = el.children[index];
                if (!el) return null;
              }}
              return el;
            }}
            function setNativeValue(el, value) {{
              const tag = el.tagName.toLowerCase();
              if (tag === "input" || tag === "textarea") {{
                const proto = tag === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                const setter = Object.getOwnPropertyDescriptor(proto, "value");
                if (setter && setter.set) setter.set.call(el, value);
                else el.value = value;
                el.dispatchEvent(new Event("input", {{ bubbles: true }}));
                el.dispatchEvent(new Event("change", {{ bubbles: true }}));
                try {{
                  el.dispatchEvent(new InputEvent("input", {{ bubbles: true, data: value, inputType: "insertText" }}));
                }} catch (e) {{}}
                return true;
              }}
              if (el.isContentEditable) {{
                el.textContent = value;
                el.dispatchEvent(new Event("input", {{ bubbles: true }}));
                try {{
                  el.dispatchEvent(new InputEvent("input", {{ bubbles: true, data: value, inputType: "insertText" }}));
                }} catch (e) {{}}
                return true;
              }}
              return false;
            }}
            function submitSearch(el) {{
              const enter = {{ key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }};
              el.dispatchEvent(new KeyboardEvent("keydown", enter));
              el.dispatchEvent(new KeyboardEvent("keypress", enter));
              el.dispatchEvent(new KeyboardEvent("keyup", enter));
              const form = el.form || el.closest("form");
              if (form) {{
                const btn = form.querySelector(
                  'button[type="submit"], input[type="submit"], button[aria-label*="search" i], button[class*="search" i], [role="button"][aria-label*="search" i]'
                );
                if (btn) {{
                  btn.click();
                  return;
                }}
                if (typeof form.requestSubmit === "function") {{
                  try {{ form.requestSubmit(); return; }} catch (e) {{}}
                }}
              }}
              const host = el.closest('[class*="search" i], [id*="search" i], header, nav') || el.parentElement;
              if (host) {{
                const btn = host.querySelector(
                  'button[aria-label*="search" i], button[class*="search" i], [role="button"][aria-label*="search" i], button[type="submit"]'
                );
                if (btn) btn.click();
              }}
            }}
            try {{
              const el = atPath(payload.path);
              if (!el) return {{ ok: false, error: "Element is gone. Inspect the page again." }};
              if (payload.expectedTag && el.tagName.toLowerCase() !== payload.expectedTag) {{
                return {{ ok: false, error: "Element changed. Inspect the page again." }};
              }}
              el.scrollIntoView({{ block: "center", inline: "nearest" }});
              el.click();
              el.focus();
              if (el.readOnly || el.getAttribute("aria-readonly") === "true") {{
                el.click();
              }}
              if (!setNativeValue(el, payload.text)) {{
                return {{ ok: false, error: "Element cannot accept typed text." }};
              }}
              if (payload.submit) submitSearch(el);
              return {{ ok: true }};
            }} catch (err) {{
              return {{ ok: false, error: String((err && err.message) || err) }};
            }}
          }})()"#
    );
    eval::eval_json_cancel(webview, &script, cancelled)?;
    Ok(ActionResult {
        executed: true,
        needs_confirmation: false,
        message: if submit {
            format!("Typed and submitted {}.", display_name(record))
        } else {
            format!("Typed into {}.", display_name(record))
        },
        page,
    })
}

pub(crate) fn scroll(
    webview: &Webview,
    direction: ScrollDirection,
    page: PageInfo,
) -> Result<ActionResult, String> {
    let (x, y, absolute) = match direction {
        ScrollDirection::Up => (0, -480, false),
        ScrollDirection::Down => (0, 480, false),
        ScrollDirection::Left => (-320, 0, false),
        ScrollDirection::Right => (320, 0, false),
        ScrollDirection::Top => (0, 0, true),
        ScrollDirection::Bottom => (0, 1, true),
    };
    let script = format!(
        r#"(function(){{
            try {{
              if ({absolute}) {{
                window.scrollTo(0, {y} ? document.body.scrollHeight : 0);
              }} else {{
                window.scrollBy({x}, {y});
              }}
              return {{ ok: true }};
            }} catch (err) {{
              return {{ ok: false, error: String((err && err.message) || err) }};
            }}
          }})()"#
    );
    eval_json(webview, &script)?;
    Ok(ActionResult {
        executed: true,
        needs_confirmation: false,
        message: "Scrolled the page.".into(),
        page,
    })
}


fn current_url(webview: &Webview) -> String {
    webview
        .url()
        .map(|url| url.to_string())
        .unwrap_or_default()
}

fn display_name(record: &ElementRecord) -> String {
    if !record.text.is_empty() {
        record.text.clone()
    } else if !record.aria_label.is_empty() {
        record.aria_label.clone()
    } else if !record.placeholder.is_empty() {
        record.placeholder.clone()
    } else {
        record.tag.clone()
    }
}

fn string_field(value: &Value, key: &str) -> String {
    value
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

fn number_field(value: &Value, key: &str) -> i32 {
    value
        .get(key)
        .and_then(Value::as_f64)
        .unwrap_or(0.0)
        .round() as i32
}
