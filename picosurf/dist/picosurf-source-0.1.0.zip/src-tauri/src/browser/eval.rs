use std::sync::mpsc::{self, RecvTimeoutError};
use std::time::{Duration, Instant};

use serde_json::Value;
use tauri::Webview;

const EVAL_TIMEOUT: Duration = Duration::from_secs(8);
const POLL: Duration = Duration::from_millis(200);

pub fn eval_json(webview: &Webview, script: &str) -> Result<Value, String> {
    eval_json_cancel(webview, script, || false)
}

pub fn eval_json_cancel(
    webview: &Webview,
    script: &str,
    cancelled: impl Fn() -> bool,
) -> Result<Value, String> {
    let wrapped = format!(
        "(function(){{ try {{ const __r = {script}; return __r; }} catch (e) {{ return {{ ok: false, error: String((e && e.message) || e) }}; }} }})()"
    );
    let (tx, rx) = mpsc::channel();
    webview
        .eval_with_callback(wrapped, move |payload| {
            let _ = tx.send(payload);
        })
        .map_err(|err| friendly_page_error(&err.to_string()))?;
    let deadline = Instant::now() + EVAL_TIMEOUT;
    loop {
        if cancelled() {
            return Err("Stopped.".into());
        }
        let remaining = deadline.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            return Err("The page did not answer in time. Cancel and try again.".into());
        }
        match rx.recv_timeout(remaining.min(POLL)) {
            Ok(raw) => return parse_eval_result(&raw),
            Err(RecvTimeoutError::Timeout) => continue,
            Err(RecvTimeoutError::Disconnected) => {
                return Err("The page did not answer. Cancel and try again.".into());
            }
        }
    }
}

fn parse_eval_result(raw: &str) -> Result<Value, String> {
    if let Ok(value) = serde_json::from_str::<Value>(raw) {
        return check_script_error(value);
    }
    if let Ok(inner) = serde_json::from_str::<String>(raw) {
        if let Ok(value) = serde_json::from_str::<Value>(&inner) {
            return check_script_error(value);
        }
        return Err(friendly_page_error(&inner));
    }
    Err(friendly_page_error(raw))
}

fn check_script_error(value: Value) -> Result<Value, String> {
    if value.get("ok").and_then(Value::as_bool) == Some(false) {
        let error = value
            .get("error")
            .and_then(Value::as_str)
            .unwrap_or("Page script failed");
        return Err(friendly_page_error(error));
    }
    Ok(value)
}

pub fn is_transient_page_error(err: &str) -> bool {
    let lower = err.to_ascii_lowercase();
    lower.contains("tree traversal")
        || lower.contains("still loading")
        || lower.contains("did not answer")
        || lower.contains("result was destroyed")
        || lower.contains("document is unloaded")
        || lower.contains("target closed")
        || lower.contains("cannot complete")
        || lower.contains("navigation")
}

fn friendly_page_error(err: &str) -> String {
    if is_transient_page_error(err) {
        "The page was still loading (WebView tree traversal failed). Cancel, wait, or try again."
            .into()
    } else if err.trim().is_empty() {
        "The page script failed.".into()
    } else {
        err.trim().to_string()
    }
}
