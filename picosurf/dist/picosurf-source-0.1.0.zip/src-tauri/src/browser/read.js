(() => {
  try {
    function clip(value, max) {
      const text = String(value || "")
        .replace(/\s+/g, " ")
        .trim();
      return text.length > max ? text.slice(0, max) : text;
    }

    const headings = Array.from(document.querySelectorAll("h1, h2, h3"))
      .map((el) => clip(el.innerText, 180))
      .filter(Boolean)
      .slice(0, 24);

    const root = document.body || document.documentElement;
    const text = clip((root && root.innerText) || "", 8000);

    return {
      ok: true,
      url: String(location.href || ""),
      origin: String(location.origin || ""),
      title: clip(document.title, 200),
      headings,
      text,
    };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
})()
