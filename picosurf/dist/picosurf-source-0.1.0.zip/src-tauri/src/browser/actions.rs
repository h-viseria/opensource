use serde::{Deserialize, Serialize};
use url::Url;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Bounds {
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PageElement {
    pub id: u32,
    pub generation: u64,
    pub tag: String,
    pub role: String,
    pub text: String,
    pub aria_label: String,
    pub placeholder: String,
    pub href: String,
    pub enabled: bool,
    pub visible: bool,
    pub bounds: Bounds,
    pub dangerous: bool,
    pub typeable: bool,
    #[serde(default)]
    pub input_type: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub element_id: String,
    #[serde(default)]
    pub class_name: String,
    #[serde(default)]
    pub read_only: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UntrustedPage {
    pub url: String,
    pub origin: String,
    pub title: String,
    pub text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PageInfo {
    pub url: String,
    pub origin: String,
    pub title: String,
    pub ready_state: String,
    pub lang: String,
    pub untrusted_text: String,
    pub element_count: usize,
    pub generation: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InspectResult {
    pub page: PageInfo,
    pub elements: Vec<PageElement>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ActionResult {
    pub executed: bool,
    pub needs_confirmation: bool,
    pub message: String,
    pub page: PageInfo,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ScreenshotResult {
    pub width: i32,
    pub height: i32,
    pub device_pixel_ratio: f64,
    pub url: String,
    pub note: String,
    #[serde(default)]
    pub full_page: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub png_base64: Option<String>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub enum ScrollDirection {
    Up,
    Down,
    Left,
    Right,
    Top,
    Bottom,
}

#[derive(Debug, Clone)]
pub struct ElementRecord {
    pub id: u32,
    pub tag: String,
    pub role: String,
    pub text: String,
    pub aria_label: String,
    pub placeholder: String,
    pub href: String,
    pub enabled: bool,
    pub visible: bool,
    pub bounds: Bounds,
    pub path: Vec<u32>,
    pub input_type: String,
    pub name: String,
    pub element_id: String,
    pub class_name: String,
    pub read_only: bool,
    pub content_editable: bool,
    pub origin: String,
    pub generation: u64,
}

impl ElementRecord {
    pub fn public(&self) -> PageElement {
        PageElement {
            id: self.id,
            generation: self.generation,
            tag: self.tag.clone(),
            role: self.role.clone(),
            text: self.text.clone(),
            aria_label: self.aria_label.clone(),
            placeholder: self.placeholder.clone(),
            href: self.href.clone(),
            enabled: self.enabled,
            visible: self.visible,
            bounds: self.bounds.clone(),
            dangerous: is_dangerous_click(self),
            typeable: is_typeable(self),
            input_type: self.input_type.clone(),
            name: self.name.clone(),
            element_id: self.element_id.clone(),
            class_name: self.class_name.clone(),
            read_only: self.read_only,
        }
    }
}

pub fn origin_of(url: &str) -> String {
    Url::parse(url)
        .ok()
        .map(|parsed| parsed.origin().ascii_serialization())
        .unwrap_or_default()
}

pub fn is_dangerous_click(el: &ElementRecord) -> bool {
    let kind = el.input_type.to_ascii_lowercase();
    if matches!(kind.as_str(), "submit" | "file" | "image") {
        return true;
    }
    if el.tag == "form" {
        return true;
    }
    let blob = format!("{} {} {} {}", el.text, el.aria_label, el.role, el.href).to_ascii_lowercase();
    [
        "add to cart",
        "buy now",
        "checkout",
        "purchase",
        "pay now",
        "place order",
        "delete",
        "remove account",
        "submit",
        "sign in",
        "log in",
        "login",
        "send message",
        "download",
    ]
    .iter()
    .any(|needle| blob.contains(needle))
}

pub fn is_typeable(el: &ElementRecord) -> bool {
    if !el.enabled {
        return false;
    }
    if el.input_type.eq_ignore_ascii_case("file") || el.input_type.eq_ignore_ascii_case("submit") {
        return false;
    }
    matches!(el.tag.as_str(), "input" | "textarea" | "select")
        || el.role == "textbox"
        || el.role == "searchbox"
        || el.content_editable
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample(tag: &str, input_type: &str, text: &str) -> ElementRecord {
        ElementRecord {
            id: 1,
            tag: tag.into(),
            role: String::new(),
            text: text.into(),
            aria_label: String::new(),
            placeholder: String::new(),
            href: String::new(),
            enabled: true,
            visible: true,
            bounds: Bounds {
                x: 0,
                y: 0,
                width: 10,
                height: 10,
            },
            path: vec![0],
            input_type: input_type.into(),
            name: String::new(),
            element_id: String::new(),
            class_name: String::new(),
            read_only: false,
            content_editable: false,
            origin: "https://example.com".into(),
            generation: 1,
        }
    }

    #[test]
    fn submit_is_dangerous() {
        assert!(is_dangerous_click(&sample("input", "submit", "Save")));
    }

    #[test]
    fn add_to_cart_is_dangerous() {
        assert!(is_dangerous_click(&sample("button", "button", "Add to cart")));
    }

    #[test]
    fn ordinary_link_is_safe() {
        assert!(!is_dangerous_click(&sample("a", "", "Next article")));
    }
}
