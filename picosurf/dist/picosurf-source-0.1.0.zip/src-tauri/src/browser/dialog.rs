use std::cell::RefCell;
use std::sync::mpsc;
use std::sync::Mutex;

use tauri::{AppHandle, Manager};
use webview2_com::Microsoft::Web::WebView2::Win32::{
    ICoreWebView2, ICoreWebView2Controller, ICoreWebView2Deferral,
    ICoreWebView2ScriptDialogOpeningEventArgs, COREWEBVIEW2_SCRIPT_DIALOG_KIND,
    COREWEBVIEW2_SCRIPT_DIALOG_KIND_BEFOREUNLOAD, COREWEBVIEW2_SCRIPT_DIALOG_KIND_CONFIRM,
    COREWEBVIEW2_SCRIPT_DIALOG_KIND_PROMPT,
};
use windows::core::{HSTRING, PWSTR, Result as WinResult};

#[derive(Clone, Debug)]
pub struct PendingScriptDialog {
    pub kind: String,
    pub message: String,
    pub default_text: String,
}

struct StoredDialog {
    args: ICoreWebView2ScriptDialogOpeningEventArgs,
    deferral: Option<ICoreWebView2Deferral>,
}

thread_local! {
    static PENDING: RefCell<Option<StoredDialog>> = RefCell::new(None);
}

static SUMMARY: Mutex<Option<PendingScriptDialog>> = Mutex::new(None);

pub fn pending_summary() -> Option<PendingScriptDialog> {
    SUMMARY.lock().ok()?.clone()
}

fn set_summary(summary: PendingScriptDialog) {
    if let Ok(mut slot) = SUMMARY.lock() {
        *slot = Some(summary);
    }
}

fn clear_summary() {
    if let Ok(mut slot) = SUMMARY.lock() {
        *slot = None;
    }
}

pub fn install(app: &AppHandle) -> Result<(), String> {
    let browser = app
        .get_webview("browser")
        .ok_or_else(|| "Browser view is not ready".to_string())?;
    browser
        .with_webview({
            let app = app.clone();
            move |platform| {
                if let Err(err) = attach(&app, platform.controller()) {
                    eprintln!("Script dialog hook failed: {err}");
                }
            }
        })
        .map_err(|err| err.to_string())?;
    Ok(())
}

fn attach(_app: &AppHandle, controller: ICoreWebView2Controller) -> Result<(), String> {
    use webview2_com::ScriptDialogOpeningEventHandler;

    let webview = unsafe {
        controller
            .CoreWebView2()
            .map_err(|err| err.to_string())?
    };
    disable_default_dialogs(&webview)?;
    let handler = ScriptDialogOpeningEventHandler::create(Box::new(move |_, args| {
        if let Some(args) = args {
            if let Err(err) = on_dialog(args) {
                eprintln!("Dialog handler error: {err}");
            }
        }
        Ok(())
    }));
    let mut token = 0i64;
    unsafe {
        webview
            .add_ScriptDialogOpening(&handler, &mut token)
            .map_err(|err| err.to_string())?;
    }
    Ok(())
}

fn disable_default_dialogs(webview: &ICoreWebView2) -> Result<(), String> {
    let settings = unsafe { webview.Settings().map_err(|err| err.to_string())? };
    unsafe {
        settings
            .SetAreDefaultScriptDialogsEnabled(false)
            .map_err(|err| err.to_string())?;
    }
    Ok(())
}

fn on_dialog(args: ICoreWebView2ScriptDialogOpeningEventArgs) -> Result<(), String> {
    let kind = read_kind(&args)?;
    let message = read_pwstring(|ptr| unsafe { args.Message(ptr) })?;
    let default_text = read_pwstring(|ptr| unsafe { args.DefaultText(ptr) }).unwrap_or_default();
    let kind_label = dialog_kind_label(kind);

    let agent_active = crate::ai::agent::has_session().unwrap_or(false);
    let deferral = unsafe { args.GetDeferral().ok() };

    if agent_active
        && matches!(
            kind.0,
            x if x == COREWEBVIEW2_SCRIPT_DIALOG_KIND_CONFIRM.0
                || x == COREWEBVIEW2_SCRIPT_DIALOG_KIND_PROMPT.0
                || x == COREWEBVIEW2_SCRIPT_DIALOG_KIND_BEFOREUNLOAD.0
        )
    {
        set_summary(PendingScriptDialog {
            kind: kind_label.to_string(),
            message: message.clone(),
            default_text: default_text.clone(),
        });
        PENDING.with(|slot| {
            *slot.borrow_mut() = Some(StoredDialog { args, deferral });
        });
        return Ok(());
    }

    if kind.0 == COREWEBVIEW2_SCRIPT_DIALOG_KIND_PROMPT.0 {
        unsafe {
            args.SetResultText(&HSTRING::from(default_text.as_str()))
                .map_err(|err| err.to_string())?;
        }
    }
    unsafe {
        args.Accept().map_err(|err| err.to_string())?;
    }
    if let Some(deferral) = deferral {
        unsafe {
            deferral.Complete().ok();
        }
    }
    Ok(())
}

pub fn handle_dialog(
    app: &AppHandle,
    accept: bool,
    prompt_text: Option<&str>,
) -> Result<String, String> {
    let browser = app
        .get_webview("browser")
        .ok_or_else(|| "Browser view is not ready".to_string())?;
    let prompt_owned = prompt_text.map(str::to_string);
    let (tx, rx) = mpsc::sync_channel(1);
    browser
        .with_webview(move |_| {
            let result = complete_pending(accept, prompt_owned.as_deref());
            let _ = tx.send(result);
        })
        .map_err(|err| err.to_string())?;
    let message = rx
        .recv()
        .map_err(|_| "Could not complete the script dialog.".to_string())??;
    clear_summary();
    Ok(message)
}

fn complete_pending(accept: bool, prompt_text: Option<&str>) -> Result<String, String> {
    PENDING.with(|slot| {
        let mut pending = slot.borrow_mut();
        let Some(stored) = pending.take() else {
            return Err("No script dialog is waiting.".into());
        };
        if accept {
            if let Some(text) = prompt_text {
                unsafe {
                    stored
                        .args
                        .SetResultText(&HSTRING::from(text))
                        .map_err(|err| err.to_string())?;
                }
            }
            unsafe {
                stored.args.Accept().map_err(|err| err.to_string())?;
            }
        }
        if let Some(deferral) = stored.deferral {
            unsafe {
                deferral.Complete().ok();
            }
        }
        Ok(if accept {
            "Accepted the dialog.".into()
        } else {
            "Dismissed the dialog.".into()
        })
    })
}

fn read_kind(args: &ICoreWebView2ScriptDialogOpeningEventArgs) -> Result<COREWEBVIEW2_SCRIPT_DIALOG_KIND, String> {
    let mut kind = COREWEBVIEW2_SCRIPT_DIALOG_KIND(0);
    unsafe {
        args.Kind(&mut kind).map_err(|err| err.to_string())?;
    }
    Ok(kind)
}

fn read_pwstring(read: impl FnOnce(&mut PWSTR) -> WinResult<()>) -> Result<String, String> {
    let mut ptr = PWSTR::null();
    read(&mut ptr).map_err(|err| err.to_string())?;
    if ptr.is_null() {
        return Ok(String::new());
    }
    Ok(unsafe { ptr.to_string() }.map_err(|err| err.to_string())?)
}

fn dialog_kind_label(kind: COREWEBVIEW2_SCRIPT_DIALOG_KIND) -> &'static str {
    if kind.0 == COREWEBVIEW2_SCRIPT_DIALOG_KIND_CONFIRM.0 {
        "confirm"
    } else if kind.0 == COREWEBVIEW2_SCRIPT_DIALOG_KIND_PROMPT.0 {
        "prompt"
    } else if kind.0 == COREWEBVIEW2_SCRIPT_DIALOG_KIND_BEFOREUNLOAD.0 {
        "beforeunload"
    } else {
        "dialog"
    }
}
