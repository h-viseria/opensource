(() => {
  try {
    const payload = __PAYLOAD_JSON__;
    const query = String(payload.query || "")
      .trim()
      .toLowerCase();
    if (!query || query.length > 120) {
      return { ok: false, error: "Query must be 1-120 characters." };
    }

    function clip(value, max) {
      const text = String(value || "")
        .replace(/\s+/g, " ")
        .trim();
      return text.length > max ? text.slice(0, max) + "…" : text;
    }

    const hits = [];
    const seen = new Set();

    function pushHit(kind, preview, path) {
      const key = kind + "|" + preview.slice(0, 80);
      if (seen.has(key) || hits.length >= 12) return;
      seen.add(key);
      hits.push({ kind, preview: clip(preview, 220), path });
    }

    const selectors = "a, button, input, textarea, select, [role='button'], [role='link'], h1, h2, h3, label, p, li";
    const nodes = Array.from(document.querySelectorAll(selectors));
    for (const el of nodes) {
      const text = clip(el.innerText || el.textContent || "", 240);
      const aria = clip(el.getAttribute("aria-label") || "", 120);
      const placeholder = clip(el.getAttribute("placeholder") || "", 120);
      const blob = (text + " " + aria + " " + placeholder).toLowerCase();
      if (!blob.includes(query)) continue;
      const path = [];
      let node = el;
      while (node && node.parentElement) {
        const parent = node.parentElement;
        path.unshift(Array.prototype.indexOf.call(parent.children, node));
        node = parent;
        if (path.length > 24) break;
      }
      if (path.length === 0) continue;
      pushHit(el.tagName.toLowerCase(), text || aria || placeholder || el.tagName, path);
    }

    return { ok: true, hits };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
})()
