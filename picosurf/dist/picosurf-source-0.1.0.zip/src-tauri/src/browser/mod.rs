mod actions;
#[cfg(windows)]
mod capture;
mod clean_view;
mod controller;
#[cfg(windows)]
mod dialog;
mod eval;
mod interactions;
mod session;
pub(crate) mod wait;
pub(crate) use wait::WaitCondition;

pub use actions::{
    ActionResult, ElementRecord, InspectResult, PageElement, PageInfo, ScrollDirection,
    ScreenshotResult, UntrustedPage,
};
pub use session::PageSession;

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Emitter, LogicalPosition, LogicalSize, Manager, Webview, Window};
use url::Url;

use crate::security;

const START_URL: &str = "https://duckduckgo.com/";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BrowserState {
    pub url: String,
    pub title: String,
    pub can_go_back: bool,
    pub can_go_forward: bool,
}

#[derive(Default)]
pub struct History {
    entries: Vec<String>,
    index: usize,
}

impl History {
    pub fn current(&self) -> Option<&str> {
        self.entries.get(self.index).map(String::as_str)
    }

    pub fn can_go_back(&self) -> bool {
        self.index > 0
    }

    pub fn can_go_forward(&self) -> bool {
        !self.entries.is_empty() && self.index + 1 < self.entries.len()
    }

    pub fn record(&mut self, url: &str) {
        if self.current() == Some(url) {
            return;
        }
        if !self.entries.is_empty() {
            self.entries.truncate(self.index + 1);
        }
        self.entries.push(url.to_string());
        self.index = self.entries.len().saturating_sub(1);
    }

    pub fn go_back(&mut self) {
        if self.can_go_back() {
            self.index -= 1;
        }
    }

    pub fn go_forward(&mut self) {
        if self.can_go_forward() {
            self.index += 1;
        }
    }
}

pub fn start_url() -> Url {
    Url::parse(START_URL).expect("start url")
}

pub fn snapshot(webview: &Webview, history: &History, title: &str) -> BrowserState {
    let url = webview
        .url()
        .map(|item| item.to_string())
        .unwrap_or_else(|_| history.current().unwrap_or("").to_string());
    BrowserState {
        url,
        title: title.to_string(),
        can_go_back: history.can_go_back(),
        can_go_forward: history.can_go_forward(),
    }
}

pub fn emit_state(app: &AppHandle, state: &BrowserState) {
    if let Some(chrome) = app.get_webview("chrome") {
        let _ = chrome.emit("browser-state", state);
    }
}

pub fn apply_bounds(
    window: &Window,
    browser: &Webview,
    toolbar_height: f64,
    sidebar_width: f64,
    ai_open: bool,
) -> Result<(), String> {
    let factor = window.scale_factor().map_err(|err| err.to_string())?;
    let size = window.inner_size().map_err(|err| err.to_string())?;
    let logical = size.to_logical::<f64>(factor);
    let sidebar = if ai_open { sidebar_width } else { 0.0 };
    let width = (logical.width - sidebar).max(160.0);
    let height = (logical.height - toolbar_height).max(120.0);
    browser
        .set_position(LogicalPosition::new(0.0, toolbar_height))
        .map_err(|err| err.to_string())?;
    browser
        .set_size(LogicalSize::new(width, height))
        .map_err(|err| err.to_string())?;
    Ok(())
}

pub fn parse_navigate_input(
    input: &str,
    settings: &crate::search::SearchSettings,
) -> Result<Url, String> {
    match security::parse_url_or_host(input)? {
        Some(url) => Ok(url),
        None => {
            let engine = crate::search::SearchEngine::from_id(&settings.engine);
            crate::search::build_search_url(engine, input.trim(), &settings.custom_template)
        }
    }
}

pub(crate) fn eval_json_cancel(
    webview: &tauri::Webview,
    script: &str,
    cancelled: impl Fn() -> bool,
) -> Result<serde_json::Value, String> {
    eval::eval_json_cancel(webview, script, cancelled)
}

pub(crate) fn collect_inspect(webview: &tauri::Webview) -> Result<controller::InspectDraft, String> {
    controller::collect_inspect(webview)
}

pub(crate) fn collect_inspect_cancel(
    webview: &tauri::Webview,
    cancelled: impl Fn() -> bool,
) -> Result<controller::InspectDraft, String> {
    controller::collect_inspect_cancel(webview, cancelled)
}

pub(crate) fn is_transient_page_error(err: &str) -> bool {
    eval::is_transient_page_error(err)
}

pub(crate) fn commit_inspect(
    session: &mut PageSession,
    draft: controller::InspectDraft,
) -> InspectResult {
    controller::commit_inspect(session, draft)
}

pub fn page_info(session: &PageSession) -> PageInfo {
    controller::page_info(session)
}

pub(crate) fn read_page(webview: &tauri::Webview) -> Result<UntrustedPage, String> {
    controller::collect_page_text(webview)
}

pub(crate) struct AgentElementFlags {
    pub dangerous: bool,
    pub password: bool,
    pub label: String,
}

pub(crate) fn agent_element_flags(
    session: &PageSession,
    webview: &tauri::Webview,
    element_id: u32,
    generation: u64,
) -> Result<AgentElementFlags, String> {
    let record = controller::resolve_element(session, webview, element_id, generation)?;
    Ok(AgentElementFlags {
        dangerous: actions::is_dangerous_click(&record),
        password: record.input_type.eq_ignore_ascii_case("password"),
        label: if record.text.is_empty() {
            record.tag.clone()
        } else {
            record.text.clone()
        },
    })
}

pub(crate) fn resolve_element(
    session: &PageSession,
    webview: &tauri::Webview,
    element_id: u32,
    generation: u64,
) -> Result<actions::ElementRecord, String> {
    controller::resolve_element(session, webview, element_id, generation)
}

pub(crate) fn click(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    confirmed: bool,
    page: PageInfo,
) -> Result<ActionResult, String> {
    controller::click(webview, record, confirmed, page)
}

pub(crate) fn click_cancel(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    confirmed: bool,
    page: PageInfo,
    cancelled: impl Fn() -> bool,
) -> Result<ActionResult, String> {
    controller::click_cancel(webview, record, confirmed, page, cancelled)
}

pub(crate) fn type_text(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    text: &str,
    page: PageInfo,
) -> Result<ActionResult, String> {
    controller::type_text(webview, record, text, page)
}

pub(crate) fn type_text_cancel(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    text: &str,
    page: PageInfo,
    submit: bool,
    cancelled: impl Fn() -> bool,
) -> Result<ActionResult, String> {
    controller::type_text_cancel(webview, record, text, page, submit, cancelled)
}

pub(crate) fn scroll(
    webview: &tauri::Webview,
    direction: ScrollDirection,
    page: PageInfo,
) -> Result<ActionResult, String> {
    controller::scroll(webview, direction, page)
}

pub fn install_dialog_handler(app: &tauri::AppHandle) -> Result<(), String> {
    #[cfg(windows)]
    {
        return dialog::install(app);
    }
    #[cfg(not(windows))]
    {
        let _ = app;
        Ok(())
    }
}

pub fn handle_script_dialog(
    app: &tauri::AppHandle,
    accept: bool,
    prompt_text: Option<&str>,
) -> Result<String, String> {
    #[cfg(windows)]
    {
        return dialog::handle_dialog(app, accept, prompt_text);
    }
    #[cfg(not(windows))]
    {
        let _ = (app, accept, prompt_text);
        Err("Script dialogs are only supported on Windows.".into())
    }
}

#[cfg(windows)]
pub use dialog::PendingScriptDialog;

#[cfg(not(windows))]
#[derive(Clone, Debug)]
pub struct PendingScriptDialog {
    pub kind: String,
    pub message: String,
    pub default_text: String,
}

pub fn pending_script_dialog() -> Option<PendingScriptDialog> {
    #[cfg(windows)]
    {
        return dialog::pending_summary();
    }
    #[cfg(not(windows))]
    {
        None
    }
}

pub(crate) fn screenshot(
    webview: &tauri::Webview,
    full_page: bool,
    save_dir: Option<&std::path::Path>,
) -> Result<ScreenshotResult, String> {
    #[cfg(windows)]
    {
        return capture::capture(webview, full_page, save_dir);
    }
    #[cfg(not(windows))]
    {
        let _ = (webview, full_page, save_dir);
        Err("Screenshots are only supported on Windows.".into())
    }
}

pub(crate) fn clear_field(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    page: PageInfo,
) -> Result<ActionResult, String> {
    interactions::clear_field(webview, record, page)
}

pub(crate) fn set_checked(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    checked: bool,
    page: PageInfo,
) -> Result<ActionResult, String> {
    interactions::set_checked(webview, record, checked, page)
}

pub(crate) fn select_option(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    option: &str,
    page: PageInfo,
) -> Result<ActionResult, String> {
    interactions::select_option(webview, record, option, page)
}

pub(crate) fn focus_element(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    page: PageInfo,
) -> Result<ActionResult, String> {
    interactions::focus_element(webview, record, page)
}

pub(crate) fn hover_element(
    webview: &tauri::Webview,
    record: &actions::ElementRecord,
    page: PageInfo,
) -> Result<ActionResult, String> {
    interactions::hover_element(webview, record, page)
}

pub(crate) fn click_at(
    webview: &tauri::Webview,
    x: i32,
    y: i32,
    page: PageInfo,
) -> Result<ActionResult, String> {
    interactions::click_at(webview, x, y, page)
}

pub(crate) fn press_key(
    webview: &tauri::Webview,
    record: Option<&actions::ElementRecord>,
    key: &str,
    page: PageInfo,
) -> Result<ActionResult, String> {
    interactions::press_key(webview, record, key, page)
}

pub(crate) fn dom_search(webview: &tauri::Webview, query: &str) -> Result<String, String> {
    interactions::dom_search(webview, query)
}

pub(crate) fn dom_snippet(webview: &tauri::Webview, record: &actions::ElementRecord) -> Result<String, String> {
    interactions::dom_snippet(webview, record)
}

pub(crate) fn wait_for(
    webview: &tauri::Webview,
    condition: wait::WaitCondition,
    value: &str,
    timeout_ms: u64,
    cancelled: impl Fn() -> bool,
) -> Result<String, String> {
    wait::wait_for(webview, condition, value, timeout_ms, cancelled)
}

pub fn clean_view_start(webview: &Webview) -> Result<bool, String> {
    clean_view::start(webview)
}

pub fn clean_view_stop(webview: &Webview) -> Result<bool, String> {
    clean_view::stop(webview)
}

pub fn clean_view_status(webview: &Webview) -> Result<bool, String> {
    clean_view::status(webview)
}
