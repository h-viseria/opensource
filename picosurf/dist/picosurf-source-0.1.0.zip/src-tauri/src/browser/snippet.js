(() => {
  try {
    const payload = __PAYLOAD_JSON__;
    function atPath(path) {
      let el = document.documentElement;
      for (const index of path) {
        el = el.children[index];
        if (!el) return null;
      }
      return el;
    }
    const el = atPath(payload.path);
    if (!el) return { ok: false, error: "Element is gone. Inspect again." };
    function clip(value, max) {
      const text = String(value || "")
        .replace(/\s+/g, " ")
        .trim();
      return text.length > max ? text.slice(0, max) + "…" : text;
    }
    let html = "";
    try {
      html = clip(el.outerHTML || "", 1800);
    } catch (e) {
      html = "";
    }
    html = html.replace(/<script[\s\S]*?<\/script>/gi, "");
    const text = clip(el.innerText || el.textContent || "", 1200);
    return {
      ok: true,
      tag: String(el.tagName || "").toLowerCase(),
      text,
      html,
    };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
})()
