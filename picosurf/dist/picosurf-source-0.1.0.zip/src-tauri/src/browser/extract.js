(() => {
  try {
    const MAX = 160;
    const SKIP = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "META", "LINK", "HEAD", "HTML"]);
    const INTERESTING = new Set([
      "A",
      "BUTTON",
      "INPUT",
      "TEXTAREA",
      "SELECT",
      "OPTION",
      "LABEL",
      "SUMMARY",
      "DETAILS",
    ]);

    function visible(el) {
      const style = window.getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
        return false;
      }
      const rect = el.getBoundingClientRect();
      return rect.width >= 2 && rect.height >= 2;
    }

    function pathOf(el) {
      const path = [];
      let node = el;
      while (node && node !== document.documentElement) {
        const parent = node.parentElement;
        if (!parent) break;
        path.push(Array.prototype.indexOf.call(parent.children, node));
        node = parent;
      }
      path.reverse();
      return path;
    }

    function clip(value, max) {
      const text = String(value || "")
        .replace(/\s+/g, " ")
        .trim();
      return text.length > max ? text.slice(0, max) : text;
    }

    function labelText(el) {
      if (el.labels && el.labels.length) {
        return clip(el.labels[0].innerText, 80);
      }
      const id = el.getAttribute("id");
      if (id) {
        const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (label) return clip(label.innerText, 80);
      }
      return "";
    }

    function interesting(el) {
      if (SKIP.has(el.tagName)) return false;
      if (INTERESTING.has(el.tagName)) return true;
      const role = (el.getAttribute("role") || "").toLowerCase();
      if (["button", "link", "textbox", "searchbox", "combobox", "menuitem", "tab", "checkbox", "radio", "switch"].includes(role)) {
        return true;
      }
      if (el.isContentEditable) return true;
      if (el.tabIndex >= 0 && el.tagName !== "BODY") return true;
      return false;
    }

    const root = document.body || document.documentElement;
    if (!root) {
      return { ok: false, error: "The page is still loading." };
    }
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    const elements = [];
    while (elements.length < MAX) {
      const el = walker.nextNode();
      if (!el) break;
      if (!interesting(el) || !visible(el)) continue;
      const rect = el.getBoundingClientRect();
      const label = labelText(el);
      const text = clip(el.innerText || el.value || label || "", 140);
      elements.push({
        tag: el.tagName.toLowerCase(),
        role: clip(el.getAttribute("role"), 40),
        text,
        ariaLabel: clip(el.getAttribute("aria-label"), 120),
        placeholder: clip(el.getAttribute("placeholder"), 80),
        href: clip(el.getAttribute("href"), 300),
        enabled: !el.disabled && el.getAttribute("aria-disabled") !== "true",
        visible: true,
        inputType: clip(el.getAttribute("type"), 24),
        name: clip(el.getAttribute("name"), 40),
        elementId: clip(el.getAttribute("id"), 40),
        className: clip(typeof el.className === "string" ? el.className : "", 80),
        readOnly: !!el.readOnly || el.getAttribute("aria-readonly") === "true",
        contentEditable: !!el.isContentEditable,
        bounds: {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
        },
        path: pathOf(el),
      });
    }

    const bodyText = clip((document.body && document.body.innerText) || "", 2000);
    return {
      ok: true,
      url: String(location.href || ""),
      origin: String(location.origin || ""),
      title: clip(document.title, 200),
      readyState: String(document.readyState || ""),
      lang: clip(document.documentElement.lang, 16),
      untrustedText: bodyText,
      elementCount: elements.length,
      elements,
    };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
})()
