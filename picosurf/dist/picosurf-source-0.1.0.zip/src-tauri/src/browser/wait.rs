use std::time::{Duration, Instant};

use tauri::Webview;

use super::eval::eval_json;
use super::collect_inspect_cancel;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WaitCondition {
    UrlContains,
    TitleContains,
    Ready,
    ElementVisible,
}

pub fn wait_for(
    webview: &Webview,
    condition: WaitCondition,
    value: &str,
    timeout_ms: u64,
    cancelled: impl Fn() -> bool,
) -> Result<String, String> {
    let timeout = Duration::from_millis(timeout_ms.clamp(500, 30_000));
    let needle = value.trim();
    if needle.is_empty() && condition != WaitCondition::Ready {
        return Err("wait_for needs a non-empty value.".into());
    }
    let deadline = Instant::now() + timeout;
    let mut last = String::new();
    while Instant::now() < deadline {
        if cancelled() {
            return Err("Stopped.".into());
        }
        let matched = match condition {
            WaitCondition::UrlContains => {
                let url = read_page_field(webview, "url")?;
                url.to_ascii_lowercase()
                    .contains(&needle.to_ascii_lowercase())
            }
            WaitCondition::TitleContains => {
                let title = read_page_field(webview, "title")?;
                title.to_ascii_lowercase()
                    .contains(&needle.to_ascii_lowercase())
            }
            WaitCondition::Ready => {
                let value = eval_json(
                    webview,
                    r#"(function(){ try { return { ok: true, ready: document.readyState === "complete" }; } catch (e) { return { ok:false, error:String(e)} } })()"#,
                )?;
                value.get("ready").and_then(|v| v.as_bool()).unwrap_or(false)
            }
            WaitCondition::ElementVisible => {
                let id = needle
                    .parse::<u32>()
                    .ok()
                    .filter(|id| *id > 0)
                    .ok_or_else(|| "element condition needs a numeric elementId.".to_string())?;
                let draft = collect_inspect_cancel(webview, &cancelled)?;
                draft.has_visible_element(id)
            }
        };
        if matched {
            return Ok(format!("wait_for satisfied ({needle})."));
        }
        last = read_page_field(webview, "url").unwrap_or_default();
        std::thread::sleep(Duration::from_millis(250));
    }
    Err(format!("Timed out waiting for condition. Last url: {last}"))
}

fn read_page_field(webview: &Webview, field: &str) -> Result<String, String> {
    let script = match field {
        "title" => {
            r#"(function(){ try { return { ok: true, title: String(document.title || "") }; } catch (e) { return { ok:false, error:String(e)}; } })()"#
        }
        _ => {
            r#"(function(){ try { return { ok: true, url: String(location.href || "") }; } catch (e) { return { ok:false, error:String(e)}; } })()"#
        }
    };
    let value = eval_json(webview, script)?;
    Ok(value
        .get(field)
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string())
}
