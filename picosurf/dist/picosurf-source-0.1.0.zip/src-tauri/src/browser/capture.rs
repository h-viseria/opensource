use std::sync::mpsc;

use base64::{engine::general_purpose::STANDARD, Engine as _};
use image::codecs::png::PngEncoder;
use image::{imageops, ExtendedColorType, ImageEncoder, RgbaImage};
use tauri::Webview;
use webview2_com::Microsoft::Web::WebView2::Win32::{
    ICoreWebView2, ICoreWebView2Controller, COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT_PNG,
};
use windows::Win32::Foundation::HGLOBAL;
use windows::Win32::System::Com::StructuredStorage::CreateStreamOnHGlobal;
use windows::Win32::System::Com::{IStream, STATFLAG_DEFAULT, STATSTG};

use super::actions::ScreenshotResult;
use super::eval::eval_json;

pub fn capture(
    webview: &Webview,
    full_page: bool,
    save_dir: Option<&std::path::Path>,
) -> Result<ScreenshotResult, String> {
    let metrics = eval_json(
        webview,
        r#"(function(){
          try {
            return {
              ok: true,
              scrollHeight: Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0),
              viewportWidth: window.innerWidth,
              viewportHeight: window.innerHeight,
              devicePixelRatio: window.devicePixelRatio || 1,
              url: String(location.href || "")
            };
          } catch (err) {
            return { ok: false, error: String((err && err.message) || err) };
          }
        })()"#,
    )?;
    let scroll_height = metrics
        .get("scrollHeight")
        .and_then(|v| v.as_f64())
        .unwrap_or(0.0)
        .round() as i32;
    let viewport_w = metrics
        .get("viewportWidth")
        .and_then(|v| v.as_f64())
        .unwrap_or(0.0)
        .round() as i32;
    let viewport_h = metrics
        .get("viewportHeight")
        .and_then(|v| v.as_f64())
        .unwrap_or(0.0)
        .round() as i32;
    let dpr = metrics
        .get("devicePixelRatio")
        .and_then(|v| v.as_f64())
        .unwrap_or(1.0);
    let url = metrics
        .get("url")
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .to_string();

    if viewport_w < 1 || viewport_h < 1 {
        return Err("Viewport size is not ready.".into());
    }

    let png = if full_page && scroll_height > viewport_h {
        capture_full_page(webview, scroll_height, viewport_h)?
    } else {
        capture_once(webview)?
    };

    let (width, height) = image_dimensions(&png).unwrap_or((viewport_w, viewport_h));
    let mut note = if full_page {
        format!("Captured full page ({width}x{height} PNG).")
    } else {
        format!("Captured viewport ({width}x{height} PNG).")
    };

    let png_base64 = STANDARD.encode(&png);
    if let Some(dir) = save_dir {
        let _ = std::fs::create_dir_all(dir);
        let file = dir.join(format!("agent-{}.png", chrono_like_stamp()));
        if std::fs::write(&file, &png).is_ok() {
            note.push_str(&format!(" Saved to {}.", file.display()));
        }
    }

    Ok(ScreenshotResult {
        width,
        height,
        device_pixel_ratio: dpr,
        url,
        note,
        full_page,
        png_base64: Some(png_base64),
    })
}

fn chrono_like_stamp() -> u128 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0)
}

fn capture_once(webview: &Webview) -> Result<Vec<u8>, String> {
    let (tx, rx) = mpsc::sync_channel(1);
    webview
        .with_webview(move |platform| {
            let result = capture_controller(platform.controller());
            let _ = tx.send(result);
        })
        .map_err(|err| err.to_string())?;
    rx.recv()
        .map_err(|_| "Screenshot failed.".to_string())?
}

fn capture_full_page(webview: &Webview, scroll_height: i32, viewport_h: i32) -> Result<Vec<u8>, String> {
    let mut images: Vec<RgbaImage> = Vec::new();
    let mut y = 0;
    while y < scroll_height {
        let script = format!(
            r#"(function(){{ try {{ window.scrollTo(0, {y}); return {{ ok: true }}; }} catch (err) {{ return {{ ok: false, error: String(err) }}; }} }})()"#
        );
        eval_json(webview, &script)?;
        std::thread::sleep(std::time::Duration::from_millis(120));
        let png = capture_once(webview)?;
        let img = image::load_from_memory(&png)
            .map_err(|err| err.to_string())?
            .to_rgba8();
        images.push(img);
        y += viewport_h;
    }
    stitch_vertical(images)
}

fn stitch_vertical(images: Vec<RgbaImage>) -> Result<Vec<u8>, String> {
    if images.is_empty() {
        return Err("No screenshot tiles.".into());
    }
    if images.len() == 1 {
        return encode_png(&images[0]);
    }
    let width = images.iter().map(|img| img.width()).max().unwrap_or(0);
    let height: u32 = images.iter().map(|img| img.height()).sum();
    let mut canvas = RgbaImage::new(width, height);
    let mut y_offset: i64 = 0;
    for img in &images {
        imageops::overlay(&mut canvas, img, 0, y_offset);
        y_offset += img.height() as i64;
    }
    encode_png(&canvas)
}

fn encode_png(img: &RgbaImage) -> Result<Vec<u8>, String> {
    let mut buf = Vec::new();
    let encoder = PngEncoder::new(&mut buf);
    encoder
        .write_image(img.as_raw(), img.width(), img.height(), ExtendedColorType::Rgba8)
        .map_err(|err| err.to_string())?;
    Ok(buf)
}

fn image_dimensions(png: &[u8]) -> Option<(i32, i32)> {
    let img = image::load_from_memory(png).ok()?;
    Some((img.width() as i32, img.height() as i32))
}

fn capture_controller(controller: ICoreWebView2Controller) -> Result<Vec<u8>, String> {
    let webview = unsafe {
        controller
            .CoreWebView2()
            .map_err(|err| err.to_string())?
    };
    capture_webview(webview)
}

fn capture_webview(webview: ICoreWebView2) -> Result<Vec<u8>, String> {
    unsafe {
        let stream =
            CreateStreamOnHGlobal(HGLOBAL::default(), true).map_err(|err| err.to_string())?;
        let (tx, rx) = mpsc::sync_channel(1);
        let stream_for_read = stream.clone();
        let handler = webview2_com::CapturePreviewCompletedHandler::create(Box::new(
            move |result| {
                let send = (|| -> Result<Vec<u8>, String> {
                    result.map_err(|err| err.to_string())?;
                    read_stream(stream_for_read)
                })();
                let _ = tx.send(send);
                Ok(())
            },
        ));
        webview
            .CapturePreview(
                COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT_PNG,
                &stream,
                &handler,
            )
            .map_err(|err| err.to_string())?;
        rx.recv()
            .map_err(|_| "Screenshot timed out.".to_string())?
    }
}

fn read_stream(stream: IStream) -> Result<Vec<u8>, String> {
    unsafe {
        let mut stat = STATSTG::default();
        stream
            .Stat(&mut stat, STATFLAG_DEFAULT)
            .map_err(|err| err.to_string())?;
        let size = stat.cbSize as usize;
        if size == 0 {
            return Err("Screenshot stream was empty.".into());
        }
        let mut buffer = vec![0u8; size];
        let mut read = 0u32;
        stream
            .Read(
                buffer.as_mut_ptr() as *mut _,
                size as u32,
                Some(&mut read),
            )
            .ok()
            .map_err(|err| err.to_string())?;
        buffer.truncate(read as usize);
        Ok(buffer)
    }
}
