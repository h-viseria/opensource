use tauri::Webview;

use super::eval;

const BOOTSTRAP_JS: &str = include_str!("clean_view.js");

fn wrap(action: &str) -> String {
    format!(
        "(function(){{ {BOOTSTRAP_JS} return window.__picosurfCleanView.{action}(); }})()"
    )
}

pub fn start(webview: &Webview) -> Result<bool, String> {
    let value = eval::eval_json(webview, &wrap("start"))?;
    Ok(value.get("active").and_then(serde_json::Value::as_bool).unwrap_or(false))
}

pub fn stop(webview: &Webview) -> Result<bool, String> {
    let value = eval::eval_json(webview, &wrap("stop"))?;
    Ok(value.get("active").and_then(serde_json::Value::as_bool).unwrap_or(false))
}

pub fn status(webview: &Webview) -> Result<bool, String> {
    let value = eval::eval_json(webview, &wrap("status"))?;
    Ok(value.get("active").and_then(serde_json::Value::as_bool).unwrap_or(false))
}
