use std::collections::HashMap;

use super::actions::{ElementRecord, origin_of};

#[derive(Default)]
pub struct PageSession {
    generation: u64,
    origin: String,
    url: String,
    title: String,
    ready_state: String,
    lang: String,
    untrusted_text: String,
    elements: HashMap<u32, ElementRecord>,
}

impl PageSession {
    pub fn invalidate(&mut self) {
        self.generation = self.generation.saturating_add(1);
        self.elements.clear();
        self.untrusted_text.clear();
        self.origin.clear();
        self.url.clear();
    }

    pub fn replace(
        &mut self,
        url: String,
        title: String,
        ready_state: String,
        lang: String,
        untrusted_text: String,
        records: Vec<ElementRecord>,
    ) {
        self.generation = self.generation.saturating_add(1);
        self.url = url;
        self.origin = origin_of(&self.url);
        self.title = title;
        self.ready_state = ready_state;
        self.lang = lang;
        self.untrusted_text = untrusted_text;
        self.elements.clear();
        for mut record in records {
            record.origin = self.origin.clone();
            record.generation = self.generation;
            self.elements.insert(record.id, record);
        }
    }

    pub fn info(&self) -> super::actions::PageInfo {
        super::actions::PageInfo {
            url: self.url.clone(),
            origin: self.origin.clone(),
            title: self.title.clone(),
            ready_state: self.ready_state.clone(),
            lang: self.lang.clone(),
            untrusted_text: self.untrusted_text.clone(),
            element_count: self.elements.len(),
            generation: self.generation,
        }
    }

    pub fn get(&self, id: u32) -> Result<&ElementRecord, String> {
        self.elements
            .get(&id)
            .ok_or_else(|| "Unknown element. Inspect the page again.".to_string())
    }

    pub fn require(
        &self,
        id: u32,
        generation: u64,
        current_url: &str,
    ) -> Result<&ElementRecord, String> {
        let record = self.get(id)?;
        if record.generation != generation || record.generation != self.generation {
            return Err("Element is from a previous page. Inspect the page again.".into());
        }
        let current_origin = origin_of(current_url);
        if record.origin != current_origin || self.origin != current_origin {
            return Err("The page origin changed. Inspect the page again.".into());
        }
        Ok(record)
    }

    pub fn public_elements(&self) -> Vec<super::actions::PageElement> {
        let mut items: Vec<_> = self.elements.values().map(ElementRecord::public).collect();
        items.sort_by_key(|item| item.id);
        items
    }
}
