#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    picosurf_lib::run();
}
