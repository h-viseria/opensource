use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

use tauri::{AppHandle, Manager, Webview};

use crate::ai::InferenceEngine;
use crate::browser::{self, BrowserState, History, PageSession};
use crate::settings::{self, AppSettings};

pub use crate::settings::AgentLimits;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum PendingNav {
    #[default]
    None,
    New,
    Back,
    Forward,
    Reload,
}

pub struct AppState {
    toolbar_height: Mutex<f64>,
    sidebar_width: Mutex<f64>,
    ai_open: Mutex<bool>,
    title: Mutex<String>,
    history: Mutex<History>,
    pending: Mutex<PendingNav>,
    selected_model: Mutex<Option<String>>,
    page: Mutex<PageSession>,
    engine: Mutex<InferenceEngine>,
    download_cancel: Arc<AtomicBool>,
    inference_stop: Arc<AtomicBool>,
    generating: Mutex<bool>,
    agent_limits: Mutex<AgentLimits>,
    settings: Mutex<AppSettings>,
    clean_view_active: Mutex<bool>,
}

impl Default for AppState {
    fn default() -> Self {
        let inference_stop = Arc::new(AtomicBool::new(false));
        Self {
            toolbar_height: Mutex::new(52.0),
            sidebar_width: Mutex::new(360.0),
            ai_open: Mutex::new(false),
            title: Mutex::new(String::new()),
            history: Mutex::new(History::default()),
            pending: Mutex::new(PendingNav::None),
            selected_model: Mutex::new(None),
            page: Mutex::new(PageSession::default()),
            engine: Mutex::new(InferenceEngine::new(inference_stop.clone())),
            download_cancel: Arc::new(AtomicBool::new(false)),
            inference_stop,
            generating: Mutex::new(false),
            agent_limits: Mutex::new(AgentLimits::default()),
            settings: Mutex::new(AppSettings::default()),
            clean_view_active: Mutex::new(false),
        }
    }
}

impl AppState {
    pub fn browser(&self, app: &AppHandle) -> Result<Option<Webview>, String> {
        Ok(app.get_webview("browser"))
    }

    pub fn window<'a>(&self, app: &'a AppHandle) -> Result<tauri::Window, String> {
        app.get_window("main")
            .ok_or_else(|| "Main window is not ready".to_string())
    }

    pub fn set_layout(&self, toolbar_height: f64, sidebar_width: f64, ai_open: bool) {
        if let Ok(mut value) = self.toolbar_height.lock() {
            *value = toolbar_height.max(40.0);
        }
        if let Ok(mut value) = self.sidebar_width.lock() {
            *value = sidebar_width.max(280.0);
        }
        if let Ok(mut value) = self.ai_open.lock() {
            *value = ai_open;
        }
    }

    pub fn apply_layout(&self, app: &AppHandle) -> Result<(), String> {
        let window = self.window(app)?;
        let Some(browser) = self.browser(app)? else {
            return Ok(());
        };
        let toolbar = *self.toolbar_height.lock().map_err(|err| err.to_string())?;
        let sidebar = *self.sidebar_width.lock().map_err(|err| err.to_string())?;
        let ai_open = *self.ai_open.lock().map_err(|err| err.to_string())?;
        browser::apply_bounds(&window, &browser, toolbar, sidebar, ai_open)
    }

    pub fn snapshot(&self, webview: &Webview) -> BrowserState {
        let history = self.history.lock().ok();
        let title = self.title.lock().ok();
        browser::snapshot(
            webview,
            history.as_deref().unwrap_or(&History::default()),
            title.as_deref().map(String::as_str).unwrap_or(""),
        )
    }

    pub fn set_pending(&self, pending: PendingNav) {
        if let Ok(mut value) = self.pending.lock() {
            *value = pending;
        }
    }

    pub fn on_url_committed(&self, url: &str) {
        self.invalidate_page();
        let pending = self.pending.lock().ok().map(|mut item| std::mem::take(&mut *item));
        let Ok(mut history) = self.history.lock() else {
            return;
        };
        match pending.unwrap_or_default() {
            PendingNav::Back => {
                if history.can_go_back() {
                    history.go_back();
                }
            }
            PendingNav::Forward => {
                if history.can_go_forward() {
                    history.go_forward();
                }
            }
            PendingNav::Reload => {}
            PendingNav::None | PendingNav::New => history.record(url),
        }
    }

    pub fn set_title(&self, title: String) {
        if let Ok(mut value) = self.title.lock() {
            *value = title;
        }
    }

    pub fn invalidate_page(&self) {
        if let Ok(mut page) = self.page.lock() {
            page.invalidate();
        }
    }

    pub fn with_page<T>(&self, f: impl FnOnce(&mut PageSession) -> T) -> Result<T, String> {
        let mut page = self.page.lock().map_err(|err| err.to_string())?;
        Ok(f(&mut page))
    }

    pub fn selected_model(&self) -> Option<String> {
        self.selected_model.lock().ok().and_then(|item| item.clone())
    }

    pub fn set_selected_model(&self, model_id: Option<String>) {
        if let Ok(mut value) = self.selected_model.lock() {
            *value = model_id;
        }
    }

    pub fn loaded_model(&self) -> Option<String> {
        self.engine.lock().ok().and_then(|engine| engine.loaded_id())
    }

    pub fn with_engine<T>(&self, f: impl FnOnce(&mut InferenceEngine) -> T) -> Result<T, String> {
        let mut engine = self.engine.lock().map_err(|err| err.to_string())?;
        Ok(f(&mut engine))
    }

    pub fn download_cancel(&self) -> Arc<AtomicBool> {
        self.download_cancel.clone()
    }

    pub fn begin_download(&self) {
        self.download_cancel.store(false, Ordering::Relaxed);
    }

    pub fn cancel_download(&self) {
        self.download_cancel.store(true, Ordering::Relaxed);
    }

    pub fn request_inference_stop(&self) {
        self.inference_stop.store(true, Ordering::Relaxed);
    }

    pub fn set_generating(&self, value: bool) {
        if let Ok(mut flag) = self.generating.lock() {
            *flag = value;
        }
    }

    pub fn is_generating(&self) -> bool {
        self.generating.lock().ok().map(|flag| *flag).unwrap_or(false)
    }

    pub fn agent_limits(&self) -> AgentLimits {
        self.agent_limits
            .lock()
            .ok()
            .map(|item| *item)
            .unwrap_or_default()
    }

    pub fn set_agent_limits(&self, limits: AgentLimits) -> AgentLimits {
        let limits = limits.clamp();
        if let Ok(mut value) = self.agent_limits.lock() {
            *value = limits;
        }
        if let Ok(mut settings) = self.settings.lock() {
            settings.agent_limits = limits;
        }
        limits
    }

    pub fn settings(&self) -> AppSettings {
        self.settings
            .lock()
            .ok()
            .map(|item| item.clone())
            .unwrap_or_default()
    }

    pub fn apply_settings(&self, settings: AppSettings) -> Result<AppSettings, String> {
        let settings = settings.clamp()?;
        if let Ok(mut value) = self.settings.lock() {
            *value = settings.clone();
        }
        self.set_agent_limits(settings.agent_limits);
        Ok(self.settings())
    }

    pub fn load_settings(&self, app: &AppHandle) {
        let loaded = settings::load(app);
        let _ = self.apply_settings(loaded);
    }

    pub fn persist_settings(&self, app: &AppHandle) -> Result<(), String> {
        settings::save(app, &self.settings())
    }

    pub fn clean_view_active(&self) -> bool {
        self.clean_view_active
            .lock()
            .ok()
            .map(|value| *value)
            .unwrap_or(false)
    }

    pub fn set_clean_view_active(&self, active: bool) {
        if let Ok(mut value) = self.clean_view_active.lock() {
            *value = active;
        }
    }
}
