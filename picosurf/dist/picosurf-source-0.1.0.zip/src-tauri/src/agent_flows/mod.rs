mod schema;

use tauri::AppHandle;

pub use schema::*;

const STORE_FILE: &str = "agent_flows.json";

pub fn load_store(app: &AppHandle) -> Result<AgentFlowStore, String> {
    let path = crate::storage::data_file(app, STORE_FILE)?;
    if !path.is_file() {
        return Ok(AgentFlowStore::default());
    }
    Ok(crate::storage::read_json_or_default(&path))
}

pub fn save_store(app: &AppHandle, store: &AgentFlowStore) -> Result<(), String> {
    let path = crate::storage::data_file(app, STORE_FILE)?;
    crate::storage::write_json(&path, store)
}

pub fn list(app: &AppHandle) -> Result<Vec<AgentFlowSummary>, String> {
    let store = load_store(app)?;
    Ok(store
        .flows
        .iter()
        .map(|flow| AgentFlowSummary {
            id: flow.id.clone(),
            name: flow.name.clone(),
            updated_at: flow.updated_at,
        })
        .collect())
}

pub fn get(app: &AppHandle, id: &str) -> Result<Option<AgentFlow>, String> {
    let store = load_store(app)?;
    Ok(store.flows.iter().find(|flow| flow.id == id).cloned())
}

pub fn upsert(app: &AppHandle, mut flow: AgentFlow) -> Result<AgentFlow, String> {
    flow = flow.normalize()?;
    let mut store = load_store(app)?;
    if let Some(existing) = store.flows.iter_mut().find(|item| item.id == flow.id) {
        flow.created_at = existing.created_at;
        flow.updated_at = now_secs();
        *existing = flow.clone();
    } else {
        flow.created_at = now_secs();
        flow.updated_at = flow.created_at;
        store.flows.push(flow.clone());
    }
    save_store(app, &store)?;
    Ok(flow)
}

pub fn delete(app: &AppHandle, id: &str) -> Result<(), String> {
    let mut store = load_store(app)?;
    let before = store.flows.len();
    store.flows.retain(|flow| flow.id != id);
    if store.flows.len() == before {
        return Err("Flow not found.".into());
    }
    save_store(app, &store)?;
    Ok(())
}

pub fn resolve_active<'a>(settings: &crate::settings::AppSettings, store: &'a AgentFlowStore) -> Option<&'a AgentFlow> {
    if !settings.assistant_mode.is_custom() {
        return None;
    }
    let id = settings.custom_flow_id.as_deref()?;
    store.flows.iter().find(|flow| flow.id == id)
}

fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|item| item.as_secs())
        .unwrap_or(0)
}
