use serde::{Deserialize, Serialize};

pub const SCHEMA_VERSION: u32 = 1;

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct AgentFlowStore {
    #[serde(default)]
    pub flows: Vec<AgentFlow>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentFlowSummary {
    pub id: String,
    pub name: String,
    pub updated_at: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentFlow {
    pub id: String,
    pub name: String,
    #[serde(default = "default_schema_version")]
    pub schema_version: u32,
    #[serde(default)]
    pub created_at: u64,
    #[serde(default)]
    pub updated_at: u64,
    pub config: AgentFlowConfig,
}

fn default_schema_version() -> u32 {
    SCHEMA_VERSION
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentFlowConfig {
    pub pipeline: Vec<PipelineNode>,
    pub discovery: DiscoveryConfig,
    pub sources: SourcesConfig,
    pub extract: ExtractConfig,
    pub synthesize: SynthesizeConfig,
    pub page_agent: PageAgentConfig,
}

impl Default for AgentFlowConfig {
    fn default() -> Self {
        Self {
            pipeline: default_pipeline(),
            discovery: DiscoveryConfig::default(),
            sources: SourcesConfig::default(),
            extract: ExtractConfig::default(),
            synthesize: SynthesizeConfig::default(),
            page_agent: PageAgentConfig::default(),
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub enum PipelineNodeId {
    Discover,
    SelectSites,
    SearchAndVisit,
    Extract,
    PageAgent,
    Synthesize,
    Report,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PipelineNode {
    pub id: PipelineNodeId,
    pub enabled: bool,
    #[serde(default)]
    pub hint: String,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "camelCase")]
pub enum DiscoveryMode {
    #[default]
    OpenWeb,
    PinnedDomainsOnly,
    SearchThenPickSites,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoveryConfig {
    pub mode: DiscoveryMode,
    #[serde(default)]
    pub hint: String,
    #[serde(default)]
    pub query_templates: Vec<String>,
}

impl Default for DiscoveryConfig {
    fn default() -> Self {
        Self {
            mode: DiscoveryMode::SearchThenPickSites,
            hint: String::new(),
            query_templates: vec!["site:{domain} {subject}".into()],
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SourcesConfig {
    #[serde(default)]
    pub pinned_domains: Vec<String>,
    #[serde(default = "default_max_sites")]
    pub max_sites: u32,
}

fn default_max_sites() -> u32 {
    4
}

impl Default for SourcesConfig {
    fn default() -> Self {
        Self {
            pinned_domains: Vec::new(),
            max_sites: default_max_sites(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ExtractField {
    pub label: String,
    #[serde(default)]
    pub hint: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ExtractConfig {
    #[serde(default)]
    pub fields: Vec<ExtractField>,
    #[serde(default)]
    pub hint: String,
}

impl Default for ExtractConfig {
    fn default() -> Self {
        Self {
            fields: vec![ExtractField {
                label: "Key facts".into(),
                hint: "Prices, names, dates, or specs relevant to the task.".into(),
            }],
            hint: String::new(),
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "camelCase")]
pub enum SynthesisFormat {
    #[default]
    Bullets,
    NumberedList,
    ComparisonTable,
    ExecutiveSummary,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SynthesizeConfig {
    pub format: SynthesisFormat,
    #[serde(default)]
    pub hint: String,
    #[serde(default = "default_report_label")]
    pub report_label: String,
}

fn default_report_label() -> String {
    "Custom research".into()
}

impl Default for SynthesizeConfig {
    fn default() -> Self {
        Self {
            format: SynthesisFormat::ComparisonTable,
            hint: String::new(),
            report_label: default_report_label(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PageAgentConfig {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default = "default_true")]
    pub per_site: bool,
    #[serde(default = "default_page_agent_goal")]
    pub goal_template: String,
    #[serde(default)]
    pub hint: String,
}

fn default_true() -> bool {
    true
}

fn default_page_agent_goal() -> String {
    "On {domain}, continue the task: {goal}. Extract: {fields}.".into()
}

impl Default for PageAgentConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            per_site: true,
            goal_template: default_page_agent_goal(),
            hint: String::new(),
        }
    }
}

pub fn default_pipeline() -> Vec<PipelineNode> {
    vec![
        node(PipelineNodeId::Discover, true, "Find relevant websites from the open web."),
        node(PipelineNodeId::SelectSites, true, "Pick specialist sites from search results."),
        node(PipelineNodeId::SearchAndVisit, true, "Run scoped searches and open pages."),
        node(PipelineNodeId::Extract, true, "Read page text from each visit."),
        node(PipelineNodeId::PageAgent, false, "Optional in-page actions on each site."),
        node(PipelineNodeId::Synthesize, true, "Compare evidence and write the report."),
        node(PipelineNodeId::Report, true, "Publish a local HTML report."),
    ]
}

fn node(id: PipelineNodeId, enabled: bool, hint: &str) -> PipelineNode {
    PipelineNode {
        id,
        enabled,
        hint: hint.into(),
    }
}

impl AgentFlow {
    pub fn normalize(mut self) -> Result<Self, String> {
        self.name = self.name.trim().chars().take(80).collect();
        if self.name.len() < 2 {
            return Err("Flow name must be at least 2 characters.".into());
        }
        if self.id.trim().is_empty() {
            self.id = uuid();
        }
        self.schema_version = SCHEMA_VERSION;
        self.config.discovery.hint = trim_hint(&self.config.discovery.hint, 240);
        self.config.extract.hint = trim_hint(&self.config.extract.hint, 240);
        self.config.synthesize.hint = trim_hint(&self.config.synthesize.hint, 240);
        self.config.page_agent.hint = trim_hint(&self.config.page_agent.hint, 240);
        self.config.synthesize.report_label = self
            .config
            .synthesize
            .report_label
            .trim()
            .chars()
            .take(48)
            .collect();
        if self.config.synthesize.report_label.is_empty() {
            self.config.synthesize.report_label = default_report_label();
        }
        self.config.sources.max_sites = self.config.sources.max_sites.clamp(1, 8);
        self.config.sources.pinned_domains = self
            .config
            .sources
            .pinned_domains
            .iter()
            .filter_map(|raw| crate::research::normalize_site(raw))
            .collect();
        self.config.sources.pinned_domains.dedup();
        for domain in crate::research::extract_domains_from_text(&self.config.discovery.hint) {
            if !self.config.sources.pinned_domains.contains(&domain) {
                self.config.sources.pinned_domains.push(domain);
            }
        }
        self.config.sources.pinned_domains.dedup();
        if self.config.discovery.mode == DiscoveryMode::PinnedDomainsOnly
            && self.config.sources.pinned_domains.is_empty()
        {
            return Err("Pinned domains mode requires at least one domain.".into());
        }
        self.config.discovery.query_templates = self
            .config
            .discovery
            .query_templates
            .iter()
            .map(|item| item.trim().chars().take(120).collect::<String>())
            .filter(|item| !item.is_empty())
            .take(6)
            .collect();
        if self.config.discovery.query_templates.is_empty() {
            self.config.discovery.query_templates = vec!["{goal}".into()];
        }
        self.config.extract.fields = self
            .config
            .extract
            .fields
            .iter()
            .map(|field| ExtractField {
                label: field.label.trim().chars().take(40).collect(),
                hint: field.hint.trim().chars().take(120).collect(),
            })
            .filter(|field| field.label.len() >= 2)
            .take(12)
            .collect();
        if self.config.extract.fields.is_empty() {
            self.config.extract = ExtractConfig::default();
        }
        if self.config.pipeline.is_empty() {
            self.config.pipeline = default_pipeline();
        }
        for node in &mut self.config.pipeline {
            node.hint = trim_hint(&node.hint, 200);
        }
        Ok(self)
    }

    pub fn node_enabled(&self, id: PipelineNodeId) -> bool {
        self.config
            .pipeline
            .iter()
            .find(|node| node.id == id)
            .map(|node| node.enabled)
            .unwrap_or(true)
    }

    pub fn node_hint(&self, id: PipelineNodeId) -> Option<&str> {
        self.config
            .pipeline
            .iter()
            .find(|node| node.id == id)
            .map(|node| node.hint.as_str())
            .filter(|hint| !hint.is_empty())
    }

    pub fn effective_pinned_domains(&self) -> Vec<String> {
        let mut out = self.config.sources.pinned_domains.clone();
        for domain in crate::research::extract_domains_from_text(&self.config.discovery.hint) {
            if !out.contains(&domain) {
                out.push(domain);
            }
        }
        if let Some(hint) = self.node_hint(PipelineNodeId::SelectSites) {
            for domain in crate::research::extract_domains_from_text(hint) {
                if !out.contains(&domain) {
                    out.push(domain);
                }
            }
        }
        out.truncate(self.config.sources.max_sites as usize);
        out
    }
}

fn trim_hint(raw: &str, max: usize) -> String {
    raw.trim().chars().take(max).collect()
}

fn uuid() -> String {
    format!(
        "flow-{}",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|item| item.as_nanos())
            .unwrap_or(0)
    )
}

impl AgentFlow {
    pub fn new_named(name: &str) -> Self {
        Self {
            id: uuid(),
            name: name.to_string(),
            schema_version: SCHEMA_VERSION,
            created_at: 0,
            updated_at: 0,
            config: AgentFlowConfig::default(),
        }
    }
}
