use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};
use tauri::AppHandle;
use url::Url;

use crate::storage;

const MAX_ENTRIES: usize = 500;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct DownloadEntry {
    pub id: String,
    pub source_url: String,
    pub file_name: String,
    pub file_path: String,
    pub domain: String,
    pub downloaded_at: u64,
}

pub fn file_path(app: &AppHandle) -> Result<PathBuf, String> {
    storage::data_file(app, "download-log.json")
}

pub fn load(path: &Path) -> Vec<DownloadEntry> {
    storage::read_json_or_default::<Vec<DownloadEntry>>(path)
}

pub fn store(path: &Path, entries: &[DownloadEntry]) -> Result<(), String> {
    storage::write_json(path, &entries.to_vec())
}

pub fn resolve_destination(
    download_dir: &Path,
    proposed: &Path,
    source_url: &Url,
) -> PathBuf {
    let file_name = proposed
        .file_name()
        .map(|name| name.to_os_string())
        .or_else(|| {
            source_url
                .path_segments()
                .and_then(|segments| segments.last())
                .map(|segment| segment.into())
        })
        .unwrap_or_else(|| "download".into());
    unique_path(download_dir.join(file_name))
}

pub fn record(app: &AppHandle, source_url: &str, saved_path: &Path) -> Result<(), String> {
    let path = file_path(app)?;
    let mut entries = load(&path);
    let file_name = saved_path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("download")
        .to_string();
    let domain = Url::parse(source_url)
        .ok()
        .and_then(|item| item.host_str().map(str::to_string))
        .unwrap_or_default();
    let now = now_unix();
    entries.insert(
        0,
        DownloadEntry {
            id: format!("download-{now}"),
            source_url: source_url.to_string(),
            file_name,
            file_path: saved_path.to_string_lossy().into_owned(),
            domain,
            downloaded_at: now,
        },
    );
    entries.truncate(MAX_ENTRIES);
    store(&path, &entries)
}

pub fn list(app: &AppHandle, limit: usize) -> Result<Vec<DownloadEntry>, String> {
    let entries = load(&file_path(app)?);
    Ok(entries.into_iter().take(limit.clamp(1, 100)).collect())
}

pub fn clear(app: &AppHandle) -> Result<(), String> {
    store(&file_path(app)?, &Vec::new())
}

fn unique_path(mut dest: PathBuf) -> PathBuf {
    if !dest.exists() {
        return dest;
    }
    let parent = dest
        .parent()
        .map(Path::to_path_buf)
        .unwrap_or_else(|| PathBuf::from("."));
    let stem = dest
        .file_stem()
        .and_then(|name| name.to_str())
        .unwrap_or("download")
        .to_string();
    let ext = dest
        .extension()
        .and_then(|name| name.to_str())
        .map(|name| format!(".{name}"))
        .unwrap_or_default();
    for index in 1..100 {
        let candidate = parent.join(format!("{stem} ({index}){ext}"));
        if !candidate.exists() {
            dest = candidate;
            return dest;
        }
    }
    dest
}

fn now_unix() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|item| item.as_secs())
        .unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn picks_unique_name_when_file_exists() {
        let dir = std::env::temp_dir().join(format!("picosurf-dl-{}", now_unix()));
        let _ = std::fs::create_dir_all(&dir);
        let existing = dir.join("report.pdf");
        let _ = std::fs::write(&existing, b"x");
        let resolved = resolve_destination(&dir, Path::new("report.pdf"), &Url::parse("https://example.com/report.pdf").unwrap());
        assert_ne!(resolved, existing);
        assert!(resolved.to_string_lossy().contains("(1)"));
        let _ = std::fs::remove_dir_all(dir);
    }
}
