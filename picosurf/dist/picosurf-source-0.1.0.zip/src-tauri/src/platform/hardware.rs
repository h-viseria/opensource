use std::path::Path;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HardwareInfo {
    pub os: String,
    pub arch: String,
    pub ram_bytes: u64,
    pub ram_label: String,
    pub cpu_cores: u32,
    pub storage_free_bytes: u64,
    pub storage_label: String,
}

pub fn probe(storage_dir: &Path) -> HardwareInfo {
    let ram_bytes = physical_ram_bytes();
    let storage_free_bytes = free_space_bytes(storage_dir);
    HardwareInfo {
        os: std::env::consts::OS.to_string(),
        arch: std::env::consts::ARCH.to_string(),
        ram_bytes,
        ram_label: format_bytes(ram_bytes),
        cpu_cores: std::thread::available_parallelism()
            .map(|value| value.get() as u32)
            .unwrap_or(1),
        storage_free_bytes,
        storage_label: format_bytes(storage_free_bytes),
    }
}

/// Recommend the 7B catalogue entry only on machines with enough RAM.
pub fn recommend_large_model(ram_bytes: u64) -> bool {
    ram_bytes >= 16 * 1024 * 1024 * 1024
}

pub fn format_bytes(bytes: u64) -> String {
    const GB: f64 = 1024.0 * 1024.0 * 1024.0;
    const MB: f64 = 1024.0 * 1024.0;
    if bytes >= (GB as u64) {
        format!("{:.1} GB", bytes as f64 / GB)
    } else {
        format!("{:.0} MB", bytes as f64 / MB)
    }
}

#[cfg(windows)]
fn physical_ram_bytes() -> u64 {
    #[repr(C)]
    struct MemoryStatusEx {
        length: u32,
        memory_load: u32,
        total_phys: u64,
        avail_phys: u64,
        total_page_file: u64,
        avail_page_file: u64,
        total_virtual: u64,
        avail_virtual: u64,
        avail_extended_virtual: u64,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn GlobalMemoryStatusEx(status: *mut MemoryStatusEx) -> i32;
    }

    unsafe {
        let mut status = std::mem::zeroed::<MemoryStatusEx>();
        status.length = std::mem::size_of::<MemoryStatusEx>() as u32;
        if GlobalMemoryStatusEx(&mut status) != 0 {
            status.total_phys
        } else {
            0
        }
    }
}

#[cfg(not(windows))]
fn physical_ram_bytes() -> u64 {
    0
}

#[cfg(windows)]
fn free_space_bytes(dir: &Path) -> u64 {
    use std::os::windows::ffi::OsStrExt;

    #[link(name = "kernel32")]
    extern "system" {
        fn GetDiskFreeSpaceExW(
            directory: *const u16,
            free_bytes_available: *mut u64,
            total_number_of_bytes: *mut u64,
            total_number_of_free_bytes: *mut u64,
        ) -> i32;
    }

    let mut wide: Vec<u16> = dir.as_os_str().encode_wide().collect();
    wide.push(0);
    let mut available = 0u64;
    unsafe {
        if GetDiskFreeSpaceExW(wide.as_ptr(), &mut available, std::ptr::null_mut(), std::ptr::null_mut())
            != 0
        {
            available
        } else {
            0
        }
    }
}

#[cfg(not(windows))]
fn free_space_bytes(_dir: &Path) -> u64 {
    0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn large_model_needs_16gb() {
        assert!(!recommend_large_model(8 * 1024 * 1024 * 1024));
        assert!(recommend_large_model(16 * 1024 * 1024 * 1024));
    }
}
