#[cfg(windows)]
mod windows;
pub mod hardware;

#[cfg(windows)]
pub use windows::ensure_webview2;

#[cfg(not(windows))]
pub fn ensure_webview2() -> Result<(), String> {
    Ok(())
}
