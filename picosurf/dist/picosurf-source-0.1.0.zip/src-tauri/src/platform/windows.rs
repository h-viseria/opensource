use std::fs;
use std::io::copy;
use std::path::{Path, PathBuf};
use std::process::Command;

use rfd::{MessageButtons, MessageDialog, MessageDialogResult, MessageLevel};
use winreg::enums::{HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE};
use winreg::RegKey;

use crate::storage;

const WEBVIEW2_GUID: &str = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";
const BOOTSTRAPPER_URL: &str = "https://go.microsoft.com/fwlink/p/?LinkId=2124703";
const DOWNLOAD_PAGE: &str = "https://developer.microsoft.com/microsoft-edge/webview2/";

pub fn ensure_webview2() -> Result<(), String> {
    apply_fixed_runtime_if_present();
    if webview2_ready() {
        return Ok(());
    }

    loop {
        match prompt() {
            MessageDialogResult::Yes => {
                download_and_run_bootstrapper()?;
            }
            MessageDialogResult::No => {
                open_in_browser(DOWNLOAD_PAGE)?;
            }
            _ => return Err("WebView2 is required to run PicoSurf.".into()),
        }

        apply_fixed_runtime_if_present();
        if webview2_ready() {
            return Ok(());
        }

        let again = MessageDialog::new()
            .set_level(MessageLevel::Warning)
            .set_title("PicoSurf")
            .set_description("WebView2 is still missing. Install it, or place a Fixed Version runtime folder next to PicoSurf.exe, then retry.")
            .set_buttons(MessageButtons::OkCancel)
            .show();
        if again != MessageDialogResult::Ok {
            return Err("WebView2 is required to run PicoSurf.".into());
        }
    }
}

fn prompt() -> MessageDialogResult {
    MessageDialog::new()
        .set_level(MessageLevel::Warning)
        .set_title("PicoSurf needs WebView2")
        .set_description("PicoSurf uses the Windows WebView2 runtime to display pages. It is not installed for this user.\n\nYes: download Microsoft's installer (no admin needed for a per-user install).\nNo: open the Microsoft download page.\nCancel: quit.\n\nYou can also unzip a WebView2 Fixed Version folder next to PicoSurf.exe or under %LOCALAPPDATA%\\PicoSurf\\webview2.")
        .set_buttons(MessageButtons::YesNoCancel)
        .show()
}

fn webview2_ready() -> bool {
    if let Ok(path) = std::env::var("WEBVIEW2_BROWSER_EXECUTABLE_FOLDER") {
        if runtime_looks_valid(Path::new(&path)) {
            return true;
        }
    }
    registry_installed()
}

fn registry_installed() -> bool {
    const PATHS: [&str; 2] = [
        r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\",
        r"SOFTWARE\Microsoft\EdgeUpdate\Clients\",
    ];
    let hives = [HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER];
    for hive in hives {
        for prefix in PATHS {
            let path = format!("{prefix}{WEBVIEW2_GUID}");
            if let Ok(key) = RegKey::predef(hive).open_subkey(path) {
                if key.get_value::<String, _>("pv").ok().filter(|v| !v.is_empty() && v != "0.0.0.0").is_some() {
                    return true;
                }
                return true;
            }
        }
    }
    false
}

fn apply_fixed_runtime_if_present() {
    if let Some(path) = find_fixed_runtime() {
        std::env::set_var("WEBVIEW2_BROWSER_EXECUTABLE_FOLDER", path);
    }
}

fn find_fixed_runtime() -> Option<PathBuf> {
    if let Ok(value) = std::env::var("WEBVIEW2_BROWSER_EXECUTABLE_FOLDER") {
        let path = PathBuf::from(value);
        if runtime_looks_valid(&path) {
            return Some(path);
        }
    }

    let mut roots = Vec::new();
    if let Ok(exe) = std::env::current_exe() {
        if let Some(parent) = exe.parent() {
            roots.push(parent.to_path_buf());
        }
    }
    if let Some(data) = storage::app_data_dir() {
        roots.push(data.join("webview2"));
        roots.push(data);
    }

    for root in roots {
        let direct = root.join("webview2");
        if runtime_looks_valid(&direct) {
            return Some(direct);
        }
        if runtime_looks_valid(&root) {
            return Some(root);
        }
        if let Ok(entries) = fs::read_dir(&root) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.is_dir() {
                    let name = entry.file_name().to_string_lossy().to_lowercase();
                    if name.contains("webview2") && runtime_looks_valid(&path) {
                        return Some(path);
                    }
                }
            }
        }
    }
    None
}

fn runtime_looks_valid(dir: &Path) -> bool {
    dir.join("msedgewebview2.exe").is_file()
}

fn download_and_run_bootstrapper() -> Result<(), String> {
    let path = std::env::temp_dir().join("MicrosoftEdgeWebview2Setup.exe");
    let mut reader = ureq::get(BOOTSTRAPPER_URL)
        .call()
        .map_err(|err| format!("Could not download WebView2 installer: {err}"))?
        .into_reader();
    let mut file = fs::File::create(&path).map_err(|err| err.to_string())?;
    copy(&mut reader, &mut file).map_err(|err| err.to_string())?;
    drop(file);

    let status = Command::new(&path)
        .arg("/install")
        .status()
        .map_err(|err| format!("Could not start WebView2 installer: {err}"))?;
    if !status.success() {
        return Err("WebView2 installer did not finish successfully.".into());
    }
    Ok(())
}

fn open_in_browser(url: &str) -> Result<(), String> {
    Command::new("cmd")
        .args(["/C", "start", "", url])
        .spawn()
        .map_err(|err| format!("Could not open browser: {err}"))?;
    Ok(())
}
