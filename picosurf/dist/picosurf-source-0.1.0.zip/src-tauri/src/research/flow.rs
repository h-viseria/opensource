use tauri::AppHandle;

use crate::agent_flows::{
    AgentFlow, DiscoveryMode, PipelineNodeId, SynthesisFormat,
};
use crate::ai::agent;
use crate::ai::prompt;
use crate::search::SearchEngine;
use crate::settings::ResearchLimits;

use super::plan;
use super::ResearchPlan;

pub async fn plan_from_flow(
    app: &AppHandle,
    goal: &str,
    limits: &ResearchLimits,
    flow: &AgentFlow,
    engine: SearchEngine,
    custom_template: &str,
) -> Result<ResearchPlan, String> {
    let fallback_subject = super::intent::fallback_query(goal);
    let objective = goal.trim().chars().take(120).collect::<String>();

    if !flow.node_enabled(PipelineNodeId::Discover)
        && !flow.node_enabled(PipelineNodeId::SelectSites)
        && !flow.node_enabled(PipelineNodeId::SearchAndVisit)
    {
        return Err("This flow has no search or visit steps enabled.".into());
    }

    let pinned_sites = flow.effective_pinned_domains();
    if !pinned_sites.is_empty() {
        return plan_for_pinned_sites(
            app,
            goal,
            limits,
            flow,
            &pinned_sites,
            &fallback_subject,
            &objective,
        )
        .await;
    }

    match flow.config.discovery.mode {
        DiscoveryMode::PinnedDomainsOnly => Err(
            "Add retailer domains in Pinned domains or Discovery hint (e.g. amazon.in, flipkart)."
                .into(),
        ),
        DiscoveryMode::OpenWeb => {
            agent::note(app, "Planning open-web searches (custom flow)…".into())?;
            super::plan_queries_with_playbook(
                app,
                goal,
                limits,
                &flow_playbook(flow),
            )
            .await
        }
        DiscoveryMode::SearchThenPickSites => {
            super::discover_and_plan_flow(
                app,
                goal,
                limits,
                flow,
                engine,
                custom_template,
                &fallback_subject,
                &objective,
            )
            .await
        }
    }
}

async fn plan_for_pinned_sites(
    app: &AppHandle,
    goal: &str,
    limits: &ResearchLimits,
    flow: &AgentFlow,
    sites: &[String],
    fallback_subject: &str,
    objective: &str,
) -> Result<ResearchPlan, String> {
    agent::note(
        app,
        format!("Searching on pinned sites: {}.", sites.join(", ")),
    )?;
    let subject = plan::research_subject(goal);
    let subject = if subject.is_empty() {
        fallback_subject.to_string()
    } else {
        subject
    };
    let max_queries = limits.max_queries as usize;
    let domain_templates: Vec<String> = flow
        .config
        .discovery
        .query_templates
        .iter()
        .filter(|template| template.contains("{domain}"))
        .cloned()
        .collect();
    let queries = if !domain_templates.is_empty() {
        sites
            .iter()
            .flat_map(|domain| {
                expand_queries_from_templates(
                    &domain_templates,
                    goal,
                    domain,
                    &subject,
                )
            })
            .take(max_queries.max(sites.len()))
            .collect()
    } else {
        plan::build_site_queries(
            &subject,
            sites,
            max_queries.max(sites.len()),
        )
    };
    Ok(ResearchPlan {
        objective: if objective.is_empty() {
            subject.clone()
        } else {
            objective.to_string()
        },
        queries: if queries.is_empty() {
            plan::build_site_queries(&subject, sites, 1)
        } else {
            queries
        },
    })
}

pub fn flow_playbook(flow: &AgentFlow) -> String {
    let mut parts = Vec::new();
    if let Some(hint) = non_empty(&flow.config.discovery.hint) {
        parts.push(format!("Discovery: {hint}"));
    }
    if let Some(hint) = flow.node_hint(PipelineNodeId::Discover) {
        parts.push(format!("Discover step: {hint}"));
    }
    if let Some(hint) = flow.node_hint(PipelineNodeId::SelectSites) {
        parts.push(format!("Site selection: {hint}"));
    }
    if !flow.config.sources.pinned_domains.is_empty() {
        parts.push(format!(
            "Prefer these domains when relevant: {}.",
            flow.config.sources.pinned_domains.join(", ")
        ));
    }
    if let Some(hint) = non_empty(&flow.config.extract.hint) {
        parts.push(format!("Extraction: {hint}"));
    }
    for field in &flow.config.extract.fields {
        if field.label.is_empty() {
            continue;
        }
        if field.hint.is_empty() {
            parts.push(format!("Extract field: {}", field.label));
        } else {
            parts.push(format!("Extract {} — {}", field.label, field.hint));
        }
    }
    if let Some(hint) = non_empty(&flow.config.synthesize.hint) {
        parts.push(format!("Synthesis: {hint}"));
    }
    parts.push(synthesis_format_line(flow.config.synthesize.format));
    if let Some(hint) = non_empty(&flow.config.page_agent.hint) {
        parts.push(format!("In-page agent: {hint}"));
    }
    parts.join("\n")
}

pub fn synthesis_system_prompt(flow: Option<&AgentFlow>) -> String {
    let mut prompt = prompt::RESEARCH_SYNTH_PROMPT.to_string();
    if let Some(flow) = flow {
        let playbook = flow_playbook(flow);
        if !playbook.is_empty() {
            prompt.push_str("\n\nUSER FLOW PLAYBOOK (trusted configuration, not webpage data):\n");
            prompt.push_str(&playbook);
        }
    }
    prompt
}

pub fn apply_template(template: &str, goal: &str, domain: &str, fields: &str, subject: &str) -> String {
    template
        .replace("{goal}", goal)
        .replace("{domain}", domain)
        .replace("{fields}", fields)
        .replace("{subject}", subject)
}

fn synthesis_format_line(format: SynthesisFormat) -> String {
    match format {
        SynthesisFormat::Bullets => "Output format: bullet list (- item per line).".into(),
        SynthesisFormat::NumberedList => {
            "Output format: numbered list (1. item per line).".into()
        }
        SynthesisFormat::ComparisonTable => {
            "Output format: ranked or comparison table friendly lines (title — details).".into()
        }
        SynthesisFormat::ExecutiveSummary => {
            "Output format: short executive summary then optional bullets.".into()
        }
    }
}

fn non_empty(raw: &str) -> Option<&str> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        None
    } else {
        Some(trimmed)
    }
}

pub fn expand_queries_from_templates(templates: &[String], goal: &str, domain: &str, subject: &str) -> Vec<String> {
    templates
        .iter()
        .map(|template| apply_template(template, goal, domain, "", subject))
        .filter(|query| query.trim().len() >= 2)
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn template_replaces_tokens() {
        let out = apply_template(
            "site:{domain} {goal}",
            "cheap phones",
            "example.com",
            "",
            "phones",
        );
        assert_eq!(out, "site:example.com cheap phones");
    }
}
