use crate::search::SearchResult;
use crate::settings::ResearchLimits;

/// Hostnames that are search engines, social platforms, or generic aggregators — not primary sources.
pub fn is_noise_domain(host: &str) -> bool {
    let host = host.trim().to_ascii_lowercase();
    let host = host.strip_prefix("www.").unwrap_or(&host);
    const NOISE: &[&str] = &[
        "google.com",
        "google.co.in",
        "google.ae",
        "google.co.uk",
        "bing.com",
        "duckduckgo.com",
        "search.brave.com",
        "brave.com",
        "yahoo.com",
        "yandex.com",
        "baidu.com",
        "facebook.com",
        "twitter.com",
        "x.com",
        "instagram.com",
        "youtube.com",
        "reddit.com",
        "pinterest.com",
        "linkedin.com",
        "tiktok.com",
        "wikipedia.org",
        "wikimedia.org",
        "quora.com",
        "medium.com",
    ];
    NOISE.iter().any(|noise| host == *noise || host.ends_with(&format!(".{noise}")))
}

pub fn research_subject(goal: &str) -> String {
    let mut subject = goal.trim().to_string();
    let lower = subject.to_ascii_lowercase();
    for prefix in [
        "search for ",
        "find ",
        "lookup ",
        "look up ",
        "compare ",
        "price of ",
        "buy ",
    ] {
        if lower.starts_with(prefix) {
            subject = subject[prefix.len()..].trim().to_string();
            break;
        }
    }
    subject.chars().take(80).collect()
}

pub fn extract_domains_from_text(text: &str) -> Vec<String> {
    let mut out = Vec::new();
    let lower = text.to_ascii_lowercase();
    for token in lower.split(|c: char| c == ',' || c == ';' || c == '\n') {
        for piece in token.split(" and ") {
            let piece = piece
                .trim()
                .trim_start_matches("find in ")
                .trim_start_matches("search in ")
                .trim_start_matches("search on ")
                .trim_start_matches("on ");
            if let Some(domain) = token_to_domain(piece) {
                push_domain(&mut out, domain);
            }
        }
    }
    out
}

fn token_to_domain(token: &str) -> Option<String> {
    let token = token
        .trim()
        .trim_matches(|c: char| ",.;:!?\"'()[]".contains(c));
    if token.is_empty() {
        return None;
    }
    if let Some(host) = normalize_site(token) {
        return Some(host);
    }
    if !token.contains('.')
        && token.len() >= 5
        && token
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '-')
    {
        for tld in ["com", "in", "co.in"] {
            if let Some(host) = normalize_site(&format!("{token}.{tld}")) {
                return Some(host);
            }
        }
    }
    None
}

fn push_domain(out: &mut Vec<String>, domain: String) {
    if is_noise_domain(&domain) {
        return;
    }
    if out.iter().any(|item| item == &domain) {
        return;
    }
    out.push(domain);
}

pub fn normalize_site(raw: &str) -> Option<String> {
    let mut host = raw
        .trim()
        .trim_start_matches("https://")
        .trim_start_matches("http://")
        .trim_start_matches("www.")
        .split('/')
        .next()
        .unwrap_or("")
        .to_ascii_lowercase();
    host = host.trim_start_matches("www.").to_string();
    if host.is_empty() || host.contains(' ') || !host.contains('.') {
        return None;
    }
    Some(host)
}

pub fn domain_from_result(result: &SearchResult) -> Option<String> {
    normalize_site(&result.domain).or_else(|| {
        url::Url::parse(&result.url)
            .ok()
            .and_then(|parsed| parsed.host_str().map(normalize_site))
            .flatten()
    })
}

pub fn domains_from_results(results: &[SearchResult], max: usize) -> Vec<String> {
    let mut out = Vec::new();
    for result in results {
        let Some(domain) = domain_from_result(result) else {
            continue;
        };
        if is_noise_domain(&domain) {
            continue;
        }
        if out.iter().any(|item: &String| item == &domain) {
            continue;
        }
        out.push(domain);
        if out.len() >= max {
            break;
        }
    }
    out
}

pub fn heuristic_discovery_queries(goal: &str, category_hint: Option<&str>) -> Vec<String> {
    let topic = research_subject(goal);
    if topic.is_empty() {
        return Vec::new();
    }
    if category_hint
        .map(extract_domains_from_text)
        .is_some_and(|domains| !domains.is_empty())
    {
        return Vec::new();
    }
    let prefix = category_hint
        .map(str::trim)
        .filter(|hint| !hint.is_empty())
        .unwrap_or("best websites for");
    vec![
        format!("{prefix} {topic}"),
        format!("{topic} official comparison review sites"),
    ]
}

pub fn parse_discovery_queries(value: &serde_json::Value, limits: &ResearchLimits) -> Vec<String> {
    let max = limits.max_queries.min(2).max(1) as usize;
    value
        .get("queries")
        .and_then(serde_json::Value::as_array)
        .cloned()
        .unwrap_or_default()
        .into_iter()
        .filter_map(|item| {
            item.as_str()
                .map(str::trim)
                .filter(|query| query.len() >= 4)
                .map(|query| query.chars().take(120).collect::<String>())
        })
        .take(max)
        .collect()
}

pub fn format_results_for_llm(results: &[SearchResult], max: usize) -> String {
    results
        .iter()
        .take(max)
        .enumerate()
        .filter_map(|(index, result)| {
            let domain = domain_from_result(result)?;
            Some(format!(
                "[{}] {} — {}\n    {}",
                index + 1,
                domain,
                result.title.chars().take(100).collect::<String>(),
                result.snippet.chars().take(160).collect::<String>()
            ))
        })
        .collect::<Vec<_>>()
        .join("\n")
}

pub fn parse_site_pick(
    value: &serde_json::Value,
    results: &[SearchResult],
    fallback_subject: &str,
    max_sites: usize,
) -> (String, Vec<String>) {
    let subject = value
        .get("subject")
        .and_then(serde_json::Value::as_str)
        .map(str::trim)
        .filter(|item| item.len() >= 2)
        .map(|item| item.chars().take(48).collect::<String>())
        .unwrap_or_else(|| fallback_subject.to_string());

    let candidate_domains = domains_from_results(results, 24);
    let mut sites: Vec<String> = value
        .get("sites")
        .and_then(serde_json::Value::as_array)
        .cloned()
        .unwrap_or_default()
        .into_iter()
        .filter_map(|item| item.as_str().map(normalize_site))
        .flatten()
        .filter(|domain| !is_noise_domain(domain))
        .filter(|domain| {
            candidate_domains.is_empty()
                || candidate_domains.iter().any(|candidate| candidate == domain)
        })
        .collect();
    sites.dedup();
    if sites.is_empty() {
        sites = heuristic_pick_sites(results, max_sites);
    } else {
        sites.truncate(max_sites);
    }
    (subject, sites)
}

pub fn heuristic_pick_sites(results: &[SearchResult], max: usize) -> Vec<String> {
    domains_from_results(results, max)
}

pub fn host_matches_site(expected: &str, actual: &str) -> bool {
    let expected = expected.trim().to_ascii_lowercase();
    let actual = actual.trim().to_ascii_lowercase();
    if expected.is_empty() || actual.is_empty() {
        return false;
    }
    expected == actual || actual.ends_with(&format!(".{expected}"))
}

pub fn site_from_scoped_query(query: &str) -> Option<String> {
    let query = query.trim();
    let rest = query.strip_prefix("site:")?;
    let site = rest.split_whitespace().next()?.trim();
    normalize_site(site)
}

pub fn build_site_queries(subject: &str, sites: &[String], max_queries: usize) -> Vec<String> {
    let subject = subject.trim();
    if subject.is_empty() || sites.is_empty() || max_queries == 0 {
        return Vec::new();
    }
    sites
        .iter()
        .take(max_queries)
        .map(|site| format!("site:{site} {subject}"))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_result(domain: &str, title: &str) -> SearchResult {
        SearchResult {
            title: title.into(),
            url: format!("https://{domain}/page"),
            snippet: title.into(),
            domain: domain.into(),
            position: 1,
        }
    }

    #[test]
    fn filters_search_engine_domains() {
        assert!(is_noise_domain("www.google.com"));
        assert!(!is_noise_domain("cardekho.com"));
    }

    #[test]
    fn extracts_domains_from_results() {
        let results = vec![
            sample_result("google.com", "search"),
            sample_result("cardekho.com", "Car prices"),
            sample_result("carwale.com", "Car deals"),
        ];
        let domains = domains_from_results(&results, 4);
        assert_eq!(domains, vec!["cardekho.com", "carwale.com"]);
    }

    #[test]
    fn builds_site_scoped_queries() {
        let queries = build_site_queries(
            "cheapest car",
            &["cardekho.com".into(), "carwale.com".into()],
            3,
        );
        assert_eq!(queries[0], "site:cardekho.com cheapest car");
        assert_eq!(queries[1], "site:carwale.com cheapest car");
    }

    #[test]
    fn site_pick_prefers_model_domains_from_results() {
        let results = vec![
            sample_result("flipkart.com", "phones"),
            sample_result("cardekho.com", "cars"),
        ];
        let value = serde_json::json!({
            "subject": "car",
            "sites": ["cardekho.com", "unknown.example"]
        });
        let (subject, sites) = parse_site_pick(&value, &results, "fallback", 4);
        assert_eq!(subject, "car");
        assert_eq!(sites, vec!["cardekho.com"]);
    }

    #[test]
    fn extracts_domains_from_discovery_hint() {
        let domains = extract_domains_from_text(
            "Find in amazon.in, flipkart and jiomart",
        );
        assert!(domains.contains(&"amazon.in".into()));
        assert!(domains.iter().any(|d| d.contains("flipkart")));
        assert!(domains.iter().any(|d| d.contains("jiomart")));
    }

    #[test]
    fn research_subject_strips_search_for() {
        assert_eq!(research_subject("search for moto g32"), "moto g32");
    }

    #[test]
    fn discovery_queries_from_json() {
        let limits = ResearchLimits::default();
        let queries = parse_discovery_queries(
            &serde_json::json!({"queries":["best car sites India","car price portals India"]}),
            &limits,
        );
        assert_eq!(queries.len(), 2);
    }
}
