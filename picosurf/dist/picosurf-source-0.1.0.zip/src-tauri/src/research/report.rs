use crate::ai::agent::CitedSource;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReportKind {
    Research,
    Custom(String),
    Compare,
    Summary,
    SavedRecall,
}

pub struct ResearchReport<'a> {
    pub kind: ReportKind,
    pub goal: &'a str,
    pub objective: &'a str,
    pub answer: &'a str,
    pub sources: &'a [CitedSource],
}

pub fn write_html(app: &tauri::AppHandle, report: &ResearchReport<'_>) -> Result<String, String> {
    let dir = crate::storage::data_file(app, "research")?;
    std::fs::create_dir_all(&dir).map_err(|err| err.to_string())?;
    cleanup_old(&dir, 24)?;

    let id = format!(
        "report-{}",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|item| item.as_millis())
            .unwrap_or(0)
    );
    let html = render_html(report);
    std::fs::write(dir.join(format!("{id}.html")), html).map_err(|err| err.to_string())?;
    Ok(id)
}

pub fn report_url(id: &str) -> String {
    format!("http://picosurf-research.localhost/{id}")
}

pub fn sidebar_message(kind: ReportKind, source_count: usize) -> String {
    let label = kind_label(&kind);
    if source_count == 0 {
        format!("{label} complete. See the main view.")
    } else {
        format!(
            "{label} complete — opened in the main view ({source_count} source{}). Source links in the report open the original sites.",
            if source_count == 1 { "" } else { "s" }
        )
    }
}

fn kind_label(kind: &ReportKind) -> String {
    match kind {
        ReportKind::Research => "Research".into(),
        ReportKind::Custom(label) => {
            let trimmed = label.trim();
            if trimmed.is_empty() {
                "Custom".into()
            } else {
                trimmed.chars().take(48).collect()
            }
        }
        ReportKind::Compare => "Comparison".into(),
        ReportKind::Summary => "Summary".into(),
        ReportKind::SavedRecall => "Saved pages".into(),
    }
}

fn cleanup_old(dir: &std::path::Path, keep: usize) -> Result<(), String> {
    let mut entries = std::fs::read_dir(dir)
        .map_err(|err| err.to_string())?
        .filter_map(|entry| entry.ok())
        .filter(|entry| {
            entry
                .path()
                .extension()
                .is_some_and(|ext| ext == "html")
        })
        .collect::<Vec<_>>();
    entries.sort_by_key(|entry| std::cmp::Reverse(entry.metadata().and_then(|m| m.modified()).ok()));
    for entry in entries.into_iter().skip(keep) {
        let _ = std::fs::remove_file(entry.path());
    }
    Ok(())
}

fn render_html(report: &ResearchReport<'_>) -> String {
    let kind_label = kind_label(&report.kind);
    let goal = escape_html(report.goal);
    let objective = escape_html(report.objective);
    let body = format_answer_html(report.answer);
    let sources = render_sources(report.sources);
    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{kind_label}: {goal}</title>
  <style>
    :root {{
      color-scheme: dark;
      --bg: #0f1318;
      --panel: #161b24;
      --line: #2a3140;
      --text: #e8edf6;
      --muted: #93a0b5;
      --accent: #3dbea0;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font: 15px/1.55 "Segoe UI", system-ui, sans-serif;
      color: var(--text);
      background: var(--bg);
    }}
    .wrap {{
      max-width: 860px;
      margin: 0 auto;
      padding: 28px 24px 48px;
    }}
    .badge {{
      display: inline-block;
      margin: 0 0 10px;
      padding: 4px 10px;
      border-radius: 999px;
      background: #1d2733;
      color: var(--accent);
      font-size: 12px;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }}
    h1 {{
      margin: 0 0 8px;
      font-size: 28px;
      line-height: 1.2;
    }}
    .meta {{
      margin: 0 0 24px;
      color: var(--muted);
      font-size: 13px;
    }}
    .answer {{
      padding: 20px 22px;
      border: 1px solid var(--line);
      border-radius: 14px;
      background: var(--panel);
    }}
    .answer p {{ margin: 0 0 14px; }}
    .answer p:last-child {{ margin-bottom: 0; }}
    .answer ol, .answer ul {{
      margin: 0 0 14px;
      padding-left: 22px;
    }}
    .answer li {{ margin: 0 0 10px; line-height: 1.5; }}
    .answer table.ranked {{
      width: 100%;
      margin: 0 0 14px;
      border-collapse: collapse;
      font-size: 14px;
    }}
    .answer table.ranked th,
    .answer table.ranked td {{
      padding: 10px 12px;
      border: 1px solid var(--line);
      text-align: left;
      vertical-align: top;
    }}
    .answer table.ranked th {{
      background: #121820;
      color: var(--muted);
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }}
    .answer table.ranked td:first-child {{
      width: 42px;
      color: var(--accent);
      font-weight: 600;
    }}
    .sources {{
      margin-top: 28px;
      padding-top: 20px;
      border-top: 1px solid var(--line);
    }}
    .sources h2 {{
      margin: 0 0 12px;
      font-size: 16px;
    }}
    .sources ol {{
      margin: 0;
      padding: 0;
      list-style: none;
      display: grid;
      gap: 10px;
    }}
    .source-card {{
      padding: 12px 14px;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: #121820;
    }}
    .source-card a {{
      color: var(--accent);
      text-decoration: none;
      font-weight: 600;
    }}
    .source-card a:hover {{ text-decoration: underline; }}
    .source-card .domain {{
      display: block;
      margin-top: 4px;
      color: var(--muted);
      font-size: 12px;
      word-break: break-all;
    }}
    .footnote {{
      margin-top: 24px;
      color: var(--muted);
      font-size: 12px;
    }}
  </style>
</head>
<body>
  <main class="wrap">
    <div class="badge">PicoSurf {kind_label}</div>
    <h1>{goal}</h1>
    <p class="meta">{objective}</p>
    <section class="answer">{body}</section>
    {sources}
    <p class="footnote">Generated locally on this device from pages PicoSurf opened during this task. Web content was treated as untrusted data.</p>
  </main>
</body>
</html>"#
    )
}

fn render_sources(sources: &[CitedSource]) -> String {
    if sources.is_empty() {
        return String::new();
    }
    let mut items = String::new();
    for (index, source) in sources.iter().enumerate() {
        let title = escape_html(&source.title);
        let url = escape_html(&source.url);
        let domain = escape_html(&source.domain);
        items.push_str(&format!(
            r#"<li class="source-card"><a href="{url}" rel="noopener noreferrer">{index}. {title}</a><span class="domain">{domain}</span></li>"#,
            index = index + 1,
            title = title,
            url = url,
            domain = domain,
        ));
    }
    format!(
        r#"<section class="sources"><h2>Sources</h2><ol>{items}</ol></section>"#
    )
}

fn format_answer_html(raw: &str) -> String {
    let trimmed = raw.trim();
    let (body, _) = split_sources_section(trimmed);
    let body = body.trim();
    if body.is_empty() {
        return "<p>No answer could be formed from the retrieved pages.</p>".into();
    }

    let lines = normalize_answer_lines(body);
    let mut blocks = Vec::new();
    let mut list_items: Vec<String> = Vec::new();
    let mut list_ordered = false;

    for line in lines {
        if line.is_empty() {
            flush_list(&mut blocks, &mut list_items, list_ordered);
            continue;
        }
        if let Some(item) = numbered_item(&line) {
            if !list_items.is_empty() && !list_ordered {
                flush_list(&mut blocks, &mut list_items, list_ordered);
            }
            list_ordered = true;
            list_items.push(item.to_string());
            continue;
        }
        if let Some(item) = bullet_item(&line) {
            if !list_items.is_empty() && list_ordered {
                flush_list(&mut blocks, &mut list_items, list_ordered);
            }
            list_ordered = false;
            list_items.push(item.to_string());
            continue;
        }
        flush_list(&mut blocks, &mut list_items, list_ordered);
        blocks.push(format!("<p>{}</p>", format_inline(&line)));
    }
    flush_list(&mut blocks, &mut list_items, list_ordered);

    if blocks.is_empty() {
        return format!("<p>{}</p>", format_inline(body));
    }
    blocks.join("\n")
}

fn normalize_answer_lines(body: &str) -> Vec<String> {
    let mut lines = Vec::new();
    for part in body.lines() {
        let trimmed = part.trim();
        if trimmed.is_empty() {
            if lines.last().is_some_and(|line: &String| !line.is_empty()) {
                lines.push(String::new());
            }
            continue;
        }
        if inline_numbered_list(trimmed) {
            lines.extend(split_inline_numbered(trimmed));
        } else {
            lines.push(trimmed.to_string());
        }
    }
    lines
}

fn inline_numbered_list(text: &str) -> bool {
    numbered_markers(text).len() >= 2
}

fn numbered_markers(text: &str) -> Vec<usize> {
    let chars: Vec<char> = text.chars().collect();
    let mut markers = Vec::new();
    let mut i = 0;
    while i < chars.len() {
        if numbered_marker_at(&chars, i).is_some() {
            markers.push(i);
        }
        i += 1;
    }
    markers
}

fn split_inline_numbered(text: &str) -> Vec<String> {
    let chars: Vec<char> = text.chars().collect();
    let markers: Vec<usize> = numbered_markers(text);
    if markers.len() < 2 {
        return vec![text.to_string()];
    }
    let mut out = Vec::new();
    let intro: String = chars[..markers[0]].iter().collect();
    let intro = intro.trim().trim_end_matches(':').trim();
    if !intro.is_empty() {
        out.push(intro.to_string());
        out.push(String::new());
    }
    for (idx, start) in markers.iter().enumerate() {
        let content_start = numbered_marker_at(&chars, *start).unwrap_or(*start);
        let end = markers.get(idx + 1).copied().unwrap_or(chars.len());
        let marker: String = chars[*start..content_start].iter().collect();
        let item: String = chars[content_start..end].iter().collect();
        out.push(format!("{marker}{}", item.trim()));
    }
    out
}

fn numbered_marker_at(chars: &[char], i: usize) -> Option<usize> {
    let at_boundary = i == 0
        || chars[i.saturating_sub(1)].is_whitespace()
        || matches!(chars[i.saturating_sub(1)], ':' | '(' | '[');
    if !at_boundary {
        return None;
    }
    let mut j = i;
    if j >= chars.len() || !chars[j].is_ascii_digit() {
        return None;
    }
    while j < chars.len() && chars[j].is_ascii_digit() {
        j += 1;
    }
    if j >= chars.len() || chars[j] != '.' {
        return None;
    }
    j += 1;
    if j >= chars.len() || !chars[j].is_whitespace() {
        return None;
    }
    Some(j + 1)
}

fn flush_list(blocks: &mut Vec<String>, items: &mut Vec<String>, ordered: bool) {
    if items.is_empty() {
        return;
    }
    if ordered {
        if let Some(table) = render_ranked_table(items) {
            blocks.push(table);
            items.clear();
            return;
        }
    }
    let tag = if ordered { "ol" } else { "ul" };
    let rendered: Vec<String> = items
        .iter()
        .map(|item| format!("<li>{}</li>", format_inline(item)))
        .collect();
    blocks.push(format!("<{tag}>{}</{tag}>", rendered.join("")));
    items.clear();
}

fn render_ranked_table(items: &[String]) -> Option<String> {
    if items.len() < 2 {
        return None;
    }
    let rows: Vec<(usize, String, String)> = items
        .iter()
        .enumerate()
        .filter_map(|(index, item)| {
            let (title, detail) = split_title_detail(item)?;
            Some((index + 1, title, detail))
        })
        .collect();
    if rows.len() != items.len() {
        return None;
    }
    let mut body = String::new();
    for (index, title, detail) in rows {
        body.push_str(&format!(
            "<tr><td>{index}</td><td>{}</td><td>{}</td></tr>",
            format_inline(&title),
            format_inline(&detail)
        ));
    }
    Some(format!(
        r#"<table class="ranked"><thead><tr><th>#</th><th>Item</th><th>Details</th></tr></thead><tbody>{body}</tbody></table>"#
    ))
}

fn split_title_detail(item: &str) -> Option<(String, String)> {
    for sep in [" — ", " – ", " - ", ": "] {
        if let Some((title, detail)) = item.split_once(sep) {
            let title = title.trim();
            let detail = detail.trim();
            if title.len() >= 2 && title.len() <= 80 && detail.len() >= 4 {
                return Some((title.to_string(), detail.to_string()));
            }
        }
    }
    None
}

fn numbered_item(line: &str) -> Option<&str> {
    let trimmed = line.trim();
    let rest = trimmed
        .strip_prefix('[')
        .and_then(|s| s.split_once(']'))
        .map(|(_, rest)| rest.trim())
        .or_else(|| {
            let mut parts = trimmed.splitn(2, '.');
            let num = parts.next()?;
            if !num.chars().all(|ch| ch.is_ascii_digit()) {
                return None;
            }
            parts.next().map(str::trim)
        })?;
    if rest.is_empty() {
        None
    } else {
        Some(rest)
    }
}

fn bullet_item(line: &str) -> Option<&str> {
    line.trim()
        .strip_prefix("- ")
        .or_else(|| line.trim().strip_prefix("* "))
        .or_else(|| line.trim().strip_prefix("• "))
}

fn format_inline(text: &str) -> String {
    let escaped = escape_html(text);
    let mut out = String::new();
    let mut chars = escaped.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '[' {
            let mut label = String::new();
            while let Some(&next) = chars.peek() {
                chars.next();
                if next == ']' {
                    break;
                }
                label.push(next);
            }
            if label.chars().all(|c| c.is_ascii_digit()) {
                out.push_str(&format!("<sup>[{label}]</sup>"));
            } else {
                out.push('[');
                out.push_str(&label);
                out.push(']');
            }
        } else {
            out.push(ch);
        }
    }
    out
}

fn split_sources_section(text: &str) -> (&str, &str) {
    if let Some(idx) = text.find("\n\nSources:\n") {
        (&text[..idx], &text[idx..])
    } else if let Some(idx) = text.find("\nSources:\n") {
        (&text[..idx], &text[idx..])
    } else {
        (text, "")
    }
}

fn escape_html(raw: &str) -> String {
    raw.chars()
        .flat_map(|ch| {
            match ch {
                '&' => "&amp;".chars().collect::<Vec<_>>(),
                '<' => "&lt;".chars().collect::<Vec<_>>(),
                '>' => "&gt;".chars().collect::<Vec<_>>(),
                '"' => "&quot;".chars().collect::<Vec<_>>(),
                '\'' => "&#39;".chars().collect::<Vec<_>>(),
                _ => vec![ch],
            }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn escapes_html_in_titles() {
        let html = render_html(&ResearchReport {
            kind: ReportKind::Research,
            goal: "Find <script>alert(1)</script> SUVs",
            objective: "Top SUVs",
            answer: "1. Tata Punch\n2. Hyundai Creta",
            sources: &[],
        });
        assert!(!html.contains("<script>"));
        assert!(html.contains("&lt;script&gt;"));
    }

    #[test]
    fn formats_numbered_answer() {
        let html = format_answer_html("Top picks:\n\n1. Tata Punch\n2. Hyundai Creta");
        assert!(html.contains("<ol>"));
        assert!(html.contains("Tata Punch"));
    }

    #[test]
    fn splits_inline_numbered_paragraph() {
        let html = format_answer_html(
            "Top Sensex movers: 1. Reliance +2% 2. TCS +1.5% 3. HDFC Bank +1%",
        );
        assert!(html.contains("<ol>"));
        assert!(html.contains("Reliance"));
        assert!(html.contains("HDFC Bank"));
    }

    #[test]
    fn renders_ranked_table_when_items_have_details() {
        let html = format_answer_html(
            "1. Reliance — up 2.1% on strong earnings\n2. TCS — gained 1.4% on IT rally",
        );
        assert!(html.contains("ranked"));
        assert!(html.contains("Reliance"));
        assert!(html.contains("strong earnings"));
    }

    #[test]
    fn strips_sources_section_from_body() {
        let (body, _) = split_sources_section("Answer here.\n\nSources:\n[1] Example");
        assert_eq!(body, "Answer here.");
    }
}
