use serde::{Deserialize, Serialize};
use url::Url;

use crate::security;
use crate::settings::AssistantMode;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Intent {
    PageTask,
    Research,
    SummarizePage,
    SummarizeUrl(String),
    Compare { urls: Vec<String> },
    SavePage,
    SearchSaved(String),
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct OmniboxDecision {
    pub kind: String,
    pub value: String,
}

pub fn classify(goal: &str) -> Intent {
    classify_with_mode(goal, AssistantMode::Auto)
}

pub fn classify_with_mode(goal: &str, mode: AssistantMode) -> Intent {
    let base = classify_auto(goal);
    match mode {
        AssistantMode::Auto => base,
        AssistantMode::Agent => match base {
            Intent::SavePage
            | Intent::SearchSaved(_)
            | Intent::SummarizePage
            | Intent::SummarizeUrl(_) => base,
            _ => Intent::PageTask,
        },
        AssistantMode::Research | AssistantMode::Custom => match base {
            Intent::PageTask if page_action_signals(goal) => Intent::PageTask,
            Intent::PageTask => Intent::Research,
            other => other,
        },
    }
}

fn classify_auto(goal: &str) -> Intent {
    let trimmed = goal.trim();
    if trimmed.is_empty() {
        return Intent::PageTask;
    }
    let lower = trimmed.to_ascii_lowercase();
    let plan = security::parse_task_plan(trimmed);
    if plan.add_to_cart || plan.buy_now {
        return Intent::PageTask;
    }
    if is_save(&lower) {
        return Intent::SavePage;
    }
    if let Some(query) = saved_query(&lower, trimmed) {
        return Intent::SearchSaved(query);
    }
    let urls = extract_urls(trimmed);
    if is_summarize(&lower) {
        if looks_like_this_page(&lower) && urls.is_empty() {
            return Intent::SummarizePage;
        }
        if let Some(url) = urls.first().cloned() {
            return Intent::SummarizeUrl(url);
        }
        if looks_like_this_page(&lower) {
            return Intent::SummarizePage;
        }
    }
    if lower.contains("compare") {
        return Intent::Compare { urls };
    }
    if is_research(&lower) {
        return Intent::Research;
    }
    Intent::PageTask
}

pub fn interpret_omnibox(input: &str, ai_enabled: bool, mode: AssistantMode) -> OmniboxDecision {
    let trimmed = input.trim();
    let (forced_search, rest) = strip_force_search(trimmed);
    if forced_search {
        return OmniboxDecision {
            kind: "search".into(),
            value: rest,
        };
    }
    if security::parse_url_or_host(trimmed).ok().flatten().is_some() {
        return OmniboxDecision {
            kind: "navigate".into(),
            value: trimmed.into(),
        };
    }
    if !ai_enabled {
        return OmniboxDecision {
            kind: "search".into(),
            value: trimmed.into(),
        };
    }
    match classify_with_mode(trimmed, mode) {
        Intent::Research | Intent::Compare { .. } => OmniboxDecision {
            kind: "research".into(),
            value: trimmed.into(),
        },
        Intent::SummarizePage | Intent::SummarizeUrl(_) => OmniboxDecision {
            kind: "summarize".into(),
            value: trimmed.into(),
        },
        Intent::SavePage => OmniboxDecision {
            kind: "save".into(),
            value: trimmed.into(),
        },
        Intent::SearchSaved(_) => OmniboxDecision {
            kind: "saved".into(),
            value: trimmed.into(),
        },
        Intent::PageTask => page_task_decision(trimmed, mode),
    }
}

fn page_task_decision(input: &str, mode: AssistantMode) -> OmniboxDecision {
    match mode {
        AssistantMode::Auto => OmniboxDecision {
            kind: "search".into(),
            value: input.into(),
        },
        AssistantMode::Agent => OmniboxDecision {
            kind: "task".into(),
            value: input.into(),
        },
        AssistantMode::Research | AssistantMode::Custom => OmniboxDecision {
            kind: if page_action_signals(input) {
                "task"
            } else {
                "research"
            }
            .into(),
            value: input.into(),
        },
    }
}

pub fn page_action_signals(goal: &str) -> bool {
    let lower = goal.to_ascii_lowercase();
    let plan = security::parse_task_plan(goal);
    if plan.add_to_cart || plan.buy_now {
        return true;
    }
    const MARKERS: &[&str] = &[
        "add to cart",
        "add to basket",
        "buy now",
        "checkout",
        "purchase",
        "click buy",
        "place order",
    ];
    if MARKERS.iter().any(|needle| lower.contains(needle)) {
        return true;
    }
    security::extract_open_target(goal).is_some()
}

fn strip_force_search(input: &str) -> (bool, String) {
    let trimmed = input.trim();
    let lower = trimmed.to_ascii_lowercase();
    if let Some(rest) = trimmed.strip_prefix('?') {
        return (true, rest.trim().to_string());
    }
    if let Some(rest) = lower.strip_prefix("search:") {
        let idx = trimmed.len() - rest.len();
        return (true, trimmed[idx..].trim().to_string());
    }
    (false, trimmed.to_string())
}

fn is_save(lower: &str) -> bool {
    [
        "save this page with ai",
        "save this with ai",
        "save with ai",
        "save this page",
        "save this",
        "save the page",
    ]
    .iter()
    .any(|needle| lower.contains(needle))
}

fn saved_query(lower: &str, original: &str) -> Option<String> {
    const MARKERS: &[&str] = &[
        "what did i save about ",
        "what did i save ",
        "show my saved articles about ",
        "show my saved ",
        "find the article i saved about ",
        "saved articles about ",
        "saved about ",
    ];
    for marker in MARKERS {
        if let Some(idx) = lower.find(marker) {
            let rest = original[idx + marker.len()..].trim();
            let rest = rest.trim_matches(|ch: char| "?.! ".contains(ch));
            return Some(if rest.is_empty() {
                "*".into()
            } else {
                rest.into()
            });
        }
    }
    None
}

fn is_summarize(lower: &str) -> bool {
    [
        "summarize",
        "summarise",
        "summary of",
        "tl;dr",
        "tldr",
        "what does this page say",
        "explain this page",
    ]
    .iter()
    .any(|needle| lower.contains(needle))
}

fn is_research(lower: &str) -> bool {
    [
        "research",
        "find the best",
        "find best",
        "top ",
        "compare",
        "what are the",
        "which ",
        "how much",
        "price of",
        "review",
        "reviews",
    ]
    .iter()
    .any(|needle| lower.contains(needle))
        || lower.contains('?')
}

fn looks_like_this_page(lower: &str) -> bool {
    [
        "this page",
        "current page",
        "this tab",
        "this site",
        "this article",
    ]
    .iter()
    .any(|needle| lower.contains(needle))
}

pub fn extract_urls(text: &str) -> Vec<String> {
    let mut urls = Vec::new();
    for token in text.split_whitespace() {
        let cleaned = token.trim_matches(|ch: char| "<>\"'()[]{}.,;:!?".contains(ch));
        if cleaned.starts_with("http://") || cleaned.starts_with("https://") {
            if Url::parse(cleaned).is_ok() {
                urls.push(cleaned.to_string());
            }
        }
    }
    urls
}

pub fn fallback_query(goal: &str) -> String {
    let trimmed = goal.trim();
    if trimmed.is_empty() {
        return "web search".into();
    }
    trimmed.chars().take(80).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::settings::AssistantMode;

    #[test]
    fn research_mode_routes_compare_to_research() {
        assert_eq!(
            classify_with_mode("Compare milk brands in UAE", AssistantMode::Research),
            Intent::Research
        );
    }

    #[test]
    fn custom_mode_routes_open_url_task() {
        assert_eq!(
            classify_with_mode("Open https://example.com and add to cart", AssistantMode::Custom),
            Intent::PageTask
        );
    }

    #[test]
    fn agent_mode_routes_research_phrase_to_page_task() {
        assert_eq!(
            classify_with_mode("Find the top 5 milk brands in UAE", AssistantMode::Agent),
            Intent::PageTask
        );
    }

    #[test]
    fn agent_mode_keeps_summarize() {
        assert_eq!(
            classify_with_mode("Summarize this page", AssistantMode::Agent),
            Intent::SummarizePage
        );
    }

    #[test]
    fn agent_interpret_runs_task() {
        let decision = interpret_omnibox(
            "Go to trafigura.com and search for india jobs",
            true,
            AssistantMode::Agent,
        );
        assert_eq!(decision.kind, "task");
    }

    #[test]
    fn auto_interpret_research_phrase() {
        let decision = interpret_omnibox("Find the top 5 milk brands in UAE", true, AssistantMode::Auto);
        assert_eq!(decision.kind, "research");
    }

    #[test]
    fn forced_search_prefix() {
        let decision = interpret_omnibox("?Find the top 5 milk brands in UAE", true, AssistantMode::Research);
        assert_eq!(decision.kind, "search");
    }

    #[test]
    fn ai_off_searches() {
        let decision = interpret_omnibox("Find the top 5 milk brands in UAE", false, AssistantMode::Research);
        assert_eq!(decision.kind, "search");
    }
}
