mod fetch;
mod parse;

#[cfg(windows)]
mod webview2;

use std::collections::HashSet;
use std::sync::{Arc, RwLock};

use serde::Serialize;
use tauri::{AppHandle, Manager};

pub use fetch::FilterMeta;

#[derive(Default)]
pub struct BlocklistState {
    hosts: RwLock<HashSet<String>>,
    meta: RwLock<FilterMeta>,
    /// User-configured retailer/source domains from saved agent flows (never ad-blocked).
    flow_allowlist: RwLock<HashSet<String>>,
}

impl BlocklistState {
    pub fn replace_hosts(&self, hosts: HashSet<String>, meta: FilterMeta) {
        if let Ok(mut guard) = self.hosts.write() {
            *guard = hosts;
        }
        if let Ok(mut guard) = self.meta.write() {
            *guard = meta;
        }
    }

    pub fn should_block_url(&self, url: &str, ctx: BlockRequestContext<'_>) -> bool {
        let Ok(url) = url::Url::parse(url) else {
            return false;
        };
        if !matches!(url.scheme(), "http" | "https") {
            return false;
        }
        let Some(host) = url.host_str() else {
            return false;
        };
        if ctx.is_main_document {
            return false;
        }
        if let Some(page_host) = ctx.page_host {
            if parse::is_same_site(page_host, host) {
                return false;
            }
        }
        if is_allowed_host(host) {
            return false;
        }
        if let Ok(guard) = self.flow_allowlist.read() {
            if parse::host_matches(host, &guard) {
                return false;
            }
        }
        let Ok(guard) = self.hosts.read() else {
            return false;
        };
        parse::host_matches(host, &guard)
    }

    pub fn replace_flow_allowlist(&self, domains: HashSet<String>) {
        if let Ok(mut guard) = self.flow_allowlist.write() {
            *guard = domains;
        }
    }

    pub fn status(&self) -> BlocklistStatus {
        let meta = self
            .meta
            .read()
            .ok()
            .map(|guard| guard.clone())
            .unwrap_or_default();
        BlocklistStatus {
            rule_hosts: meta.rule_hosts,
            updated_at: meta.updated_at,
            sources: meta.sources,
        }
    }

    pub fn meta(&self) -> FilterMeta {
        self.meta
            .read()
            .ok()
            .map(|guard| guard.clone())
            .unwrap_or_default()
    }
}

#[derive(Debug, Clone, Serialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct BlocklistStatus {
    pub rule_hosts: u32,
    pub updated_at: u64,
    pub sources: Vec<String>,
}

fn is_allowed_host(host: &str) -> bool {
    let host = host.trim().to_ascii_lowercase();
    host == "localhost"
        || host.ends_with(".localhost")
        || host == "127.0.0.1"
        || host == "picosurf-research.localhost"
        || crate::search::is_trusted_search_host(&host)
}

pub struct BlockRequestContext<'a> {
    pub page_host: Option<&'a str>,
    pub is_main_document: bool,
}

pub struct BlocklistHandle(pub Arc<BlocklistState>);

pub fn shared_state(app: &AppHandle) -> Arc<BlocklistState> {
    if let Some(state) = app.try_state::<BlocklistHandle>() {
        return state.0.clone();
    }
    let arc = Arc::new(BlocklistState::default());
    let _ = app.manage(BlocklistHandle(arc.clone()));
    arc
}

pub fn refresh_flow_allowlist(app: &AppHandle) {
    let shared = shared_state(app);
    let mut allow = HashSet::new();
    if let Ok(store) = crate::agent_flows::load_store(app) {
        for flow in &store.flows {
            for domain in flow.effective_pinned_domains() {
                allow.insert(domain);
            }
        }
    }
    shared.replace_flow_allowlist(allow);
}

pub fn bootstrap(app: &AppHandle) -> Result<(), String> {
    let shared = shared_state(app);
    reload_from_disk(app, &shared)?;
    refresh_flow_allowlist(app);
    let meta = shared.meta();
    if fetch::needs_refresh(&meta) {
        let app_refresh = app.clone();
        let shared_refresh = shared.clone();
        tauri::async_runtime::spawn(async move {
            let _ = refresh_filters(&app_refresh, &shared_refresh);
        });
    }
    install_request_blocker(app)?;
    Ok(())
}

pub fn reload_from_disk(app: &AppHandle, shared: &BlocklistState) -> Result<(), String> {
    let (hosts, meta) = fetch::load_hosts_from_disk(app)?;
    shared.replace_hosts(hosts, meta);
    Ok(())
}

pub fn refresh_filters(app: &AppHandle, shared: &BlocklistState) -> Result<FilterMeta, String> {
    let _meta = fetch::download_filters(app)?;
    let (hosts, meta) = fetch::load_hosts_from_disk(app)?;
    shared.replace_hosts(hosts, meta.clone());
    Ok(meta)
}

pub fn install_request_blocker(app: &AppHandle) -> Result<(), String> {
    #[cfg(windows)]
    {
        webview2::install(app)
    }
    #[cfg(not(windows))]
    {
        let _ = app;
        Ok(())
    }
}
