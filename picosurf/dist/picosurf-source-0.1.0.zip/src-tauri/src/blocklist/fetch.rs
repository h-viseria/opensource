use std::collections::HashSet;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};
use tauri::AppHandle;

use super::parse::parse_filter_text;
use crate::storage;

pub const EASYLIST_URL: &str = "https://easylist.to/easylist/easylist.txt";
pub const EASYPRIVACY_URL: &str = "https://easylist.to/easylist/easyprivacy.txt";
const REFRESH_INTERVAL: Duration = Duration::from_secs(24 * 60 * 60);

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct FilterMeta {
    pub updated_at: u64,
    pub rule_hosts: u32,
    pub sources: Vec<String>,
}

pub fn filters_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let dir = storage::data_file(app, "filters")?;
    std::fs::create_dir_all(&dir).map_err(|err| err.to_string())?;
    Ok(dir)
}

pub fn meta_path(dir: &Path) -> PathBuf {
    dir.join("meta.json")
}

pub fn load_meta(dir: &Path) -> FilterMeta {
    let path = meta_path(dir);
    if !path.is_file() {
        return FilterMeta::default();
    }
    storage::read_json_or_default(&path)
}

pub fn load_hosts_from_disk(app: &AppHandle) -> Result<(HashSet<String>, FilterMeta), String> {
    let dir = filters_dir(app)?;
    let mut combined = HashSet::new();
    for name in ["easylist.txt", "easyprivacy.txt"] {
        let path = dir.join(name);
        if path.is_file() {
            let raw = std::fs::read_to_string(&path).map_err(|err| err.to_string())?;
            combined.extend(parse_filter_text(&raw));
        }
    }
    let mut meta = load_meta(&dir);
    if meta.rule_hosts == 0 {
        meta.rule_hosts = combined.len() as u32;
    }
    Ok((combined, meta))
}

pub fn needs_refresh(meta: &FilterMeta) -> bool {
    if meta.updated_at == 0 {
        return true;
    }
    let Ok(now) = SystemTime::now().duration_since(UNIX_EPOCH) else {
        return true;
    };
    now.saturating_sub(Duration::from_secs(meta.updated_at)) >= REFRESH_INTERVAL
}

pub fn download_filters(app: &AppHandle) -> Result<FilterMeta, String> {
    let dir = filters_dir(app)?;
    let agent = ureq::AgentBuilder::new()
        .timeout_connect(Duration::from_secs(30))
        .timeout_read(Duration::from_secs(120))
        .user_agent("PicoSurf/0.1 (filter updater)")
        .build();

    let mut combined = HashSet::new();
    let mut sources = Vec::new();

    for (name, url) in [("easylist.txt", EASYLIST_URL), ("easyprivacy.txt", EASYPRIVACY_URL)] {
        let response = agent
            .get(url)
            .call()
            .map_err(|err| format!("Could not download {url}: {err}"))?;
        let mut body = String::new();
        response
            .into_reader()
            .read_to_string(&mut body)
            .map_err(|err| format!("Could not read {url}: {err}"))?;
        std::fs::write(dir.join(name), &body).map_err(|err| err.to_string())?;
        combined.extend(parse_filter_text(&body));
        sources.push(url.into());
    }

    let updated_at = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or(0);
    let meta = FilterMeta {
        updated_at,
        rule_hosts: combined.len() as u32,
        sources,
    };
    storage::write_json(&meta_path(&dir), &meta)?;
    Ok(meta)
}
