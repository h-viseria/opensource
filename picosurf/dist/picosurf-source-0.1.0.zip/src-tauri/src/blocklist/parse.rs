use std::collections::HashSet;

/// Parse EasyList / EasyPrivacy network rules into blocked hostnames.
pub fn parse_filter_text(raw: &str) -> HashSet<String> {
    let mut hosts = HashSet::new();
    for line in raw.lines() {
        if let Some(host) = parse_network_host(line) {
            hosts.insert(host);
        }
    }
    hosts
}

fn parse_network_host(line: &str) -> Option<String> {
    let line = line.trim();
    if line.is_empty() || line.starts_with('!') || line.starts_with('[') {
        return None;
    }
    if line.starts_with("@@") {
        return None;
    }
    if line.contains("##") || line.starts_with('#') {
        return None;
    }
    let rule = line.split('$').next()?.trim();
    if let Some(rest) = rule.strip_prefix("||") {
        return normalize_host(rest.split(['^', '/', '*']).next()?);
    }
    None
}

pub fn normalize_host(raw: &str) -> Option<String> {
    let mut host = raw.trim().to_ascii_lowercase();
    host = host.trim_start_matches("www.").to_string();
    if host.is_empty() || host.contains(' ') || !host.contains('.') {
        return None;
    }
    Some(host)
}

pub fn is_same_site(page_host: &str, request_host: &str) -> bool {
    let page = page_host.trim().to_ascii_lowercase();
    let request = request_host.trim().to_ascii_lowercase();
    if page.is_empty() || request.is_empty() {
        return false;
    }
    page == request || request.ends_with(&format!(".{page}"))
}

pub fn host_matches(host: &str, blocked: &HashSet<String>) -> bool {
    let host = host.trim().to_ascii_lowercase();
    if host.is_empty() {
        return false;
    }
    if blocked.contains(&host) {
        return true;
    }
    blocked
        .iter()
        .any(|domain| host.len() > domain.len() + 1 && host.ends_with(&format!(".{domain}")))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_domain_anchor_rules() {
        let hosts = parse_filter_text("||doubleclick.net^\n||ads.example.com^");
        assert!(hosts.contains("doubleclick.net"));
        assert!(hosts.contains("ads.example.com"));
    }

    #[test]
    fn ignores_cosmetic_rules() {
        let hosts = parse_filter_text("example.com##.ad\n||tracker.net^");
        assert!(!hosts.contains("example.com"));
        assert!(hosts.contains("tracker.net"));
    }

    #[test]
    fn subdomain_match() {
        let mut set = HashSet::new();
        set.insert("doubleclick.net".into());
        assert!(host_matches("ads.doubleclick.net", &set));
        assert!(!host_matches("notdoubleclick.net", &set));
    }

    #[test]
    fn allowlist_matches_retailer_subdomains() {
        let mut set = HashSet::new();
        set.insert("flipkart.com".into());
        assert!(host_matches("www.flipkart.com", &set));
        assert!(host_matches("flipkart.com", &set));
    }
}
