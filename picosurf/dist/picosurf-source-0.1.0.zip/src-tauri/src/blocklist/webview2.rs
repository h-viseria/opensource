use std::sync::atomic::{AtomicBool, Ordering};



use tauri::{AppHandle, Manager};

use webview2_com::{

    take_pwstr, WebResourceRequestedEventHandler,

};

use webview2_com::Microsoft::Web::WebView2::Win32::{

    ICoreWebView2, ICoreWebView2Controller, ICoreWebView2Environment,

    ICoreWebView2WebResourceRequestedEventArgs, COREWEBVIEW2_WEB_RESOURCE_CONTEXT,

    COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL, COREWEBVIEW2_WEB_RESOURCE_CONTEXT_DOCUMENT,

};

use windows::core::HSTRING;



use super::{BlocklistHandle, BlockRequestContext};

use crate::state::AppState;



static INSTALLED: AtomicBool = AtomicBool::new(false);



pub fn install(app: &AppHandle) -> Result<(), String> {

    if INSTALLED.swap(true, Ordering::SeqCst) {

        return Ok(());

    }

    let browser = app

        .get_webview("browser")

        .ok_or_else(|| "Browser view is not ready".to_string())?;

    browser

        .with_webview({

            let app = app.clone();

            move |platform| {

                if let Err(err) = attach(&app, platform.controller(), platform.environment()) {

                    eprintln!("Ad block hook failed: {err}");

                }

            }

        })

        .map_err(|err| err.to_string())?;

    Ok(())

}



fn attach(

    app: &AppHandle,

    controller: ICoreWebView2Controller,

    env: ICoreWebView2Environment,

) -> Result<(), String> {

    let core = unsafe {

        controller

            .CoreWebView2()

            .map_err(|err| format!("CoreWebView2: {err}"))

    }?;

    unsafe {

        core.AddWebResourceRequestedFilter(

            &HSTRING::from("https://*"),

            COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL,

        )

        .map_err(|err| format!("Filter https: {err}"))?;

        core.AddWebResourceRequestedFilter(

            &HSTRING::from("http://*"),

            COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL,

        )

        .map_err(|err| format!("Filter http: {err}"))?;

    }



    let app = app.clone();

    let core_for_handler = core.clone();

    let mut token = Default::default();

    unsafe {

        core.add_WebResourceRequested(

            &WebResourceRequestedEventHandler::create(Box::new(move |_, args| {

                handle_request(&app, &env, &core_for_handler, args)

            })),

            &mut token,

        )

        .map_err(|err| format!("WebResourceRequested: {err}"))?;

    }

    Ok(())

}



fn page_host(core: &ICoreWebView2) -> Option<String> {

    let mut raw = windows::core::PWSTR::null();

    unsafe { core.Source(&mut raw).ok()? };

    let url = take_pwstr(raw);

    url::Url::parse(&url)

        .ok()

        .and_then(|parsed| parsed.host_str().map(str::to_string))

}



fn resource_context(args: &ICoreWebView2WebResourceRequestedEventArgs) -> COREWEBVIEW2_WEB_RESOURCE_CONTEXT {

    let mut ctx = COREWEBVIEW2_WEB_RESOURCE_CONTEXT(0);

    let _ = unsafe { args.ResourceContext(&mut ctx) };

    ctx

}



fn handle_request(

    app: &AppHandle,

    env: &ICoreWebView2Environment,

    core: &ICoreWebView2,

    args: Option<ICoreWebView2WebResourceRequestedEventArgs>,

) -> windows::core::Result<()> {

    let Some(args) = args else {

        return Ok(());

    };

    let enabled = app

        .try_state::<AppState>()

        .map(|state| state.settings().ad_block_enabled)

        .unwrap_or(false);

    if !enabled {

        return Ok(());

    }

    let request = unsafe { args.Request()? };

    let uri = {

        let mut raw = windows::core::PWSTR::null();

        unsafe { request.Uri(&mut raw)? };

        take_pwstr(raw)

    };

    let ctx_type = resource_context(&args);

    let is_main_document = ctx_type == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_DOCUMENT;

    let page_host = page_host(core);

    let block_ctx = BlockRequestContext {

        page_host: page_host.as_deref(),

        is_main_document,

    };

    let block = app

        .try_state::<BlocklistHandle>()

        .map(|state| state.0.should_block_url(&uri, block_ctx))

        .unwrap_or(false);

    if !block {

        return Ok(());

    }

    let response = unsafe {

        env.CreateWebResourceResponse(

            None,

            403,

            &HSTRING::from("Blocked"),

            &HSTRING::new(),

        )?

    };

    unsafe { args.SetResponse(&response)? };

    Ok(())

}


