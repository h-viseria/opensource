use serde::{Deserialize, Serialize};
use tauri::AppHandle;

use crate::search::{self, SearchEngine, SearchSettings};
use crate::storage;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum AssistantMode {
    Research,
    Agent,
    Auto,
    Custom,
}

impl<'de> Deserialize<'de> for AssistantMode {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let raw = String::deserialize(deserializer)?;
        Ok(AssistantMode::from_id(&raw))
    }
}

impl Default for AssistantMode {
    fn default() -> Self {
        Self::Research
    }
}

impl AssistantMode {
    pub fn id(self) -> &'static str {
        match self {
            Self::Research => "research",
            Self::Agent => "agent",
            Self::Auto => "auto",
            Self::Custom => "custom",
        }
    }

    pub fn from_id(raw: &str) -> Self {
        match raw.trim().to_ascii_lowercase().as_str() {
            "custom" | "flow" => Self::Custom,
            "auto" | "automatic" => Self::Auto,
            "agent" | "page" | "page_task" | "pagetask" | "automation" | "browse" => Self::Agent,
            "shopping" | "shop" | "finance" | "financial" | "markets" => Self::Research,
            _ => Self::Research,
        }
    }

    pub fn is_custom(self) -> bool {
        matches!(self, Self::Custom)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentLimits {
    pub max_actions: u32,
    pub max_navigations: u32,
    pub max_runtime_secs: u32,
}

impl Default for AgentLimits {
    fn default() -> Self {
        Self {
            max_actions: 8,
            max_navigations: 3,
            max_runtime_secs: 90,
        }
    }
}

impl AgentLimits {
    pub fn clamp(self) -> Self {
        Self {
            max_actions: self.max_actions.clamp(1, 40),
            max_navigations: self.max_navigations.clamp(1, 20),
            max_runtime_secs: self.max_runtime_secs.clamp(15, 600),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum AgentStructureLevel {
    Off,
    Minimal,
    Standard,
    Detailed,
}

impl Default for AgentStructureLevel {
    fn default() -> Self {
        Self::Standard
    }
}

impl AgentStructureLevel {
    pub fn id(self) -> &'static str {
        match self {
            Self::Off => "off",
            Self::Minimal => "minimal",
            Self::Standard => "standard",
            Self::Detailed => "detailed",
        }
    }

    pub fn from_id(raw: &str) -> Self {
        match raw.trim().to_ascii_lowercase().as_str() {
            "off" | "none" | "false" => Self::Off,
            "minimal" | "min" => Self::Minimal,
            "detailed" | "full" | "max" => Self::Detailed,
            _ => Self::Standard,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ResearchLimits {
    pub max_queries: u32,
    pub max_results_per_query: u32,
    pub max_pages: u32,
    pub max_depth: u32,
    pub max_runtime_secs: u32,
    pub max_extract_chars: u32,
}

impl Default for ResearchLimits {
    fn default() -> Self {
        Self {
            max_queries: 5,
            max_results_per_query: 10,
            max_pages: 8,
            max_depth: 3,
            max_runtime_secs: 120,
            max_extract_chars: 1800,
        }
    }
}

impl ResearchLimits {
    pub fn clamp(self) -> Self {
        Self {
            max_queries: self.max_queries.clamp(1, 8),
            max_results_per_query: self.max_results_per_query.clamp(1, 20),
            max_pages: self.max_pages.clamp(1, 15),
            max_depth: self.max_depth.clamp(1, 5),
            max_runtime_secs: self.max_runtime_secs.clamp(30, 600),
            max_extract_chars: self.max_extract_chars.clamp(400, 4000),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppSettings {
    pub search: SearchSettings,
    pub research: ResearchLimits,
    pub ai_enabled: bool,
    pub save_with_ai_enabled: bool,
    pub agent_limits: AgentLimits,
    #[serde(default)]
    pub agent_structure_level: AgentStructureLevel,
    #[serde(default)]
    pub assistant_mode: AssistantMode,
    #[serde(default = "default_history_enabled")]
    pub history_enabled: bool,
    #[serde(default)]
    pub ai_history_enabled: bool,
    #[serde(default)]
    pub ad_block_enabled: bool,
    #[serde(default)]
    pub custom_flow_id: Option<String>,
}

fn default_history_enabled() -> bool {
    true
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            search: SearchSettings::default(),
            research: ResearchLimits::default(),
            ai_enabled: true,
            save_with_ai_enabled: true,
            agent_limits: AgentLimits::default(),
            agent_structure_level: AgentStructureLevel::default(),
            assistant_mode: AssistantMode::default(),
            history_enabled: true,
            ai_history_enabled: false,
            ad_block_enabled: false,
            custom_flow_id: None,
        }
    }
}

impl AppSettings {
    pub fn clamp(mut self) -> Result<Self, String> {
        self.research = self.research.clamp();
        self.agent_limits = self.agent_limits.clamp();
        self.agent_structure_level =
            AgentStructureLevel::from_id(self.agent_structure_level.id());
        self.assistant_mode = AssistantMode::from_id(self.assistant_mode.id());
        if !self.assistant_mode.is_custom() {
            self.custom_flow_id = None;
        } else if self
            .custom_flow_id
            .as_ref()
            .is_some_and(|id| id.trim().is_empty())
        {
            self.custom_flow_id = None;
        }
        if self.assistant_mode.is_custom() && self.custom_flow_id.is_none() {
            self.assistant_mode = AssistantMode::Research;
        }
        let engine = SearchEngine::from_id(&self.search.engine);
        self.search.engine = engine.id().into();
        if self.search.research_engine != "same" && !self.search.research_engine.is_empty() {
            let research = SearchEngine::from_id(&self.search.research_engine);
            self.search.research_engine = research.id().into();
        } else {
            self.search.research_engine = "same".into();
        }
        let research = if self.search.research_engine.eq_ignore_ascii_case("same") {
            engine
        } else {
            SearchEngine::from_id(&self.search.research_engine)
        };
        if engine == SearchEngine::Custom || research == SearchEngine::Custom {
            search::validate_template(&self.search.custom_template)?;
        }
        Ok(self)
    }
}

pub fn load(app: &AppHandle) -> AppSettings {
    let path = match storage::data_file(app, "settings.json") {
        Ok(path) => path,
        Err(_) => return AppSettings::default(),
    };
    if !path.exists() {
        return AppSettings::default();
    }
    let mut settings = storage::read_json_or_default::<AppSettings>(&path);
    match settings.clone().clamp() {
        Ok(normalized) => normalized,
        Err(_) => {
            if SearchEngine::from_id(&settings.search.engine) != SearchEngine::Custom {
                settings.search.custom_template.clear();
            }
            settings.clamp().unwrap_or_default()
        }
    }
}

pub fn save(app: &AppHandle, settings: &AppSettings) -> Result<(), String> {
    let path = storage::data_file(app, "settings.json")?;
    storage::write_json(&path, settings)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clamps_research_limits() {
        let limits = ResearchLimits {
            max_queries: 99,
            max_results_per_query: 0,
            max_pages: 100,
            max_depth: 0,
            max_runtime_secs: 1,
            max_extract_chars: 10,
        }
        .clamp();
        assert_eq!(limits.max_queries, 8);
        assert_eq!(limits.max_results_per_query, 1);
        assert_eq!(limits.max_pages, 15);
        assert_eq!(limits.max_depth, 1);
        assert_eq!(limits.max_runtime_secs, 30);
        assert_eq!(limits.max_extract_chars, 400);
    }

    #[test]
    fn custom_engine_requires_template() {
        let mut settings = AppSettings::default();
        settings.search.engine = "custom".into();
        settings.search.custom_template = "https://example.com/q".into();
        assert!(settings.clone().clamp().is_err());
        settings.search.custom_template = "https://example.com/q?q={query}".into();
        assert!(settings.clamp().is_ok());
    }
}
