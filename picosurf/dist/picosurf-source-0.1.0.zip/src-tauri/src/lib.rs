mod agent_flows;
mod blocklist;
mod visit_history;
mod download_log;
mod ai;
mod browser;
mod commands;
mod models;
mod platform;
mod research;
mod saved;
mod search;
mod security;
mod settings;
mod state;
mod storage;

use tauri::http::{self, header, StatusCode};
use tauri::webview::{DownloadEvent, PageLoadEvent, WebviewBuilder};
use tauri::{Emitter, LogicalPosition, LogicalSize, Manager, WebviewUrl};

use crate::state::{AppState, PendingNav};

pub fn run() {
    if let Err(err) = platform::ensure_webview2() {
        eprintln!("{err}");
        std::process::exit(1);
    }

    tauri::Builder::default()
        .register_uri_scheme_protocol("picosurf-research", |ctx, request| {
            serve_research_report(ctx.app_handle(), request.uri().path())
        })
        .manage(AppState::default())
        .setup(|app| {
            create_shell(app)?;
            let handle = app.handle().clone();
            browser::install_dialog_handler(&handle)?;
            if let Some(state) = app.try_state::<AppState>() {
                state.load_settings(&handle);
            }
            blocklist::bootstrap(&handle)?;
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::browser_navigate,
            commands::browser_back,
            commands::browser_forward,
            commands::browser_reload,
            commands::browser_state,
            commands::browser_inspect,
            commands::browser_page_info,
            commands::browser_click,
            commands::browser_type,
            commands::browser_scroll,
            commands::browser_screenshot,
            commands::clean_view_start,
            commands::clean_view_stop,
            commands::clean_view_status,
            commands::ad_block_status,
            commands::ad_block_refresh,
            commands::layout_sync,
            commands::models_list,
            commands::models_select,
            commands::models_download,
            commands::models_cancel,
            commands::models_load,
            commands::models_unload,
            commands::ai_generate,
            commands::ai_task,
            commands::ai_confirm,
            commands::ai_stop,
            commands::agent_limits_get,
            commands::agent_limits_set,
            commands::settings_get,
            commands::settings_set,
            commands::assistant_mode_get,
            commands::assistant_mode_set,
            commands::agent_flows_list,
            commands::agent_flows_get,
            commands::agent_flows_save,
            commands::agent_flows_delete,
            commands::history_list,
            commands::history_clear,
            commands::history_enabled_get,
            commands::history_enabled_set,
            commands::history_ai_enabled_get,
            commands::history_ai_enabled_set,
            commands::downloads_list,
            commands::downloads_clear,
            commands::omnibox_interpret,
            commands::saved_list,
            commands::saved_search,
            commands::save_with_ai,
        ])
        .run(tauri::generate_context!())
        .expect("error while running PicoSurf");
}

fn create_shell(app: &mut tauri::App) -> tauri::Result<()> {
    let width = 1200.0;
    let height = 700.0;
    let window = tauri::window::WindowBuilder::new(app, "main")
        .title("PicoSurf")
        .inner_size(1200.0, 700.0)
        .min_inner_size(880.0, 640.0)
        .resizable(true)
        .center()
        .build()?;

    let _chrome = window.add_child(
        WebviewBuilder::new("chrome", WebviewUrl::App("index.html".into()))
            .auto_resize()
            .devtools(cfg!(debug_assertions)),
        LogicalPosition::new(0.0, 0.0),
        LogicalSize::new(width, height),
    )?;

    let handle = app.handle().clone();
    let mut browser_builder =
        WebviewBuilder::new("browser", WebviewUrl::External(browser::start_url()))
            .devtools(cfg!(debug_assertions))
            .on_navigation(|url| security::is_allowed_navigation(&url));

    if let Ok(dir) = app.path().app_local_data_dir() {
        let profile = dir.join("browser-profile");
        let _ = std::fs::create_dir_all(&profile);
        browser_builder = browser_builder.data_directory(profile);
    }

    let handle_load = handle.clone();
    browser_builder = browser_builder.on_page_load(move |webview, payload| {
        match payload.event() {
            PageLoadEvent::Finished => {
                let url = payload.url().to_string();
                if let Some(state) = handle_load.try_state::<AppState>() {
                    state.on_url_committed(&url);
                    let title = state
                        .snapshot(&webview)
                        .title;
                    if state.settings().history_enabled {
                        let _ = visit_history::record(&handle_load, &url, &title);
                    }
                    let snapshot = state.snapshot(&webview);
                    browser::emit_state(&handle_load, &snapshot);
                }
            }
            PageLoadEvent::Started => {
                if let Some(state) = handle_load.try_state::<AppState>() {
                    state.invalidate_page();
                    if state.clean_view_active() {
                        commands::stop_clean_view_session(&handle_load, &state);
                    }
                }
            }
        }
    });

    let handle_title = handle.clone();
    browser_builder = browser_builder.on_document_title_changed(move |webview, title| {
        if let Some(state) = handle_title.try_state::<AppState>() {
            state.set_title(title.clone());
            if let Ok(url) = webview.url() {
                if state.settings().history_enabled {
                    let _ = visit_history::update_title(&handle_title, &url.to_string(), &title);
                }
            }
            let snapshot = state.snapshot(&webview);
            browser::emit_state(&handle_title, &snapshot);
        }
    });

    let handle_new = handle.clone();
    browser_builder = browser_builder.on_new_window(move |url, _features| {
        if security::is_allowed_navigation(&url) {
            if let Some(browser_view) = handle_new.get_webview("browser") {
                if let Some(state) = handle_new.try_state::<AppState>() {
                    state.set_pending(PendingNav::New);
                }
                let _ = browser_view.navigate(url);
            }
        }
        tauri::webview::NewWindowResponse::Deny
    });

    let handle_download = handle.clone();
    browser_builder = browser_builder.on_download(move |_webview, event| {
        match event {
            DownloadEvent::Requested { url, destination } => {
                if let Ok(download_dir) = handle_download.path().download_dir() {
                    let _ = std::fs::create_dir_all(&download_dir);
                    *destination =
                        download_log::resolve_destination(&download_dir, destination, &url);
                }
                true
            }
            DownloadEvent::Finished { url, path, success } => {
                if success {
                    if let Some(saved_path) = path {
                        let _ = download_log::record(
                            &handle_download,
                            &url.to_string(),
                            saved_path.as_path(),
                        );
                        if let Some(chrome) = handle_download.get_webview("chrome") {
                            let _ = chrome.emit("download-log-updated", ());
                        }
                    }
                }
                true
            }
            _ => true,
        }
    });

    let _browser = window.add_child(
        browser_builder,
        LogicalPosition::new(0.0, 52.0),
        LogicalSize::new(width, height - 52.0),
    )?;

    let handle_resize = handle.clone();
    window.on_window_event(move |event| {
        if matches!(
            event,
            tauri::WindowEvent::Resized(_) | tauri::WindowEvent::ScaleFactorChanged { .. }
        ) {
            let handle_resize = handle_resize.clone();
            tauri::async_runtime::spawn(async move {
                if let Some(state) = handle_resize.try_state::<AppState>() {
                    let _ = state.apply_layout(&handle_resize);
                }
            });
        }
    });

    Ok(())
}

fn serve_research_report(
    app: &tauri::AppHandle,
    path: &str,
) -> http::Response<Vec<u8>> {
    let id = path.trim_start_matches('/');
    if !security::is_allowed_research_id(id) {
        return research_http_response(
            StatusCode::BAD_REQUEST,
            "text/plain; charset=utf-8",
            b"Invalid report id.",
        );
    }
    let file = match storage::data_file(app, &format!("research/{id}.html")) {
        Ok(path) => path,
        Err(_) => {
            return research_http_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                "text/plain; charset=utf-8",
                b"Could not resolve report path.",
            );
        }
    };
    match std::fs::read(&file) {
        Ok(bytes) => research_http_response(
            StatusCode::OK,
            "text/html; charset=utf-8",
            &bytes,
        ),
        Err(_) => research_http_response(
            StatusCode::NOT_FOUND,
            "text/plain; charset=utf-8",
            b"Report not found.",
        ),
    }
}

fn research_http_response(
    status: StatusCode,
    content_type: &str,
    body: &[u8],
) -> http::Response<Vec<u8>> {
    http::Response::builder()
        .status(status)
        .header(header::CONTENT_TYPE, content_type)
        .body(body.to_vec())
        .unwrap_or_else(|_| {
            http::Response::builder()
                .status(StatusCode::INTERNAL_SERVER_ERROR)
                .body(Vec::new())
                .unwrap()
        })
}
