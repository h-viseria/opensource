pub fn is_allowed_navigation(url: &url::Url) -> bool {
    if url.scheme() == "picosurf-research" {
        return is_allowed_research_url(url);
    }
    matches!(url.scheme(), "https" | "http" | "about")
        && (url.scheme() != "about" || url.as_str() == "about:blank")
}

pub fn is_allowed_research_url(url: &url::Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    let allowed_host = match url.scheme() {
        "picosurf-research" => host == "localhost",
        "http" | "https" => host == "picosurf-research.localhost",
        _ => false,
    };
    if !allowed_host {
        return false;
    }
    let path = url.path();
    if path.contains("..") || path.matches('/').count() != 1 {
        return false;
    }
    is_allowed_research_id(path.trim_start_matches('/'))
}

pub fn is_allowed_research_id(id: &str) -> bool {
    id.starts_with("report-")
        && id.len() > "report-".len()
        && !id.contains('/')
        && !id.contains('\\')
        && !id.contains("..")
        && id
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || matches!(ch, '-' | '_'))
}

pub fn normalize_input(input: &str) -> Result<url::Url, String> {
    match parse_url_or_host(input)? {
        Some(url) => Ok(url),
        None => default_search_url(input.trim()),
    }
}

pub fn parse_url_or_host(input: &str) -> Result<Option<url::Url>, String> {
    let trimmed = input.trim();
    if trimmed.is_empty() {
        return Err("Enter an address or search".into());
    }

    if let Ok(url) = url::Url::parse(trimmed) {
        if is_allowed_navigation(&url) {
            return Ok(Some(url));
        }
        return Err(format!("Blocked URL scheme: {}", url.scheme()));
    }

    if looks_like_host(trimmed) {
        let url = url::Url::parse(&format!("https://{trimmed}"))
            .map_err(|err| format!("Invalid address: {err}"))?;
        if is_allowed_navigation(&url) {
            return Ok(Some(url));
        }
        return Err("That address is not allowed".into());
    }

    Ok(None)
}

pub fn default_search_url(query: &str) -> Result<url::Url, String> {
    crate::search::build_search_url(
        crate::search::SearchEngine::DuckDuckGo,
        query,
        "",
    )
}

pub fn looks_like_host(value: &str) -> bool {
    if value.contains(' ') || value.contains('\\') {
        return false;
    }
    if let Some(host) = value.split('/').next() {
        host.contains('.') && !host.starts_with('.') && !host.ends_with('.')
    } else {
        false
    }
}

pub fn extract_open_target(goal: &str) -> Option<String> {
    if let Some(url) = first_http_url(goal) {
        return Some(url);
    }
    let lower = goal.to_ascii_lowercase();
    const PREFIXES: &[&str] = &[
        "open url ",
        "open the url ",
        "open this url ",
        "navigate to ",
        "go to ",
        "visit ",
        "open ",
    ];
    for prefix in PREFIXES {
        if let Some(idx) = lower.find(prefix) {
            let rest = goal[idx + prefix.len()..].trim_start();
            let token = rest
                .split_whitespace()
                .next()?
                .trim_matches(|ch: char| ".,;:!?'\")".contains(ch));
            if token.is_empty() {
                continue;
            }
            if let Ok(url) = normalize_input(token) {
                let host = url.host_str().unwrap_or("");
                if host == "duckduckgo.com" && !token.to_ascii_lowercase().contains("duckduckgo") {
                    continue;
                }
                return Some(url.to_string());
            }
        }
    }
    None
}

fn first_http_url(text: &str) -> Option<String> {
    let lower = text.to_ascii_lowercase();
    let start = lower.find("https://").or_else(|| lower.find("http://"))?;
    let rest = &text[start..];
    let end = rest
        .find(|ch: char| ch.is_whitespace() || "<>\"')|]".contains(ch))
        .unwrap_or(rest.len());
    let candidate = rest[..end].trim_end_matches(|ch: char| ".,;:!?".contains(ch));
    let url = normalize_input(candidate).ok()?;
    if !matches!(url.scheme(), "http" | "https") {
        return None;
    }
    Some(url.to_string())
}

pub fn extract_search_query(goal: &str) -> Option<String> {
    let lower = goal.to_ascii_lowercase();
    for marker in ["search for ", "look for ", "find "] {
        if let Some(idx) = lower.find(marker) {
            return clean_query(&goal[idx + marker.len()..]);
        }
    }
    if let Some(idx) = lower.find("search ") {
        let rest = &goal[idx + 7..];
        let rest_lower = rest.to_ascii_lowercase();
        if let Some(for_idx) = rest_lower.find(" for ") {
            return clean_query(&rest[for_idx + 5..]);
        }
        return clean_query(rest);
    }
    leftover_query_after_open(goal)
}

fn clean_query(raw: &str) -> Option<String> {
    let mut text = cut_followup_actions(raw.trim()).to_string();
    let lower = text.to_ascii_lowercase();
    for cut in [" and then ", " then ", "\n"] {
        if let Some(idx) = lower.find(cut) {
            if text.is_char_boundary(idx) {
                text.truncate(idx);
            }
            break;
        }
    }
    let text = text.trim().trim_matches(|ch: char| ".,;:".contains(ch));
    if text.chars().count() < 2 {
        return None;
    }
    Some(text.to_string())
}

fn cut_followup_actions(text: &str) -> &str {
    let lower = text.to_ascii_lowercase();
    const CUTS: &[&str] = &[
        " and add it to cart",
        " and add to cart",
        " and add it to basket",
        " and add to basket",
        " add it to cart",
        " add to cart",
        " add it to basket",
        " add to basket",
        " and buy it now",
        " and buy now",
        " and buy it",
        " and buy",
        " buy now",
        " and purchase",
        " then add",
        " then buy",
        " and click",
        " and order",
        ", add to cart",
        ", add it to cart",
        ", buy",
    ];
    let mut best = text.len();
    for needle in CUTS {
        if let Some(idx) = lower.find(needle) {
            if text.is_char_boundary(idx) {
                best = best.min(idx);
            }
        }
    }
    text[..best].trim_end_matches(|ch: char| ".,;: ".contains(ch))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TaskPlan {
    pub search_query: Option<String>,
    pub add_to_cart: bool,
    pub buy_now: bool,
}

pub fn parse_task_plan(goal: &str) -> TaskPlan {
    let lower = goal.to_ascii_lowercase();
    let add_to_cart = [
        "add to cart",
        "add it to cart",
        "add this to cart",
        "add to basket",
        "add it to basket",
    ]
    .iter()
    .any(|needle| lower.contains(needle));
    let buy_now = ["buy now", "buy it now", "purchase it", "place order"]
        .iter()
        .any(|needle| lower.contains(needle));
    TaskPlan {
        search_query: extract_search_query(goal),
        add_to_cart,
        buy_now,
    }
}

fn leftover_query_after_open(goal: &str) -> Option<String> {
    let url = extract_open_target(goal)?;
    let mut rest = goal.to_string();
    if let Some(raw) = first_http_url(goal) {
        rest = rest.replace(&raw, " ");
    }
    rest = rest.replace(&url, " ");
    const DROP: &[&str] = &[
        "open", "url", "go", "to", "visit", "and", "then", "navigate", "the", "page", "website",
        "site", "please", "add", "cart", "basket", "buy", "now", "it", "this",
    ];
    let kept: Vec<&str> = rest
        .split_whitespace()
        .filter(|word| {
            let lower = word.trim_matches(|ch: char| ".,;:!?".contains(ch)).to_ascii_lowercase();
            !DROP.contains(&lower.as_str()) && !lower.contains("http")
        })
        .collect();
    if kept.len() < 2 && kept.join(" ").chars().count() < 4 {
        return None;
    }
    clean_query(&kept.join(" "))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn allows_https() {
        let url = url::Url::parse("https://example.com").unwrap();
        assert!(is_allowed_navigation(&url));
    }

    #[test]
    fn allows_research_report_scheme() {
        let url = url::Url::parse("http://picosurf-research.localhost/report-123").unwrap();
        assert!(is_allowed_navigation(&url));
        assert!(is_allowed_research_url(&url));
    }

    #[test]
    fn blocks_spoofed_research_paths() {
        let url = url::Url::parse("http://picosurf-research.localhost/../secrets").unwrap();
        assert!(!is_allowed_research_url(&url));
    }

    #[test]
    fn blocks_file() {
        let url = url::Url::parse("file:///C:/secret.txt").unwrap();
        assert!(!is_allowed_navigation(&url));
    }

    #[test]
    fn blocks_javascript() {
        let url = url::Url::parse("javascript:alert(1)").unwrap();
        assert!(!is_allowed_navigation(&url));
    }

    #[test]
    fn searches_plain_language() {
        let url = normalize_input("amul 500g butter").unwrap();
        assert!(url.as_str().contains("duckduckgo.com"));
        assert!(url.as_str().contains("kl=en-us") || url.query().unwrap().contains("kl"));
        assert!(url.query().unwrap().contains("amul"));
    }

    #[test]
    fn plain_language_is_not_a_url() {
        assert!(parse_url_or_host("milk brands UAE").unwrap().is_none());
    }

    #[test]
    fn blocked_scheme_is_an_error() {
        assert!(parse_url_or_host("file:///C:/secret.txt").is_err());
        assert!(parse_url_or_host("javascript:alert(1)").is_err());
        assert!(parse_url_or_host("data:text/html,hi").is_err());
    }

    #[test]
    fn upgrades_bare_host() {
        let url = normalize_input("duckduckgo.com").unwrap();
        assert_eq!(url.as_str(), "https://duckduckgo.com/");
    }

    #[test]
    fn extracts_open_https_url() {
        let url = extract_open_target("open https://www.amazon.in and search for butter").unwrap();
        assert!(url.contains("amazon.in"));
    }

    #[test]
    fn extracts_go_to_host() {
        let url = extract_open_target("go to amazon.com then search for milk").unwrap();
        assert_eq!(url, "https://amazon.com/");
    }

    #[test]
    fn ignores_plain_search_without_open() {
        assert!(extract_open_target("search amazon for butter").is_none());
    }

    #[test]
    fn extracts_search_for_query() {
        assert_eq!(
            extract_search_query("open https://www.amazon.in/ and search for Amul butter 500g")
                .as_deref(),
            Some("Amul butter 500g")
        );
    }

    #[test]
    fn extracts_search_site_for_query() {
        assert_eq!(
            extract_search_query("search amazon for amul butter").as_deref(),
            Some("amul butter")
        );
    }

    #[test]
    fn leftover_words_after_open_are_the_query() {
        assert_eq!(
            extract_search_query("open https://www.amazon.in/ Amul butter 500g").as_deref(),
            Some("Amul butter 500g")
        );
    }

    #[test]
    fn search_query_strips_add_to_cart() {
        let goal = "open amazon.in, search for Amul butter 500g and add it to cart";
        assert_eq!(
            extract_search_query(goal).as_deref(),
            Some("Amul butter 500g")
        );
        let plan = parse_task_plan(goal);
        assert!(plan.add_to_cart);
        assert!(!plan.buy_now);
    }
}
