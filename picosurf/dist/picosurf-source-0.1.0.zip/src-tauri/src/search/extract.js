(() => {
  try {
    function clip(value, max) {
      const text = String(value || "")
        .replace(/\s+/g, " ")
        .trim();
      return text.length > max ? text.slice(0, max) : text;
    }

    const SKIP_RE =
      /^(javascript:|mailto:|tel:|#)/i;
    const seen = new Set();
    const results = [];
    const anchors = Array.from(document.querySelectorAll("a[href]"));
    for (const el of anchors) {
      if (results.length >= 20) break;
      const href = String(el.href || el.getAttribute("href") || "").trim();
      if (!href || SKIP_RE.test(href)) continue;
      if (!/^https?:/i.test(href)) continue;
      const title = clip(el.innerText || el.getAttribute("aria-label") || "", 160);
      if (title.length < 8) continue;
      const key = href.split("#")[0];
      if (seen.has(key)) continue;
      seen.add(key);
      const box =
        el.closest("article, li, .result, .web-result, [data-testid]") || el.parentElement;
      const snippet = clip((box && box.innerText) || title, 240);
      results.push({
        title,
        url: href,
        snippet,
      });
    }

    const body = clip((document.body && document.body.innerText) || "", 1200);
    return {
      ok: true,
      url: String(location.href || ""),
      title: clip(document.title, 200),
      body,
      results,
    };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
})()
