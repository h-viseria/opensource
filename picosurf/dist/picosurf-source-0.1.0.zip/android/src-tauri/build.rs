fn sync_android_clean_view_asset() {
    use std::{fs, path::PathBuf};
    let manifest_dir = PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").unwrap());
    let src = manifest_dir.join("src/browser/clean_view.js");
    let dst = manifest_dir.join("gen/android/app/src/main/assets/picosurf/clean_view.js");
    if !src.exists() {
        return;
    }
    if let Some(parent) = dst.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let _ = fs::copy(&src, &dst);
}

fn main() {
    sync_android_clean_view_asset();
    tauri_build::try_build(
        tauri_build::Attributes::new().app_manifest(
            tauri_build::AppManifest::new().commands(&[
                "browser_navigate",
                "browser_back",
                "browser_forward",
                "browser_reload",
                "browser_state",
                "browse_uses_embedded_frame",
                "browser_ensure",
                "layout_sync",
                "settings_get",
                "settings_set",
                "app_mode_get",
                "app_mode_set",
                "research_feature_status",
                "research_feature_request_install",
                "research_run",
                "research_stop",
                "omnibox_resolve",
                "models_list",
                "models_select",
                "models_download",
                "models_cancel",
                "models_load",
                "models_unload",
                "ai_generate",
                "history_list",
                "history_clear",
                "history_enabled_get",
                "history_enabled_set",
                "history_ai_enabled_get",
                "history_ai_enabled_set",
                "bookmark_list",
                "bookmark_add",
                "bookmark_remove",
                "bookmark_has",
                "clean_view_start",
                "clean_view_stop",
                "clean_view_status",
            ]),
        ),
    )
    .expect("failed to run tauri-build");
}
