use serde::{Deserialize, Serialize};

use crate::search::SearchSettings;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum AppMode {
    Browse,
    Research,
}

impl Default for AppMode {
    fn default() -> Self {
        Self::Browse
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ResearchLimits {
    pub max_queries: u32,
    pub max_results_per_query: u32,
    pub max_pages: u32,
    pub max_depth: u32,
    pub max_runtime_secs: u32,
    pub max_extract_chars: u32,
}

impl Default for ResearchLimits {
    fn default() -> Self {
        Self {
            max_queries: 3,
            max_results_per_query: 6,
            max_pages: 5,
            max_depth: 2,
            max_runtime_secs: 90,
            max_extract_chars: 1600,
        }
    }
}

impl ResearchLimits {
    pub fn clamp(self) -> Self {
        Self {
            max_queries: self.max_queries.clamp(1, 6),
            max_results_per_query: self.max_results_per_query.clamp(1, 10),
            max_pages: self.max_pages.clamp(1, 8),
            max_depth: self.max_depth.clamp(1, 4),
            max_runtime_secs: self.max_runtime_secs.clamp(30, 180),
            max_extract_chars: self.max_extract_chars.clamp(800, 4000),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AndroidSettings {
    pub mode: AppMode,
    pub search: SearchSettings,
    pub research: ResearchLimits,
    #[serde(default = "default_ai_enabled")]
    pub ai_enabled: bool,
    #[serde(default = "default_history_enabled")]
    pub history_enabled: bool,
    #[serde(default)]
    pub ai_history_enabled: bool,
    pub research_feature_installed: bool,
    #[serde(default)]
    pub selected_model_id: Option<String>,
}

fn default_ai_enabled() -> bool {
    false
}

fn default_history_enabled() -> bool {
    false
}

impl Default for AndroidSettings {
    fn default() -> Self {
        Self {
            mode: AppMode::Browse,
            search: SearchSettings::default(),
            research: ResearchLimits::default(),
            ai_enabled: false,
            history_enabled: false,
            ai_history_enabled: false,
            research_feature_installed: false,
            selected_model_id: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LayoutSync {
    pub toolbar_height: f64,
    pub bottom_nav_height: f64,
    #[serde(default)]
    pub browse_overlay: bool,
}

impl Default for LayoutSync {
    fn default() -> Self {
        Self {
            toolbar_height: 52.0,
            bottom_nav_height: 56.0,
            browse_overlay: false,
        }
    }
}
