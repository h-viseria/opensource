pub mod models;

use tauri::{AppHandle, Emitter, Manager, State};
use url::Url;

use crate::bookmarks::{self, Bookmark};
use crate::browser::{self, browser_webview};
use crate::research::ResearchRunResult;
use crate::search;
use crate::settings::{AndroidSettings, AppMode, LayoutSync};
use crate::state::{AppState, PendingNav};
use crate::visit_history::{self, VisitEntry};
#[cfg(target_os = "android")]
use crate::browse_shell::BrowseShellExt;
use serde::Serialize;
use serde_json::Value;

#[cfg(target_os = "android")]
fn mobile_sync_url(app: &AppHandle, state: &AppState) {
    if let Ok(meta) = app.browse_shell().page_meta() {
        if meta.ready {
            if !meta.url.is_empty() {
                state.set_browse_url(&meta.url);
            }
            state.set_page_title(&meta.title);
        } else {
            state.clear_history_settled_gate();
            if let Ok(url) = app.browse_shell().current_url() {
                if !url.is_empty() {
                    state.set_browse_url(&url);
                }
            }
        }
    } else if let Ok(url) = app.browse_shell().current_url() {
        if !url.is_empty() {
            state.set_browse_url(&url);
        }
    }
}

#[cfg(target_os = "android")]
fn maybe_record_visit(app: &AppHandle, state: &AppState) {
    if !state.settings().history_enabled {
        return;
    }
    let Ok(meta) = app.browse_shell().page_meta() else {
        return;
    };
    if !meta.ready || meta.url.is_empty() {
        return;
    }
    if !visit_history::should_record(&meta.url) {
        return;
    }
    if state.history_already_settled(&meta.url) {
        return;
    }
    if visit_history::record(app, &meta.url, &meta.title).is_ok() {
        state.mark_history_settled(&meta.url);
    }
}

#[cfg(target_os = "android")]
fn mobile_emit(app: &AppHandle, state: &AppState) -> browser::BrowserState {
    mobile_sync_url(app, state);
    maybe_record_visit(app, state);
    state.emit_browser_state_mobile(app);
    state.mobile_snapshot()
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CleanViewState {
    pub active: bool,
}

fn emit_clean_view(app: &AppHandle, active: bool) {
    if let Some(main) = app.get_webview("main") {
        let _ = main.emit("clean-view-changed", CleanViewState { active });
    }
}

#[cfg(target_os = "android")]
async fn browse_eval_async(app: &AppHandle, script: &str) -> Result<Value, String> {
    app.browse_shell().eval_json_async(script).await
}

pub fn stop_clean_view_session(app: &AppHandle, state: &AppState) {
    if !state.clean_view_active() {
        return;
    }
    state.set_clean_view_active(false);
    emit_clean_view(app, false);
    #[cfg(target_os = "android")]
    {
        let app = app.clone();
        tauri::async_runtime::spawn(async move {
            let _ = app.browse_shell().set_touch_passthrough(false);
            let script = browser::clean_view::action_script("stop");
            let _ = browse_eval_async(&app, &script).await;
        });
    }
}

#[tauri::command]
pub fn settings_get(state: State<AppState>) -> AndroidSettings {
    state.settings()
}

#[tauri::command]
pub fn settings_set(
    app: AppHandle,
    state: State<AppState>,
    settings: AndroidSettings,
) -> Result<AndroidSettings, String> {
    state.set_settings(&app, settings)?;
    state.apply_layout(&app)?;
    Ok(state.settings())
}

#[tauri::command]
pub fn app_mode_get(state: State<AppState>) -> AppMode {
    state.settings().mode
}

#[tauri::command]
pub fn app_mode_set(app: AppHandle, state: State<AppState>, mode: AppMode) -> Result<AppMode, String> {
    let mut settings = state.settings();
    settings.mode = mode;
    state.set_settings(&app, settings)?;
    Ok(mode)
}

#[tauri::command]
pub fn layout_sync(app: AppHandle, state: State<AppState>, layout: LayoutSync) -> Result<(), String> {
    state.set_layout(layout);
    state.apply_layout(&app)
}

#[tauri::command]
pub fn omnibox_resolve(state: State<AppState>, input: String) -> Result<String, String> {
    let settings = state.settings();
    let url = search::resolve_omnibox(&input, &settings.search)?;
    Ok(url.to_string())
}

#[tauri::command]
pub fn browser_navigate(
    app: AppHandle,
    state: State<AppState>,
    input: String,
) -> Result<browser::BrowserState, String> {
    let settings = state.settings();
    let url = search::resolve_omnibox(&input, &settings.search)?;
    navigate_to(&app, &state, url)
}

fn navigate_to(
    app: &AppHandle,
    state: &AppState,
    url: Url,
) -> Result<browser::BrowserState, String> {
    if !crate::security::is_allowed_navigation(&url) {
        return Err("That URL is not allowed.".into());
    }
    #[cfg(all(mobile, not(target_os = "android")))]
    {
        state.set_pending(PendingNav::None);
        state.set_browse_url(url.as_str());
        state.on_url_committed(url.as_str());
        state.emit_browser_state_mobile(app);
        return Ok(state.mobile_snapshot());
    }
    #[cfg(target_os = "android")]
    {
        stop_clean_view_session(app, state);
        state.set_pending(PendingNav::None);
        app.browse_shell().load_url(url.as_str())?;
        state.set_browse_url(url.as_str());
        state.on_url_committed(url.as_str());
        return Ok(mobile_emit(app, state));
    }
    #[cfg(desktop)]
    {
        let webview = browser_webview(app)?;
        state.set_pending(PendingNav::None);
        webview
            .navigate(url.clone())
            .map_err(|err| err.to_string())?;
        state.on_url_committed(url.as_str());
        state.emit_browser_state(app, &webview);
        Ok(state.snapshot(&webview))
    }
}

#[tauri::command]
pub fn browser_back(app: AppHandle, state: State<AppState>) -> Result<browser::BrowserState, String> {
    #[cfg(all(mobile, not(target_os = "android")))]
    {
        let target = state.history_back_target()?;
        if let Some(url) = target {
            state.set_pending(PendingNav::Back);
            state.set_browse_url(&url);
        }
        state.emit_browser_state_mobile(&app);
        return Ok(state.mobile_snapshot());
    }
    #[cfg(target_os = "android")]
    {
        stop_clean_view_session(&app, &state);
        if !app.browse_shell().go_back()? {
            if let Some(url) = state.history_back_target()? {
                state.set_pending(PendingNav::Back);
                app.browse_shell().load_url(&url)?;
            }
        } else {
            state.set_pending(PendingNav::Back);
        }
        return Ok(mobile_emit(&app, &state));
    }
    #[cfg(desktop)]
    {
        let webview = browser_webview(&app)?;
        let target = state.history_back_target()?;
        if let Some(url) = target {
            state.set_pending(PendingNav::Back);
            let parsed = Url::parse(&url).map_err(|err| err.to_string())?;
            webview.navigate(parsed).map_err(|err| err.to_string())?;
        }
        state.emit_browser_state(&app, &webview);
        Ok(state.snapshot(&webview))
    }
}

#[tauri::command]
pub fn browser_forward(
    app: AppHandle,
    state: State<AppState>,
) -> Result<browser::BrowserState, String> {
    #[cfg(all(mobile, not(target_os = "android")))]
    {
        let target = state.history_forward_target()?;
        if let Some(url) = target {
            state.set_pending(PendingNav::Forward);
            state.set_browse_url(&url);
        }
        state.emit_browser_state_mobile(&app);
        return Ok(state.mobile_snapshot());
    }
    #[cfg(target_os = "android")]
    {
        stop_clean_view_session(&app, &state);
        if !app.browse_shell().go_forward()? {
            if let Some(url) = state.history_forward_target()? {
                state.set_pending(PendingNav::Forward);
                app.browse_shell().load_url(&url)?;
            }
        } else {
            state.set_pending(PendingNav::Forward);
        }
        return Ok(mobile_emit(&app, &state));
    }
    #[cfg(desktop)]
    {
        let webview = browser_webview(&app)?;
        let target = state.history_forward_target()?;
        if let Some(url) = target {
            state.set_pending(PendingNav::Forward);
            let parsed = Url::parse(&url).map_err(|err| err.to_string())?;
            webview.navigate(parsed).map_err(|err| err.to_string())?;
        }
        state.emit_browser_state(&app, &webview);
        Ok(state.snapshot(&webview))
    }
}

#[tauri::command]
pub fn browser_reload(
    app: AppHandle,
    state: State<AppState>,
) -> Result<browser::BrowserState, String> {
    #[cfg(all(mobile, not(target_os = "android")))]
    {
        state.set_pending(PendingNav::Reload);
        state.emit_browser_state_mobile(&app);
        return Ok(state.mobile_snapshot());
    }
    #[cfg(target_os = "android")]
    {
        stop_clean_view_session(&app, &state);
        state.set_pending(PendingNav::Reload);
        app.browse_shell().reload()?;
        return Ok(mobile_emit(&app, &state));
    }
    #[cfg(desktop)]
    {
        let webview = browser_webview(&app)?;
        state.set_pending(PendingNav::Reload);
        webview.reload().map_err(|err| err.to_string())?;
        state.emit_browser_state(&app, &webview);
        Ok(state.snapshot(&webview))
    }
}

#[tauri::command]
pub fn browser_ensure(app: AppHandle) -> Result<(), String> {
    #[cfg(mobile)]
    {
        browser::mobile::ensure_browser_webview(&app)?;
    }
    #[cfg(desktop)]
    {
        let _ = app;
    }
    Ok(())
}

#[tauri::command]
pub fn browse_uses_embedded_frame() -> bool {
    cfg!(mobile)
}

#[tauri::command]
pub fn browser_state(app: AppHandle, state: State<AppState>) -> Result<browser::BrowserState, String> {
    #[cfg(all(mobile, not(target_os = "android")))]
    {
        let _ = app;
        return Ok(state.mobile_snapshot());
    }
    #[cfg(target_os = "android")]
    {
        return Ok(mobile_emit(&app, &state));
    }
    #[cfg(desktop)]
    {
        let webview = browser_webview(&app)?;
        state.emit_browser_state(&app, &webview);
        Ok(state.snapshot(&webview))
    }
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ResearchFeatureStatus {
    pub installed: bool,
    pub play_delivery_ready: bool,
}

#[tauri::command]
pub fn research_feature_status(state: State<AppState>) -> ResearchFeatureStatus {
    let settings = state.settings();
    ResearchFeatureStatus {
        installed: settings.research_feature_installed,
        play_delivery_ready: false,
    }
}

#[tauri::command]
pub fn research_feature_request_install(
    app: AppHandle,
    state: State<AppState>,
) -> Result<ResearchFeatureStatus, String> {
    let mut settings = state.settings();
    settings.research_feature_installed = true;
    state.set_settings(&app, settings)?;
    Ok(ResearchFeatureStatus {
        installed: true,
        play_delivery_ready: false,
    })
}

#[tauri::command]
pub async fn research_run(
    app: AppHandle,
    state: State<'_, AppState>,
    goal: String,
) -> Result<ResearchRunResult, String> {
    state.clear_research_stop();
    let settings = state.settings();
    crate::research::run(&app, &goal, &settings).await
}

#[tauri::command]
pub fn research_stop(state: State<AppState>) -> Result<(), String> {
    state.request_research_stop();
    Ok(())
}

#[tauri::command]
pub fn history_list(
    app: AppHandle,
    query: Option<String>,
    limit: Option<u32>,
) -> Result<Vec<VisitEntry>, String> {
    visit_history::list(
        &app,
        query.as_deref().unwrap_or(""),
        limit.unwrap_or(50).clamp(1, 100) as usize,
    )
}

#[tauri::command]
pub async fn history_clear(app: AppHandle) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || visit_history::clear(&app))
        .await
        .map_err(|err| err.to_string())?
}

#[tauri::command]
pub fn history_enabled_get(state: State<AppState>) -> Result<bool, String> {
    Ok(state.settings().history_enabled)
}

#[tauri::command]
pub fn history_enabled_set(
    app: AppHandle,
    state: State<AppState>,
    enabled: bool,
) -> Result<bool, String> {
    let mut settings = state.settings();
    settings.history_enabled = enabled;
    if !enabled {
        settings.ai_history_enabled = false;
    }
    state.set_settings(&app, settings)?;
    Ok(state.settings().history_enabled)
}

#[tauri::command]
pub fn history_ai_enabled_get(state: State<AppState>) -> Result<bool, String> {
    Ok(state.settings().ai_history_enabled)
}

#[tauri::command]
pub fn history_ai_enabled_set(
    app: AppHandle,
    state: State<AppState>,
    enabled: bool,
) -> Result<bool, String> {
    let mut settings = state.settings();
    if enabled && !settings.history_enabled {
        return Err("Enable browsing history before allowing AI access.".into());
    }
    settings.ai_history_enabled = enabled;
    state.set_settings(&app, settings)?;
    Ok(state.settings().ai_history_enabled)
}

#[tauri::command]
pub fn bookmark_list(app: AppHandle) -> Result<Vec<Bookmark>, String> {
    bookmarks::list(&app)
}

#[tauri::command]
pub fn bookmark_add(
    app: AppHandle,
    state: State<AppState>,
    url: Option<String>,
    title: Option<String>,
) -> Result<Bookmark, String> {
    #[cfg(target_os = "android")]
    mobile_sync_url(&app, &state);
    let snapshot = state.mobile_snapshot();
    let url = url.unwrap_or(snapshot.url);
    let title = title.unwrap_or(snapshot.title);
    bookmarks::add(&app, &url, &title)
}

#[tauri::command]
pub fn bookmark_remove(app: AppHandle, url: String) -> Result<(), String> {
    bookmarks::remove(&app, &url)
}

#[tauri::command]
pub fn bookmark_has(app: AppHandle, state: State<AppState>, url: Option<String>) -> Result<bool, String> {
    #[cfg(target_os = "android")]
    mobile_sync_url(&app, &state);
    let target = url.unwrap_or_else(|| state.mobile_snapshot().url);
    bookmarks::has_url(&app, &target)
}

#[tauri::command]
pub async fn clean_view_start(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<CleanViewState, String> {
    #[cfg(target_os = "android")]
    {
        app.browse_shell().set_touch_passthrough(true)?;
        let script = browser::clean_view::action_script("start");
        let value = browse_eval_async(&app, &script).await?;
        let active = browser::clean_view::parse_active(&value);
        if !active {
            let _ = app.browse_shell().set_touch_passthrough(false);
        }
        state.set_clean_view_active(active);
        emit_clean_view(&app, active);
        return Ok(CleanViewState { active });
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = (app, state);
        Err("Clean View requires the browse webview.".into())
    }
}

#[tauri::command]
pub fn clean_view_stop(app: AppHandle, state: State<AppState>) -> Result<CleanViewState, String> {
    stop_clean_view_session(&app, &state);
    #[cfg(target_os = "android")]
    {
        let _ = app.browse_shell().set_touch_passthrough(false);
    }
    Ok(CleanViewState { active: false })
}

#[tauri::command]
pub fn clean_view_status(state: State<AppState>) -> Result<CleanViewState, String> {
    Ok(CleanViewState {
        active: state.clean_view_active(),
    })
}
