use std::path::Path;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HardwareInfo {
    pub os: String,
    pub arch: String,
    pub ram_bytes: u64,
    pub ram_label: String,
    pub cpu_cores: u32,
    pub storage_free_bytes: u64,
    pub storage_label: String,
}

pub fn probe(storage_dir: &Path) -> HardwareInfo {
    let ram_bytes = physical_ram_bytes();
    let storage_free_bytes = free_space_bytes(storage_dir);
    HardwareInfo {
        os: std::env::consts::OS.to_string(),
        arch: std::env::consts::ARCH.to_string(),
        ram_bytes,
        ram_label: format_bytes(ram_bytes),
        cpu_cores: std::thread::available_parallelism()
            .map(|value| value.get() as u32)
            .unwrap_or(1),
        storage_free_bytes,
        storage_label: format_bytes(storage_free_bytes),
    }
}

/// Recommend the 7B catalogue entry only on machines with enough RAM.
pub fn recommend_large_model(ram_bytes: u64) -> bool {
    ram_bytes >= 16 * 1024 * 1024 * 1024
}

pub fn format_bytes(bytes: u64) -> String {
    const GB: f64 = 1024.0 * 1024.0 * 1024.0;
    const MB: f64 = 1024.0 * 1024.0;
    if bytes >= (GB as u64) {
        format!("{:.1} GB", bytes as f64 / GB)
    } else {
        format!("{:.0} MB", bytes as f64 / MB)
    }
}

#[cfg(windows)]
fn physical_ram_bytes() -> u64 {
    #[repr(C)]
    struct MemoryStatusEx {
        length: u32,
        memory_load: u32,
        total_phys: u64,
        avail_phys: u64,
        total_page_file: u64,
        avail_page_file: u64,
        total_virtual: u64,
        avail_virtual: u64,
        avail_extended_virtual: u64,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn GlobalMemoryStatusEx(status: *mut MemoryStatusEx) -> i32;
    }

    unsafe {
        let mut status = std::mem::zeroed::<MemoryStatusEx>();
        status.length = std::mem::size_of::<MemoryStatusEx>() as u32;
        if GlobalMemoryStatusEx(&mut status) != 0 {
            status.total_phys
        } else {
            0
        }
    }
}

#[cfg(all(unix, not(target_os = "ios")))]
fn physical_ram_bytes() -> u64 {
    memtotal_from_proc().unwrap_or(0)
}

#[cfg(all(unix, not(target_os = "ios")))]
fn memtotal_from_proc() -> Option<u64> {
    let text = std::fs::read_to_string("/proc/meminfo").ok()?;
    for line in text.lines() {
        if line.starts_with("MemTotal:") {
            let kb: u64 = line.split_whitespace().nth(1)?.parse().ok()?;
            return Some(kb.saturating_mul(1024));
        }
    }
    None
}

#[cfg(all(not(windows), not(all(unix, not(target_os = "ios")))))]
fn physical_ram_bytes() -> u64 {
    0
}

#[cfg(windows)]
fn free_space_bytes(dir: &Path) -> u64 {
    use std::os::windows::ffi::OsStrExt;

    #[link(name = "kernel32")]
    extern "system" {
        fn GetDiskFreeSpaceExW(
            directory: *const u16,
            free_bytes_available: *mut u64,
            total_number_of_bytes: *mut u64,
            total_number_of_free_bytes: *mut u64,
        ) -> i32;
    }

    let mut wide: Vec<u16> = dir.as_os_str().encode_wide().collect();
    wide.push(0);
    let mut available = 0u64;
    unsafe {
        if GetDiskFreeSpaceExW(wide.as_ptr(), &mut available, std::ptr::null_mut(), std::ptr::null_mut())
            != 0
        {
            available
        } else {
            0
        }
    }
}

#[cfg(all(unix, not(target_os = "ios")))]
fn free_space_bytes(dir: &Path) -> u64 {
    statvfs_available_bytes(dir).unwrap_or(0)
}

#[cfg(all(unix, not(target_os = "ios")))]
fn statvfs_available_bytes(dir: &Path) -> Option<u64> {
    use std::ffi::CString;
    use std::mem::MaybeUninit;

    #[repr(C)]
    struct StatVfs {
        f_bsize: u64,
        f_frsize: u64,
        f_blocks: u64,
        f_bfree: u64,
        f_bavail: u64,
        f_files: u64,
        f_ffree: u64,
        f_favail: u64,
        f_fsid: [i32; 2],
        f_flag: u64,
        f_namemax: u64,
    }

    extern "C" {
        fn statvfs(path: *const std::os::raw::c_char, buf: *mut StatVfs) -> i32;
    }

    let path = CString::new(dir.as_os_str().to_str().unwrap_or(".")).ok()?;
    let mut buf = MaybeUninit::<StatVfs>::uninit();
    let rc = unsafe { statvfs(path.as_ptr(), buf.as_mut_ptr()) };
    if rc != 0 {
        return None;
    }
    let stat = unsafe { buf.assume_init() };
    Some(stat.f_bavail.saturating_mul(stat.f_frsize))
}

#[cfg(all(not(windows), not(all(unix, not(target_os = "ios")))))]
fn free_space_bytes(_dir: &Path) -> u64 {
    0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn large_model_needs_16gb() {
        assert!(!recommend_large_model(8 * 1024 * 1024 * 1024));
        assert!(recommend_large_model(16 * 1024 * 1024 * 1024));
    }
}
