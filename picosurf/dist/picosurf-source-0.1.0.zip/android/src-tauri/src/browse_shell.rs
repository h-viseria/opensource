#![cfg(target_os = "android")]

use serde::Deserialize;
use serde_json::Value;
use tauri::{
    plugin::{Builder, PluginHandle, TauriPlugin},
    Manager, Runtime,
};

pub struct BrowseShell<R: Runtime> {
    mobile_plugin_handle: Option<PluginHandle<R>>,
}

pub trait BrowseShellExt<R: Runtime> {
    fn browse_shell(&self) -> &BrowseShell<R>;
}

impl<R: Runtime, T: Manager<R>> BrowseShellExt<R> for T {
    fn browse_shell(&self) -> &BrowseShell<R> {
        self.state::<BrowseShell<R>>().inner()
    }
}

#[derive(Deserialize)]
struct HandledResponse {
    handled: bool,
}

#[derive(Deserialize)]
struct UrlResponse {
    url: String,
}

#[derive(Deserialize)]
struct EvalResponse {
    raw: String,
}

#[derive(Deserialize)]
pub struct PageMetaResponse {
    pub url: String,
    pub title: String,
    pub ready: bool,
}

impl<R: Runtime> BrowseShell<R> {
    fn handle(&self) -> Result<&PluginHandle<R>, String> {
        self.mobile_plugin_handle
            .as_ref()
            .ok_or_else(|| "Browse shell is not available on this device.".into())
    }

    pub fn load_url(&self, url: &str) -> Result<(), String> {
        self.handle()?
            .run_mobile_plugin("loadUrl", serde_json::json!({ "url": url }))
            .map_err(|err| err.to_string())
    }

    pub fn reload(&self) -> Result<(), String> {
        self.handle()?
            .run_mobile_plugin("reload", serde_json::json!({}))
            .map_err(|err| err.to_string())
    }

    pub fn go_back(&self) -> Result<bool, String> {
        let resp: HandledResponse = self
            .handle()?
            .run_mobile_plugin("goBack", serde_json::json!({}))
            .map_err(|err| err.to_string())?;
        Ok(resp.handled)
    }

    pub fn go_forward(&self) -> Result<bool, String> {
        let resp: HandledResponse = self
            .handle()?
            .run_mobile_plugin("goForward", serde_json::json!({}))
            .map_err(|err| err.to_string())?;
        Ok(resp.handled)
    }

    pub fn current_url(&self) -> Result<String, String> {
        let resp: UrlResponse = self
            .handle()?
            .run_mobile_plugin("getUrl", serde_json::json!({}))
            .map_err(|err| err.to_string())?;
        Ok(resp.url)
    }

    pub fn set_insets(&self, top_px: i32, bottom_px: i32) -> Result<(), String> {
        self.handle()?.run_mobile_plugin(
            "setInsets",
            serde_json::json!({ "topPx": top_px, "bottomPx": bottom_px }),
        ).map_err(|err| err.to_string())
    }

    pub fn page_title(&self) -> Result<String, String> {
        #[derive(Deserialize)]
        struct TitleResponse {
            title: String,
        }
        let resp: TitleResponse = self
            .handle()?
            .run_mobile_plugin("getTitle", serde_json::json!({}))
            .map_err(|err| err.to_string())?;
        Ok(resp.title)
    }

    pub fn page_meta(&self) -> Result<PageMetaResponse, String> {
        self.handle()?
            .run_mobile_plugin("getPageMeta", serde_json::json!({}))
            .map_err(|err| err.to_string())
    }

    pub fn set_touch_passthrough(&self, enabled: bool) -> Result<(), String> {
        self.handle()?
            .run_mobile_plugin(
                "setTouchPassthrough",
                serde_json::json!({ "enabled": enabled }),
            )
            .map_err(|err| err.to_string())
    }

    pub async fn eval_json_async(&self, script: &str) -> Result<Value, String> {
        let wrapped = format!(
            "(function(){{ try {{ const __r = ({script}); return __r; }} catch (e) {{ return {{ ok: false, error: String((e && e.message) || e) }}; }} }})()"
        );
        let resp: EvalResponse = self
            .handle()?
            .run_mobile_plugin_async("evalJson", serde_json::json!({ "script": wrapped }))
            .await
            .map_err(|err| err.to_string())?;
        parse_eval_raw(&resp.raw)
    }
}

fn parse_eval_raw(raw: &str) -> Result<Value, String> {
    let trimmed = raw.trim();
    if trimmed.is_empty() || trimmed == "null" || trimmed == "undefined" {
        return Err("The page did not answer.".into());
    }
    let value = decode_eval_payload(trimmed)?;
    if value.get("ok").and_then(Value::as_bool) == Some(false) {
        let error = value
            .get("error")
            .and_then(Value::as_str)
            .unwrap_or("Page script failed");
        return Err(error.to_string());
    }
    Ok(value)
}

fn decode_eval_payload(raw: &str) -> Result<Value, String> {
    if let Ok(value) = serde_json::from_str::<Value>(raw) {
        if let Some(inner) = value.as_str() {
            if let Ok(parsed) = serde_json::from_str::<Value>(inner) {
                return Ok(parsed);
            }
        }
        return Ok(value);
    }
    if let Ok(inner) = serde_json::from_str::<String>(raw) {
        if let Ok(value) = serde_json::from_str::<Value>(&inner) {
            return Ok(value);
        }
        return Err(inner);
    }
    Err(raw.to_string())
}

pub fn init<R: Runtime>() -> TauriPlugin<R> {
    Builder::<R>::new("browse-shell")
        .setup(|app, api| {
            let handle = api
                .register_android_plugin("com.picosurf.android", "BrowseShellPlugin")
                .ok();
            if handle.is_none() {
                eprintln!("browse-shell: failed to register BrowseShellPlugin");
            }
            app.manage(BrowseShell {
                mobile_plugin_handle: handle,
            });
            Ok(())
        })
        .build()
}
