use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};
use tauri::AppHandle;
use url::Url;

use crate::security;
use crate::storage;

const MAX_BOOKMARKS: usize = 200;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct Bookmark {
    pub id: String,
    pub url: String,
    pub title: String,
    pub domain: String,
    pub saved_at: u64,
}

pub fn file_path(app: &AppHandle) -> Result<PathBuf, String> {
    storage::data_file(app, "bookmarks.json")
}

pub fn load(path: &Path) -> Vec<Bookmark> {
    storage::read_json_or_default(path)
}

pub fn store(path: &Path, items: &[Bookmark]) -> Result<(), String> {
    storage::write_json(path, items)
}

pub fn list(app: &AppHandle) -> Result<Vec<Bookmark>, String> {
    Ok(load(&file_path(app)?))
}

pub fn has_url(app: &AppHandle, url: &str) -> Result<bool, String> {
    let items = load(&file_path(app)?);
    Ok(items.iter().any(|item| item.url == url))
}

pub fn add(app: &AppHandle, url: &str, title: &str) -> Result<Bookmark, String> {
    let parsed = Url::parse(url).map_err(|err| format!("Invalid URL: {err}"))?;
    if !security::is_allowed_navigation(&parsed) {
        return Err("That page cannot be bookmarked.".into());
    }
    let path = file_path(app)?;
    let mut items = load(&path);
    let domain = parsed.host_str().unwrap_or("").to_string();
    let clean_title = sanitize(title, 160);
    let title = if clean_title.is_empty() {
        domain.clone()
    } else {
        clean_title
    };
    let now = now_unix();
    if let Some(existing) = items.iter_mut().find(|item| item.url == url) {
        existing.title = title.clone();
        existing.saved_at = now;
        let bookmark = existing.clone();
        store(&path, &items)?;
        return Ok(bookmark);
    }
    let bookmark = Bookmark {
        id: format!("bm-{now}"),
        url: parsed.to_string(),
        title,
        domain,
        saved_at: now,
    };
    items.insert(0, bookmark.clone());
    items.truncate(MAX_BOOKMARKS);
    store(&path, &items)?;
    Ok(bookmark)
}

pub fn remove(app: &AppHandle, url: &str) -> Result<(), String> {
    let path = file_path(app)?;
    let mut items = load(&path);
    items.retain(|item| item.url != url);
    store(&path, &items)
}

fn sanitize(raw: &str, max: usize) -> String {
    raw.chars()
        .filter(|ch| *ch != '\0' && (*ch == '\n' || *ch == '\t' || !ch.is_control()))
        .take(max)
        .collect()
}

fn now_unix() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|item| item.as_secs())
        .unwrap_or(0)
}
