mod ai;
mod bookmarks;
#[cfg(target_os = "android")]
mod browse_shell;
#[cfg(target_os = "android")]
mod research_shell;
mod browser;
mod commands;
mod models;
mod platform;
mod research;
mod search;
mod security;
mod settings;
mod state;
mod storage;
mod visit_history;

use tauri::Manager;

use crate::settings::AppMode;
use crate::state::AppState;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let mut builder = tauri::Builder::default().plugin(tauri_plugin_opener::init());
    #[cfg(target_os = "android")]
    {
        builder = builder
            .plugin(browse_shell::init())
            .plugin(research_shell::init());
    }
    builder
        .manage(AppState::default())
        .setup(|app| {
            if let Some(state) = app.try_state::<AppState>() {
                state.load_from_disk(app.handle());
                let _ = state.default_to_browse_when_research_not_ready(app.handle());
                #[cfg(target_os = "android")]
                if state.settings().mode == AppMode::Research {
                    use crate::browse_shell::BrowseShellExt;
                    let _ = app.browse_shell().set_content_visible(false);
                }
            }
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::browser_navigate,
            commands::browser_back,
            commands::browser_forward,
            commands::browser_reload,
            commands::browser_state,
            commands::browse_uses_embedded_frame,
            commands::browser_ensure,
            commands::layout_sync,
            commands::settings_get,
            commands::settings_set,
            commands::app_mode_get,
            commands::app_mode_set,
            commands::research_feature_status,
            commands::research_feature_request_install,
            commands::research_run,
            commands::research_stop,
            commands::omnibox_resolve,
            commands::models::models_list,
            commands::models::models_select,
            commands::models::models_download,
            commands::models::models_cancel,
            commands::models::models_load,
            commands::models::models_unload,
            commands::models::ai_generate,
            commands::history_list,
            commands::history_clear,
            commands::history_enabled_get,
            commands::history_enabled_set,
            commands::history_ai_enabled_get,
            commands::history_ai_enabled_set,
            commands::bookmark_list,
            commands::bookmark_add,
            commands::bookmark_remove,
            commands::bookmark_has,
            commands::clean_view_start,
            commands::clean_view_stop,
            commands::clean_view_status,
        ])
        .run(tauri::generate_context!())
        .unwrap_or_else(|err| {
            eprintln!("PicoSurf Android failed to start: {err}");
            std::process::exit(1);
        });
}
