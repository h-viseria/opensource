#![cfg(target_os = "android")]

use serde::Deserialize;
use serde_json::Value;
use tauri::{
    plugin::{Builder, PluginHandle, TauriPlugin},
    Manager, Runtime,
};

pub struct ResearchShell<R: Runtime> {
    mobile_plugin_handle: Option<PluginHandle<R>>,
}

pub trait ResearchShellExt<R: Runtime> {
    fn research_shell(&self) -> &ResearchShell<R>;
}

impl<R: Runtime, T: Manager<R>> ResearchShellExt<R> for T {
    fn research_shell(&self) -> &ResearchShell<R> {
        self.state::<ResearchShell<R>>().inner()
    }
}

#[derive(Deserialize)]
struct EvalResponse {
    raw: String,
}

#[derive(Deserialize)]
pub struct PageMetaResponse {
    pub url: String,
    pub title: String,
    pub ready: bool,
}

impl<R: Runtime> ResearchShell<R> {
    fn handle(&self) -> Result<&PluginHandle<R>, String> {
        self.mobile_plugin_handle
            .as_ref()
            .ok_or_else(|| "Research fetch layer is not available.".into())
    }

    pub fn load_url(&self, url: &str) -> Result<(), String> {
        self.handle()?
            .run_mobile_plugin("loadUrl", serde_json::json!({ "url": url }))
            .map_err(|err| err.to_string())
    }

    pub fn page_meta(&self) -> Result<PageMetaResponse, String> {
        self.handle()?
            .run_mobile_plugin("getPageMeta", serde_json::json!({}))
            .map_err(|err| err.to_string())
    }

    pub fn current_url(&self) -> Result<String, String> {
        #[derive(Deserialize)]
        struct UrlResponse {
            url: String,
        }
        let resp: UrlResponse = self
            .handle()?
            .run_mobile_plugin("getUrl", serde_json::json!({}))
            .map_err(|err| err.to_string())?;
        Ok(resp.url)
    }

    pub async fn eval_json_async(&self, script: &str) -> Result<Value, String> {
        let wrapped = format!(
            "(function(){{ try {{ const __r = ({script}); return __r; }} catch (e) {{ return {{ ok: false, error: String((e && e.message) || e) }}; }} }})()"
        );
        let resp: EvalResponse = self
            .handle()?
            .run_mobile_plugin_async("evalJson", serde_json::json!({ "script": wrapped }))
            .await
            .map_err(|err| err.to_string())?;
        parse_eval_raw(&resp.raw)
    }
}

fn parse_eval_raw(raw: &str) -> Result<Value, String> {
    let trimmed = raw.trim();
    if trimmed.is_empty() || trimmed == "null" || trimmed == "undefined" {
        return Err("The page did not answer.".into());
    }
    let value = decode_eval_payload(trimmed)?;
    if value.get("ok").and_then(Value::as_bool) == Some(false) {
        let error = value
            .get("error")
            .and_then(Value::as_str)
            .unwrap_or("Page script failed");
        return Err(error.to_string());
    }
    Ok(value)
}

fn decode_eval_payload(raw: &str) -> Result<Value, String> {
    if let Ok(value) = serde_json::from_str::<Value>(raw) {
        if let Some(inner) = value.as_str() {
            if let Ok(parsed) = serde_json::from_str::<Value>(inner) {
                return Ok(parsed);
            }
        }
        return Ok(value);
    }
    if let Ok(inner) = serde_json::from_str::<String>(raw) {
        if let Ok(value) = serde_json::from_str::<Value>(&inner) {
            return Ok(value);
        }
        return Err(inner);
    }
    Err(raw.to_string())
}

pub fn init<R: Runtime>() -> TauriPlugin<R> {
    Builder::<R>::new("research-shell")
        .setup(|app, api| {
            let handle = api
                .register_android_plugin("com.picosurf.android", "ResearchShellPlugin")
                .ok();
            if handle.is_none() {
                eprintln!("research-shell: failed to register ResearchShellPlugin");
            }
            app.manage(ResearchShell {
                mobile_plugin_handle: handle,
            });
            Ok(())
        })
        .build()
}
