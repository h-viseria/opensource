use serde::{Deserialize, Serialize};
use url::Url;

use crate::ai::prompt;
use crate::security;

const EXTRACT_JS: &str = include_str!("search/extract.js");

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum SearchEngine {
    DuckDuckGo,
    Google,
    Bing,
    Brave,
    Custom,
}

impl SearchEngine {
    pub fn from_id(id: &str) -> Self {
        match id.trim().to_ascii_lowercase().as_str() {
            "google" => Self::Google,
            "bing" => Self::Bing,
            "brave" => Self::Brave,
            "custom" => Self::Custom,
            _ => Self::DuckDuckGo,
        }
    }

    pub fn display_name(self) -> &'static str {
        match self {
            Self::DuckDuckGo => "DuckDuckGo",
            Self::Google => "Google",
            Self::Bing => "Bing",
            Self::Brave => "Brave Search",
            Self::Custom => "Custom",
        }
    }

    pub fn template(self) -> &'static str {
        match self {
            Self::DuckDuckGo => "https://html.duckduckgo.com/html/?q={query}&kl=en-us",
            Self::Google => "https://www.google.com/search?q={query}&hl=en",
            Self::Bing => "https://www.bing.com/search?q={query}&setlang=en-us",
            Self::Brave => "https://search.brave.com/search?q={query}&lang=en",
            Self::Custom => "",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SearchSettings {
    pub engine: String,
    #[serde(default = "default_research_engine")]
    pub research_engine: String,
    pub custom_template: String,
}

fn default_research_engine() -> String {
    "same".into()
}

impl Default for SearchSettings {
    fn default() -> Self {
        Self {
            engine: "duckduckgo".into(),
            research_engine: "same".into(),
            custom_template: String::new(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct SearchResult {
    pub title: String,
    pub url: String,
    pub snippet: String,
    pub domain: String,
    pub position: u32,
}

pub fn build_search_url(
    engine: SearchEngine,
    query: &str,
    custom_template: &str,
) -> Result<Url, String> {
    let template = if engine == SearchEngine::Custom {
        validate_template(custom_template)?;
        custom_template.trim()
    } else {
        engine.template()
    };
    build_search_url_from_template(template, query)
}

fn validate_template(template: &str) -> Result<(), String> {
    let trimmed = template.trim();
    if trimmed.is_empty() || !trimmed.contains("{query}") {
        return Err("Custom search template must include {query}.".into());
    }
    let sample = build_search_url_from_template(trimmed, "picosurf")?;
    if !security::is_allowed_navigation(&sample) {
        return Err("That search template is not an allowed http(s) address.".into());
    }
    Ok(())
}

fn build_search_url_from_template(template: &str, query: &str) -> Result<Url, String> {
    let q = query.trim();
    if q.is_empty() {
        return Err("Search query was empty.".into());
    }
    let encoded = urlencoding_lite(q);
    let resolved = template.replace("{query}", &encoded);
    Url::parse(&resolved).map_err(|err| format!("Invalid search URL: {err}"))
}

pub fn resolve_omnibox(input: &str, settings: &SearchSettings) -> Result<Url, String> {
    if let Some(query) = security::force_search_prefix(input) {
        let engine = SearchEngine::from_id(&settings.engine);
        return build_search_url(engine, query, &settings.custom_template);
    }
    match security::parse_url_or_host(input)? {
        Some(url) => Ok(url),
        None => {
            let engine = SearchEngine::from_id(&settings.engine);
            build_search_url(engine, input.trim(), &settings.custom_template)
        }
    }
}

fn urlencoding_lite(value: &str) -> String {
    let mut out = String::new();
    for ch in value.chars() {
        match ch {
            'A'..='Z' | 'a'..='z' | '0'..='9' | '-' | '_' | '.' | '~' => out.push(ch),
            ' ' => out.push('+'),
            _ => {
                for byte in ch.encode_utf8(&mut [0; 4]).bytes() {
                    out.push_str(&format!("%{byte:02X}"));
                }
            }
        }
    }
    out
}

pub fn extract_script() -> &'static str {
    EXTRACT_JS
}

pub fn research_engine(settings: &SearchSettings) -> SearchEngine {
    if settings.research_engine.eq_ignore_ascii_case("same") || settings.research_engine.is_empty() {
        SearchEngine::from_id(&settings.engine)
    } else {
        SearchEngine::from_id(&settings.research_engine)
    }
}

pub fn parse_search_results(engine: SearchEngine, value: &serde_json::Value) -> Vec<SearchResult> {
    let raw = value
        .get("results")
        .and_then(serde_json::Value::as_array)
        .cloned()
        .unwrap_or_default();
    let mut out = Vec::new();
    for item in raw {
        let title = item
            .get("title")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("")
            .trim();
        let raw_url = item
            .get("url")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("")
            .trim();
        let snippet = item
            .get("snippet")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("")
            .trim();
        let Some(parsed) = result_from_link(engine, title, raw_url, snippet, (out.len() as u32) + 1)
        else {
            continue;
        };
        out.push(parsed);
        if out.len() >= 10 {
            break;
        }
    }
    out
}

pub fn result_from_link(
    engine: SearchEngine,
    title: &str,
    raw_url: &str,
    snippet: &str,
    position: u32,
) -> Option<SearchResult> {
    let url = unwrap_result_url(engine, raw_url)?;
    if is_internal_result(engine, &url) {
        return None;
    }
    if title.trim().len() < 8 {
        return None;
    }
    let domain = url.host_str()?.to_string();
    Some(SearchResult {
        title: prompt::sanitize_untrusted(title).chars().take(160).collect(),
        url: url.to_string(),
        snippet: prompt::sanitize_untrusted(snippet).chars().take(240).collect(),
        domain,
        position,
    })
}

fn unwrap_result_url(engine: SearchEngine, raw: &str) -> Option<Url> {
    let parsed = Url::parse(raw).ok()?;
    if !security::is_allowed_navigation(&parsed) {
        return None;
    }
    match engine {
        SearchEngine::DuckDuckGo => {
            if parsed.host_str()?.contains("duckduckgo") {
                if let Some((_, dest)) = parsed.query_pairs().find(|(key, _)| key == "uddg") {
                    return Url::parse(&dest).ok().filter(security::is_allowed_navigation);
                }
            }
            Some(parsed)
        }
        SearchEngine::Google => {
            if parsed.host_str()?.contains("google.") && parsed.path() == "/url" {
                if let Some((_, dest)) = parsed.query_pairs().find(|(key, _)| key == "q") {
                    return Url::parse(&dest).ok().filter(security::is_allowed_navigation);
                }
            }
            Some(parsed)
        }
        _ => Some(parsed),
    }
}

fn is_internal_result(engine: SearchEngine, url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    match engine {
        SearchEngine::DuckDuckGo => host.contains("duckduckgo.com"),
        SearchEngine::Google => host.contains("google.") || host.contains("gstatic.com"),
        SearchEngine::Bing => host.contains("bing.com") || host.contains("microsoft.com"),
        SearchEngine::Brave => host.contains("brave.com") && !host.contains("search.brave.com"),
        SearchEngine::Custom => false,
    }
}

pub fn looks_blocked(title: &str, body: &str) -> bool {
    let blob = format!("{title} {body}").to_ascii_lowercase();
    [
        "captcha",
        "unusual traffic",
        "verify you are human",
        "are you a robot",
        "enable javascript",
        "access denied",
        "sorry, you have been blocked",
    ]
    .iter()
    .any(|needle| blob.contains(needle))
}
