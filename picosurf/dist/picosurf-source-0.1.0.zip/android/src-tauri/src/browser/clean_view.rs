use serde_json::Value;

const BOOTSTRAP_JS: &str = include_str!("clean_view.js");

/// Script passed to the browse webview. On Android the bootstrap is injected from assets on page load.
pub fn action_script(action: &str) -> String {
    #[cfg(target_os = "android")]
    {
        return format!(
            "(function(){{ try {{ if(!window.__picosurfCleanView){{ return {{ ok:false, error:'Clean View is not ready yet. Wait for the page to finish loading.' }}; }} return window.__picosurfCleanView.{action}(); }} catch(e){{ return {{ ok:false, error:String((e && e.message) || e) }}; }} }})()"
        );
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = action;
        String::new()
    }
}

fn wrap(action: &str) -> String {
    #[cfg(target_os = "android")]
    {
        return action_script(action);
    }
    #[cfg(not(target_os = "android"))]
    {
        format!(
            "(function(){{ {BOOTSTRAP_JS} return window.__picosurfCleanView.{action}(); }})()"
        )
    }
}

pub fn parse_active(value: &Value) -> bool {
    value
        .get("active")
        .and_then(Value::as_bool)
        .unwrap_or(false)
}

pub fn start(eval: impl FnOnce(&str) -> Result<Value, String>) -> Result<bool, String> {
    run_action(eval, "start")
}

pub fn stop(eval: impl FnOnce(&str) -> Result<Value, String>) -> Result<bool, String> {
    run_action(eval, "stop")
}

pub fn status(eval: impl FnOnce(&str) -> Result<Value, String>) -> Result<bool, String> {
    run_action(eval, "status")
}

fn run_action(
    eval: impl FnOnce(&str) -> Result<Value, String>,
    action: &str,
) -> Result<bool, String> {
    let value = eval(&wrap(action))?;
    Ok(parse_active(&value))
}
