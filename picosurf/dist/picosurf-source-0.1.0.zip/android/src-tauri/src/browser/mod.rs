pub mod clean_view;
pub mod eval;
#[cfg(mobile)]
pub mod mobile;
pub mod page;
pub mod research_fetch;

pub use page::UntrustedPage;

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Manager, Webview, WebviewWindow};
#[cfg(desktop)]
use tauri::{LogicalPosition, LogicalSize};

pub const BROWSER_LABEL: &str = "browser";
pub const RESEARCH_LABEL: &str = "research-fetch";
pub const START_URL: &str = "https://duckduckgo.com/";

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct BrowserState {
    pub url: String,
    pub title: String,
    pub can_go_back: bool,
    pub can_go_forward: bool,
    /// Browse content WebView finished its current load (Android embedded shell).
    #[serde(default)]
    pub page_ready: bool,
}

#[derive(Default)]
pub struct History {
    entries: Vec<String>,
    index: usize,
}

impl History {
    pub fn can_go_back(&self) -> bool {
        self.index > 0
    }

    pub fn can_go_forward(&self) -> bool {
        !self.entries.is_empty() && self.index + 1 < self.entries.len()
    }

    pub fn record(&mut self, url: &str) {
        if self.entries.get(self.index).map(String::as_str) == Some(url) {
            return;
        }
        if !self.entries.is_empty() {
            self.entries.truncate(self.index + 1);
        }
        self.entries.push(url.to_string());
        self.index = self.entries.len().saturating_sub(1);
    }

    pub fn go_back(&mut self) -> Option<String> {
        if !self.can_go_back() {
            return None;
        }
        self.index -= 1;
        self.entries.get(self.index).cloned()
    }

    pub fn go_forward(&mut self) -> Option<String> {
        if !self.can_go_forward() {
            return None;
        }
        self.index += 1;
        self.entries.get(self.index).cloned()
    }
}

pub fn snapshot(webview: &Webview, history: &History, title: &str) -> BrowserState {
    let url = webview
        .url()
        .map(|u| u.to_string())
        .unwrap_or_else(|_| START_URL.into());
    snapshot_from_url(&url, history, title)
}

pub fn snapshot_from_url(url: &str, history: &History, title: &str) -> BrowserState {
    BrowserState {
        url: url.to_string(),
        title: title.to_string(),
        can_go_back: history.can_go_back(),
        can_go_forward: history.can_go_forward(),
        page_ready: true,
    }
}

pub fn apply_bounds(
    window: &WebviewWindow,
    browser: &Webview,
    toolbar_height: f64,
    bottom_nav_height: f64,
) -> Result<(), String> {
    // Child webview move/resize from Rust is desktop-only; on Android/iOS the UI
    // repositions via @tauri-apps/api/webview (see useBrowserWebview.ts).
    #[cfg(desktop)]
    {
        let factor = window.scale_factor().map_err(|err| err.to_string())?;
        let size = window.inner_size().map_err(|err| err.to_string())?;
        let logical = size.to_logical::<f64>(factor);
        let height = (logical.height - toolbar_height - bottom_nav_height).max(120.0);
        browser
            .set_position(LogicalPosition::new(0.0, toolbar_height))
            .map_err(|err| err.to_string())?;
        browser
            .set_size(LogicalSize::new(logical.width.max(160.0), height))
            .map_err(|err| err.to_string())?;
    }
    #[cfg(mobile)]
    {
        let _ = (window, browser, toolbar_height, bottom_nav_height);
    }
    Ok(())
}

pub fn browser_webview(app: &AppHandle) -> Result<Webview, String> {
    app.get_webview(BROWSER_LABEL)
        .ok_or_else(|| "Browser webview is not ready. Open Browse mode first.".into())
}

pub fn research_webview(app: &AppHandle) -> Result<Webview, String> {
    app.get_webview(RESEARCH_LABEL).ok_or_else(|| {
        "Research fetch webview is not ready. Switch to Research and wait a moment.".into()
    })
}
