use tauri::AppHandle;

/// Android/iOS only expose one [`WebView`] per activity via `setWebView` (see Wry).
/// Creating a second webview here would replace the main UI webview — do not build one.
pub fn ensure_browser_webview(_app: &AppHandle) -> Result<(), String> {
    Ok(())
}
