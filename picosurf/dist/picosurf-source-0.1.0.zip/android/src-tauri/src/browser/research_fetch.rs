use std::time::Duration;

use serde_json::Value;
use tauri::{AppHandle, Manager};
use url::Url;

use crate::browser::{eval, page, research_webview};
use crate::state::AppState;

const READ_JS: &str = include_str!("read.js");

fn research_stopped(app: &AppHandle) -> bool {
    app.state::<AppState>().research_stop_requested()
}

pub async fn navigate(app: &AppHandle, url: Url) -> Result<(), String> {
    if research_stopped(app) {
        return Err("Stopped.".into());
    }
    #[cfg(target_os = "android")]
    {
        use crate::research_shell::ResearchShellExt;
        app.research_shell().load_url(url.as_str())?;
        wait_for_http_page(app).await
    }
    #[cfg(not(target_os = "android"))]
    {
        let webview = research_webview(app)?;
        webview.navigate(url).map_err(|err| err.to_string())?;
        wait_for_http_page(app).await
    }
}

pub async fn current_document_url(app: &AppHandle, fallback: &str) -> String {
    #[cfg(target_os = "android")]
    {
        use crate::research_shell::ResearchShellExt;
        app.research_shell()
            .current_url()
            .or_else(|_| app.research_shell().page_meta().map(|m| m.url))
            .unwrap_or_else(|_| fallback.to_string())
    }
    #[cfg(not(target_os = "android"))]
    {
        research_webview(app)
            .ok()
            .and_then(|w| w.url().ok())
            .map(|u| u.to_string())
            .unwrap_or_else(|| fallback.to_string())
    }
}

pub async fn eval_json(app: &AppHandle, script: &str) -> Result<Value, String> {
    if research_stopped(app) {
        return Err("Stopped.".into());
    }
    #[cfg(target_os = "android")]
    {
        use crate::research_shell::ResearchShellExt;
        app.research_shell().eval_json_async(script).await
    }
    #[cfg(not(target_os = "android"))]
    {
        let webview = research_webview(app)?;
        let script_owned = script.to_string();
        let app_handle = app.clone();
        tauri::async_runtime::spawn_blocking(move || {
            eval::eval_json_cancel(&webview, &script_owned, || {
                app_handle.state::<AppState>().research_stop_requested()
            })
        })
        .await
        .map_err(|err| err.to_string())?
    }
}

pub async fn read_page(app: &AppHandle) -> Result<page::UntrustedPage, String> {
    let value = eval_json(app, READ_JS).await?;
    page::from_eval_value(value)
}

async fn wait_for_http_page(app: &AppHandle) -> Result<(), String> {
    for _ in 0..40 {
        if research_stopped(app) {
            return Err("Stopped.".into());
        }
        tokio::time::sleep(Duration::from_millis(500)).await;
        #[cfg(target_os = "android")]
        {
            use crate::research_shell::ResearchShellExt;
            if let Ok(meta) = app.research_shell().page_meta() {
                if meta.ready {
                    let lower = meta.url.to_ascii_lowercase();
                    if lower.starts_with("http://") || lower.starts_with("https://") {
                        return Ok(());
                    }
                }
            }
        }
        #[cfg(not(target_os = "android"))]
        {
            if let Ok(webview) = research_webview(app) {
                if let Ok(url) = webview.url() {
                    if url.scheme() == "http" || url.scheme() == "https" {
                        return Ok(());
                    }
                }
            }
        }
    }
    Ok(())
}
