(() => {
  try {
    function clip(value, max) {
      const text = String(value || "")
        .replace(/\s+/g, " ")
        .trim();
      return text.length > max ? text.slice(0, max) : text;
    }

    const headings = Array.from(document.querySelectorAll("h1, h2, h3"))
      .map((el) => clip(el.innerText, 180))
      .filter(Boolean)
      .slice(0, 24);

    function mainRoot() {
      const selectors = [
        "article",
        "main",
        '[role="main"]',
        "#main-content",
        ".story",
        ".content-main",
      ];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el && el.innerText && el.innerText.trim().length > 200) {
          return el;
        }
      }
      return document.body || document.documentElement;
    }

    const root = mainRoot();
    let text = clip((root && root.innerText) || "", 12000);
    if (text.length < 400 && headings.length > 0) {
      text = clip(`${headings.join(". ")}. ${text}`, 12000);
    }

    return {
      ok: true,
      url: String(location.href || ""),
      origin: String(location.origin || ""),
      title: clip(document.title, 200),
      headings,
      text,
    };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
})()
