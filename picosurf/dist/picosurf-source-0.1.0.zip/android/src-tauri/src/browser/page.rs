use serde_json::Value;
use tauri::Webview;

use super::eval;

const READ_JS: &str = include_str!("read.js");

#[derive(Debug, Clone)]
pub struct UntrustedPage {
    pub url: String,
    pub origin: String,
    pub title: String,
    pub text: String,
}

pub fn read_page(webview: &Webview) -> Result<UntrustedPage, String> {
    let value = eval::eval_json(webview, READ_JS)?;
    from_eval_value(value)
}

pub fn from_eval_value(value: Value) -> Result<UntrustedPage, String> {
    if value.get("ok").and_then(Value::as_bool) == Some(false) {
        let error = value
            .get("error")
            .and_then(Value::as_str)
            .unwrap_or("Could not read page");
        return Err(error.into());
    }
    Ok(UntrustedPage {
        url: value
            .get("url")
            .and_then(Value::as_str)
            .unwrap_or("")
            .into(),
        origin: value
            .get("origin")
            .and_then(Value::as_str)
            .unwrap_or("")
            .into(),
        title: value
            .get("title")
            .and_then(Value::as_str)
            .unwrap_or("")
            .into(),
        text: value
            .get("text")
            .and_then(Value::as_str)
            .unwrap_or("")
            .into(),
    })
}

pub fn is_transient_page_error(err: &str) -> bool {
    eval::is_transient_page_error(err)
}
