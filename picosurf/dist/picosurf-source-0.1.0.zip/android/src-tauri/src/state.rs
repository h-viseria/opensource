use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

use tauri::{AppHandle, Emitter, Manager, Runtime, Webview, WebviewWindow};

use crate::ai::InferenceEngine;
use crate::browser::{self, BrowserState, History};
use crate::settings::{AndroidSettings, AppMode, LayoutSync};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum PendingNav {
    #[default]
    None,
    Back,
    Forward,
    Reload,
}

pub struct AppState {
    layout: Mutex<LayoutSync>,
    browse_url: Mutex<String>,
    title: Mutex<String>,
    history: Mutex<History>,
    pending: Mutex<PendingNav>,
    settings: Mutex<AndroidSettings>,
    selected_model: Mutex<Option<String>>,
    engine: Mutex<InferenceEngine>,
    download_cancel: Arc<AtomicBool>,
    model_op_busy: Arc<AtomicBool>,
    research_stop: Arc<AtomicBool>,
    clean_view_active: Mutex<bool>,
    history_settled_url: Mutex<Option<String>>,
}

impl Default for AppState {
    fn default() -> Self {
        Self {
            layout: Mutex::new(LayoutSync::default()),
            browse_url: Mutex::new(browser::START_URL.to_string()),
            title: Mutex::new(String::new()),
            history: Mutex::new(History::default()),
            pending: Mutex::new(PendingNav::None),
            settings: Mutex::new(AndroidSettings::default()),
            selected_model: Mutex::new(None),
            engine: Mutex::new(InferenceEngine::default()),
            download_cancel: Arc::new(AtomicBool::new(false)),
            model_op_busy: Arc::new(AtomicBool::new(false)),
            research_stop: Arc::new(AtomicBool::new(false)),
            clean_view_active: Mutex::new(false),
            history_settled_url: Mutex::new(None),
        }
    }
}

impl AppState {
    pub fn clear_history_settled_gate(&self) {
        if let Ok(mut slot) = self.history_settled_url.lock() {
            *slot = None;
        }
    }

    pub fn mark_history_settled(&self, url: &str) {
        if let Ok(mut slot) = self.history_settled_url.lock() {
            *slot = Some(url.to_string());
        }
    }

    pub fn history_already_settled(&self, url: &str) -> bool {
        self.history_settled_url
            .lock()
            .ok()
            .and_then(|slot| slot.clone())
            .is_some_and(|recorded| recorded == url)
    }

    pub fn clean_view_active(&self) -> bool {
        self.clean_view_active.lock().map(|v| *v).unwrap_or(false)
    }

    pub fn set_clean_view_active(&self, active: bool) {
        if let Ok(mut slot) = self.clean_view_active.lock() {
            *slot = active;
        }
    }

    pub fn load_from_disk(&self, app: &AppHandle) {
        let loaded = crate::storage::load_settings(app);
        if let Ok(mut settings) = self.settings.lock() {
            *settings = loaded;
        }
        if let Ok(mut selected) = self.selected_model.lock() {
            *selected = self
                .settings
                .lock()
                .ok()
                .and_then(|s| s.selected_model_id.clone());
        }
    }

    pub fn settings(&self) -> AndroidSettings {
        self.settings
            .lock()
            .map(|s| s.clone())
            .unwrap_or_default()
    }

    pub fn set_settings(&self, app: &AppHandle, settings: AndroidSettings) -> Result<(), String> {
        let settings = AndroidSettings {
            research: settings.research.clamp(),
            ..settings
        };
        if let Ok(mut selected) = self.selected_model.lock() {
            *selected = settings.selected_model_id.clone();
        }
        crate::storage::save_settings(app, &settings)?;
        if let Ok(mut slot) = self.settings.lock() {
            *slot = settings;
        }
        Ok(())
    }

    pub fn set_pending(&self, pending: PendingNav) {
        if let Ok(mut slot) = self.pending.lock() {
            *slot = pending;
        }
    }

    pub fn set_layout(&self, layout: LayoutSync) {
        if let Ok(mut slot) = self.layout.lock() {
            *slot = layout;
        }
    }

    pub fn apply_layout(&self, app: &AppHandle) -> Result<(), String> {
        let layout = self.layout.lock().map_err(|err| err.to_string())?;
        #[cfg(target_os = "android")]
        {
            use crate::browse_shell::BrowseShellExt;
            let top = layout.toolbar_height.round() as i32;
            let bottom = layout.bottom_nav_height.round() as i32;
            app.browse_shell().set_insets(top, bottom, layout.browse_overlay)?;
            return Ok(());
        }
        #[cfg(not(target_os = "android"))]
        {
            let window: WebviewWindow = app
                .get_webview_window("main")
                .ok_or_else(|| "Main window is not ready".to_string())?;
            let Some(browser) = app.get_webview(browser::BROWSER_LABEL) else {
                return Ok(());
            };
            browser::apply_bounds(
                &window,
                &browser,
                layout.toolbar_height,
                layout.bottom_nav_height,
            )
        }
    }

    pub fn snapshot(&self, webview: &Webview) -> BrowserState {
        let history = self.history.lock().ok();
        let title = self.title.lock().ok();
        browser::snapshot(
            webview,
            history.as_deref().unwrap_or(&History::default()),
            title.as_deref().map(String::as_str).unwrap_or(""),
        )
    }

    pub fn set_browse_url(&self, url: &str) {
        if let Ok(mut slot) = self.browse_url.lock() {
            *slot = url.to_string();
        }
    }

    pub fn set_page_title(&self, title: &str) {
        if let Ok(mut slot) = self.title.lock() {
            *slot = title.to_string();
        }
    }

    pub fn mobile_snapshot(&self) -> BrowserState {
        let history = self.history.lock().ok();
        let title = self.title.lock().ok();
        let url = self
            .browse_url
            .lock()
            .map(|u| u.clone())
            .unwrap_or_else(|_| browser::START_URL.to_string());
        browser::snapshot_from_url(
            &url,
            history.as_deref().unwrap_or(&History::default()),
            title.as_deref().map(String::as_str).unwrap_or(""),
        )
    }

    pub fn mobile_snapshot_for_app<R: Runtime>(&self, app: &AppHandle<R>) -> BrowserState {
        let mut snapshot = self.mobile_snapshot();
        #[cfg(target_os = "android")]
        {
            use crate::browse_shell::BrowseShellExt;
            snapshot.page_ready = app
                .browse_shell()
                .page_meta()
                .map(|meta| meta.ready)
                .unwrap_or(false);
        }
        snapshot
    }

    pub fn emit_browser_state_mobile<R: Runtime>(&self, app: &AppHandle<R>) {
        let snapshot = self.mobile_snapshot_for_app(app);
        if let Some(main) = app.get_webview("main") {
            let _ = main.emit("browser-state", snapshot);
        }
    }

    pub fn history_back_target(&self) -> Result<Option<String>, String> {
        let mut history = self.history.lock().map_err(|err| err.to_string())?;
        Ok(history.go_back())
    }

    pub fn history_forward_target(&self) -> Result<Option<String>, String> {
        let mut history = self.history.lock().map_err(|err| err.to_string())?;
        Ok(history.go_forward())
    }

    pub fn on_url_committed(&self, url: &str) {
        let pending = self
            .pending
            .lock()
            .ok()
            .map(|mut item| std::mem::take(&mut *item));
        let Ok(mut history) = self.history.lock() else {
            return;
        };
        match pending.unwrap_or_default() {
            PendingNav::Back | PendingNav::Forward | PendingNav::Reload => {}
            PendingNav::None => history.record(url),
        }
    }

    pub fn emit_browser_state(&self, app: &AppHandle, webview: &Webview) {
        let snapshot = self.snapshot(webview);
        if let Some(main) = app.get_webview("main") {
            let _ = main.emit("browser-state", snapshot);
        }
    }

    pub fn with_engine<T>(&self, f: impl FnOnce(&mut InferenceEngine) -> T) -> Result<T, String> {
        let mut engine = self.engine.lock().map_err(|err| err.to_string())?;
        Ok(f(&mut engine))
    }

    pub fn engine_loaded_id(&self) -> Option<String> {
        self.engine
            .lock()
            .ok()
            .and_then(|engine| engine.loaded_id())
    }

    pub fn loaded_model(&self) -> Option<String> {
        self.engine_loaded_id()
    }

    pub fn research_session_ready(&self) -> bool {
        let settings = self.settings();
        settings.research_feature_installed
            && settings.ai_enabled
            && self.engine_loaded_id().is_some()
    }

    /// Cold start / after unload: stay on Browse until a model is loaded for research.
    pub fn default_to_browse_when_research_not_ready(
        &self,
        app: &AppHandle,
    ) -> Result<(), String> {
        if self.settings().mode != AppMode::Research {
            return Ok(());
        }
        if self.research_session_ready() {
            return Ok(());
        }
        let mut settings = self.settings();
        settings.mode = AppMode::Browse;
        self.set_settings(app, settings)?;
        #[cfg(target_os = "android")]
        {
            use crate::browse_shell::BrowseShellExt;
            let _ = app.browse_shell().set_content_visible(true);
        }
        let _ = app.emit("app-mode-changed", AppMode::Browse);
        Ok(())
    }

    pub fn set_selected_model(&self, app: &AppHandle, id: Option<String>) -> Result<(), String> {
        if let Ok(mut slot) = self.selected_model.lock() {
            *slot = id.clone();
        }
        let mut settings = self.settings();
        settings.selected_model_id = id;
        self.set_settings(app, settings)
    }

    pub fn download_cancel(&self) -> Arc<AtomicBool> {
        self.download_cancel.clone()
    }

    pub fn begin_download(&self) {
        self.download_cancel.store(false, Ordering::Relaxed);
    }

    pub fn cancel_download(&self) {
        self.download_cancel.store(true, Ordering::Relaxed);
    }

    pub fn try_begin_model_op(&self) -> Result<(), String> {
        if self
            .model_op_busy
            .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
            .is_err()
        {
            return Err("A model operation is already in progress.".into());
        }
        Ok(())
    }

    pub fn end_model_op(&self) {
        self.model_op_busy.store(false, Ordering::SeqCst);
    }

    pub fn request_research_stop(&self) {
        self.research_stop.store(true, Ordering::Relaxed);
        self.with_engine(|engine| engine.request_stop()).ok();
    }

    pub fn clear_research_stop(&self) {
        self.research_stop.store(false, Ordering::Relaxed);
    }

    pub fn research_stop_requested(&self) -> bool {
        self.research_stop.load(Ordering::Relaxed)
            || self
                .engine
                .lock()
                .map(|engine| engine.stop_requested())
                .unwrap_or(false)
    }
}
