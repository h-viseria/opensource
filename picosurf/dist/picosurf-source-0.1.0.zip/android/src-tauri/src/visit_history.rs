use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};
use tauri::{AppHandle, Runtime};
use url::Url;

use crate::security;
use crate::storage;

const MAX_ENTRIES: usize = 500;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct VisitEntry {
    pub id: String,
    pub url: String,
    pub title: String,
    pub domain: String,
    pub visited_at: u64,
}

pub fn file_path<R: Runtime>(app: &AppHandle<R>) -> Result<PathBuf, String> {
    storage::data_file(app, "visit-history.json")
}

pub fn load(path: &Path) -> Vec<VisitEntry> {
    storage::read_json_or_default(path)
}

pub fn store(path: &Path, entries: &[VisitEntry]) -> Result<(), String> {
    storage::write_json(path, entries)
}

pub fn should_record(url: &str) -> bool {
    let Ok(parsed) = Url::parse(url) else {
        return false;
    };
    if !security::is_allowed_navigation(&parsed) {
        return false;
    }
    if parsed.scheme() == "about" {
        return false;
    }
    if parsed.host_str() == Some("picosurf-research.localhost") {
        return false;
    }
    true
}

pub fn record<R: Runtime>(app: &AppHandle<R>, url: &str, title: &str) -> Result<(), String> {
    if !should_record(url) {
        return Ok(());
    }
    let path = file_path(app)?;
    let mut entries = load(&path);
    let domain = Url::parse(url)
        .ok()
        .and_then(|item| item.host_str().map(str::to_string))
        .unwrap_or_default();
    let clean_title = sanitize(title, 200);
    let now = now_unix();
    if let Some(existing) = entries.first_mut() {
        if existing.url == url {
            existing.title = clean_title;
            existing.visited_at = now;
            existing.domain = domain;
            return store(&path, &entries);
        }
    }
    entries.insert(
        0,
        VisitEntry {
            id: format!("visit-{now}"),
            url: url.to_string(),
            title: clean_title,
            domain,
            visited_at: now,
        },
    );
    entries.truncate(MAX_ENTRIES);
    store(&path, &entries)
}

pub fn list(app: &AppHandle, query: &str, limit: usize) -> Result<Vec<VisitEntry>, String> {
    let path = file_path(app)?;
    let entries = load(&path);
    Ok(search_entries(&entries, query, limit))
}

pub fn clear(app: &AppHandle) -> Result<(), String> {
    let path = file_path(app)?;
    store(&path, &[])
}

fn search_entries(entries: &[VisitEntry], query: &str, limit: usize) -> Vec<VisitEntry> {
    let q = query.trim();
    let take = limit.clamp(1, 100);
    if q.is_empty() {
        return entries.iter().take(take).cloned().collect();
    }
    let words: Vec<String> = q
        .split_whitespace()
        .map(|word| word.trim_matches(|ch: char| ".,;:?!".contains(ch)).to_ascii_lowercase())
        .filter(|word| word.len() > 1)
        .collect();
    if words.is_empty() {
        return entries.iter().take(take).cloned().collect();
    }
    let mut scored: Vec<(u32, VisitEntry)> = entries
        .iter()
        .filter_map(|entry| {
            let blob = format!("{} {} {}", entry.title, entry.url, entry.domain).to_ascii_lowercase();
            let score = words
                .iter()
                .filter(|word| blob.contains(word.as_str()))
                .count() as u32;
            (score > 0).then(|| (score, entry.clone()))
        })
        .collect();
    scored.sort_by(|a, b| b.0.cmp(&a.0));
    scored.into_iter().map(|(_, entry)| entry).take(take).collect()
}

fn sanitize(raw: &str, max: usize) -> String {
    raw.chars()
        .filter(|ch| *ch != '\0' && (*ch == '\n' || *ch == '\t' || !ch.is_control()))
        .take(max)
        .collect()
}

fn now_unix() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|item| item.as_secs())
        .unwrap_or(0)
}
