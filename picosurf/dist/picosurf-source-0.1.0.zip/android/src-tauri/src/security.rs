use url::Url;

pub fn is_allowed_navigation(url: &Url) -> bool {
    matches!(url.scheme(), "https" | "http" | "about")
        && (url.scheme() != "about" || url.as_str() == "about:blank")
}

pub fn parse_url_or_host(input: &str) -> Result<Option<Url>, String> {
    let trimmed = input.trim();
    if trimmed.is_empty() {
        return Err("Enter an address or search".into());
    }

    if let Ok(url) = Url::parse(trimmed) {
        if is_allowed_navigation(&url) {
            return Ok(Some(url));
        }
        return Err(format!("Blocked URL scheme: {}", url.scheme()));
    }

    if looks_like_host(trimmed) {
        let url = Url::parse(&format!("https://{trimmed}"))
            .map_err(|err| format!("Invalid address: {err}"))?;
        if is_allowed_navigation(&url) {
            return Ok(Some(url));
        }
        return Err("That address is not allowed".into());
    }

    Ok(None)
}

pub fn looks_like_host(value: &str) -> bool {
    if value.contains(' ') || value.contains('\\') {
        return false;
    }
    if let Some(host) = value.split('/').next() {
        host.contains('.') && !host.starts_with('.') && !host.ends_with('.')
    } else {
        false
    }
}

pub fn force_search_prefix(input: &str) -> Option<&str> {
    let trimmed = input.trim();
    if trimmed.starts_with('?') {
        return Some(trimmed.trim_start_matches('?').trim_start());
    }
    let lower = trimmed.to_ascii_lowercase();
    if lower.starts_with("search:") {
        return Some(trimmed[7..].trim_start());
    }
    None
}
