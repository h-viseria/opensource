use std::sync::atomic::{AtomicI32, Ordering};
use std::sync::Arc;



use tauri::{AppHandle, Emitter, Manager, State};



use crate::ai::{ChatTurn, GenerateResult};

use crate::models::{

    self, ModelProgress, ModelsListResponse, ModelSelectResponse,

};

use crate::state::AppState;



fn emit_main(app: &AppHandle, event: &str, payload: impl serde::Serialize + Clone) {

    if let Some(main) = app.get_webview("main") {

        let _ = main.emit(event, payload);

    }

}



fn emit_model_progress(app: &AppHandle, progress: ModelProgress) {

    emit_main(app, "model-progress", progress);

}



#[tauri::command]

pub async fn models_list(

    app: AppHandle,

    state: State<'_, AppState>,

) -> Result<ModelsListResponse, String> {

    let dir = models::models_dir(&app)?;

    let selected = state.settings().selected_model_id;

    let loaded = state.loaded_model();

    models::list_models(&app, &dir, selected, loaded)

}



#[tauri::command]

pub async fn models_select(

    app: AppHandle,

    state: State<'_, AppState>,

    model_id: String,

) -> Result<ModelSelectResponse, String> {

    let spec = models::find(&app, &model_id)?;

    state.set_selected_model(&app, Some(spec.id.clone()))?;

    let dir = models::models_dir(&app)?;

    let needs_download = !spec.is_downloaded(&dir);

    Ok(ModelSelectResponse {

        selected_id: spec.id,

        needs_download,

        download_enabled: models::download_enabled(),

        message: if needs_download {

            "Download this model before loading.".into()

        } else {

            "Model file is on disk. Load it when ready.".into()

        },

    })

}



#[tauri::command]

pub async fn models_download(

    app: AppHandle,

    state: State<'_, AppState>,

    model_id: String,

) -> Result<ModelsListResponse, String> {

    state.try_begin_model_op()?;

    let result = models_download_inner(app, state.clone(), model_id).await;

    state.end_model_op();

    result

}



async fn models_download_inner(

    app: AppHandle,

    state: State<'_, AppState>,

    model_id: String,

) -> Result<ModelsListResponse, String> {

    let spec = models::find(&app, &model_id)?;

    let dir = models::models_dir(&app)?;

    state.begin_download();

    let cancel = state.download_cancel();

    let app_handle = app.clone();

    let id = spec.id.clone();

    let spec_dl = spec.clone();

    let dir_dl = dir.clone();

    tauri::async_runtime::spawn_blocking(move || {

        spec_dl.download(&dir_dl, &cancel, |received, total| {

            emit_model_progress(

                &app_handle,

                ModelProgress {

                    model_id: id.clone(),

                    phase: "download".into(),

                    received,

                    total,

                    message: "Downloading model…".into(),

                },

            );

        })

    })

    .await

    .map_err(|err| err.to_string())??;

    emit_model_progress(

        &app,

        ModelProgress {

            model_id: spec.id.clone(),

            phase: "verify".into(),

            received: spec.size_bytes(),

            total: spec.size_bytes(),

            message: "Verifying SHA-256…".into(),

        },

    );

    spec.verify_all(&dir)?;

    emit_model_progress(

        &app,

        ModelProgress {

            model_id: spec.id.clone(),

            phase: "done".into(),

            received: spec.size_bytes(),

            total: spec.size_bytes(),

            message: "Download complete.".into(),

        },

    );

    models_list(app, state).await

}



#[tauri::command]

pub async fn models_cancel(state: State<'_, AppState>) -> Result<(), String> {

    state.cancel_download();

    state.with_engine(|engine| engine.request_stop())?;

    Ok(())

}



#[tauri::command]

pub async fn models_load(

    app: AppHandle,

    state: State<'_, AppState>,

    model_id: String,

) -> Result<ModelsListResponse, String> {

    if !crate::ai::inference_available() {

        return Err(

            "This build cannot load models into memory. Rebuild the APK with the llama feature (see README)."

                .into(),

        );

    }

    state.try_begin_model_op()?;

    let result = models_load_inner(app, state.clone(), model_id).await;

    state.end_model_op();

    result

}



async fn models_load_inner(

    app: AppHandle,

    state: State<'_, AppState>,

    model_id: String,

) -> Result<ModelsListResponse, String> {

    let spec = models::find(&app, &model_id)?;

    let dir = models::models_dir(&app)?;

    let path = spec.verify_all(&dir)?;

    let total = spec.size_bytes();

    emit_model_progress(

        &app,

        ModelProgress {

            model_id: spec.id.clone(),

            phase: "load".into(),

            received: 0,

            total,

            message: format!("Loading {} into memory…", spec.display_name),

        },

    );

    state.begin_download();

    let cancel = state.download_cancel();

    let id = spec.id.clone();

    let app_handle = app.clone();

    let load_result = tauri::async_runtime::spawn_blocking(move || {

        let managed = app_handle.state::<AppState>();

        let last_pct = Arc::new(AtomicI32::new(-1));

        managed.with_engine(|engine| {

            engine.load_model(&id, &path, {

                let app_handle = app_handle.clone();

                let id = id.clone();

                let last_pct = Arc::clone(&last_pct);

                move |progress| {

                    if cancel.load(Ordering::Relaxed) {

                        return false;

                    }

                    let pct = (progress * 100.0).floor() as i32;

                    let prev = last_pct.swap(pct, Ordering::Relaxed);

                    if prev != pct {

                        let received = (progress as f64 * total as f64).round() as u64;

                        emit_model_progress(

                            &app_handle,

                            ModelProgress {

                                model_id: id.clone(),

                                phase: "load".into(),

                                received: received.min(total),

                                total,

                                message: format!("Loading into memory… {pct}%"),

                            },

                        );

                    }

                    true

                }

            })

        })?

    })

    .await

    .map_err(|err| err.to_string())?;



    match load_result {

        Ok(()) => {

            state.set_selected_model(&app, Some(spec.id.clone()))?;

            emit_model_progress(

                &app,

                ModelProgress {

                    model_id: spec.id.clone(),

                    phase: "done".into(),

                    received: total,

                    total,

                    message: "Model loaded into memory.".into(),

                },

            );

            models_list(app, state).await

        }

        Err(err) => {

            emit_model_progress(

                &app,

                ModelProgress {

                    model_id: spec.id.clone(),

                    phase: "error".into(),

                    received: 0,

                    total,

                    message: err.clone(),

                },

            );

            Err(err)

        }

    }

}



#[tauri::command]

pub async fn models_unload(

    app: AppHandle,

    state: State<'_, AppState>,

) -> Result<ModelsListResponse, String> {

    state.try_begin_model_op()?;

    let result: Result<(), String> = (|| {
        state.with_engine(|engine| engine.unload())?;
        emit_model_progress(
            &app,
            ModelProgress {
                model_id: String::new(),
                phase: "done".into(),
                received: 0,
                total: 0,
                message: "Model unloaded from memory.".into(),
            },
        );
        Ok(())
    })();

    state.end_model_op();

    result?;

    state.default_to_browse_when_research_not_ready(&app)?;

    models_list(app, state).await

}



#[tauri::command]

pub async fn ai_generate(

    state: State<'_, AppState>,

    messages: Vec<ChatTurn>,

) -> Result<GenerateResult, String> {

    if state.loaded_model().is_none() {

        return Err("Load a local model first.".into());

    }

    state.with_engine(|engine| engine.generate(&messages, None, |_token| ()))?

}


