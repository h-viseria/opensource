use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use serde::{Deserialize, Serialize};

use crate::browser::UntrustedPage;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatTurn {
    pub role: String,
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GenerateResult {
    pub text: String,
    pub stopped: bool,
    pub message: String,
    pub used_page: bool,
    pub page_origin: String,
}

pub struct InferenceEngine {
    model_id: Option<String>,
    stop: Arc<AtomicBool>,
}

impl Default for InferenceEngine {
    fn default() -> Self {
        Self::new(Arc::new(AtomicBool::new(false)))
    }
}

impl InferenceEngine {
    pub fn new(stop: Arc<AtomicBool>) -> Self {
        Self {
            model_id: None,
            stop,
        }
    }

    pub fn is_loaded(&self) -> bool {
        false
    }

    pub fn loaded_id(&self) -> Option<String> {
        self.model_id.clone()
    }

    pub fn request_stop(&self) {
        self.stop.store(true, Ordering::Relaxed);
    }

    pub fn stop_requested(&self) -> bool {
        self.stop.load(Ordering::Relaxed)
    }

    pub fn unload(&mut self) {
        self.model_id = None;
        self.stop.store(false, Ordering::Relaxed);
    }

    pub fn load_model(
        &mut self,
        _id: &str,
        _path: &Path,
        _on_progress: impl FnMut(f32) -> bool,
    ) -> Result<(), String> {
        Err(stub_err())
    }

    pub fn generate(
        &mut self,
        _turns: &[ChatTurn],
        _page: Option<&UntrustedPage>,
        _on_token: impl FnMut(&str),
    ) -> Result<GenerateResult, String> {
        Err(stub_err())
    }

    pub fn generate_cfg(
        &mut self,
        _turns: &[ChatTurn],
        _page: Option<&UntrustedPage>,
        _system: &str,
        _max_new_tokens: i32,
        _temperature: f32,
        _on_token: impl FnMut(&str),
    ) -> Result<GenerateResult, String> {
        Err(stub_err())
    }
}

fn stub_err() -> String {
    "Build PicoSurf Android with --features llama to enable on-device inference.".into()
}
