pub mod prompt;

#[cfg(feature = "llama")]
mod llama;
#[cfg(not(feature = "llama"))]
mod llama_stub;

#[cfg(feature = "llama")]
pub use llama::{ChatTurn, GenerateResult, InferenceEngine};
#[cfg(not(feature = "llama"))]
pub use llama_stub::{ChatTurn, GenerateResult, InferenceEngine};
