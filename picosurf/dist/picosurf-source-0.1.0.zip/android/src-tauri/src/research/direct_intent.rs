use url::Url;

/// User asked to read a specific site (e.g. "summarize news from ndtv.com") rather than multi-search.
#[derive(Debug, Clone)]
pub struct DirectSiteIntent {
    pub seed_url: Url,
    pub site_label: String,
}

/// Detect a single-site intent from the user goal. Returns None for open-ended research questions.
pub fn detect(goal: &str) -> Option<DirectSiteIntent> {
    let trimmed = goal.trim();
    if trimmed.is_empty() {
        return None;
    }

    if let Some(url) = extract_explicit_url(trimmed) {
        return Some(intent_from_url(url));
    }

    let lower = trimmed.to_ascii_lowercase();
    let domain = domain_after_preposition(&lower)
        .or_else(|| first_likely_site_domain(&lower))?;

    let host = normalize_host(&domain);
    if is_search_or_generic_host(&host) {
        return None;
    }

    Url::parse(&format!("https://{host}/"))
        .ok()
        .map(|url| DirectSiteIntent {
            site_label: host.clone(),
            seed_url: url,
        })
}

fn intent_from_url(url: Url) -> DirectSiteIntent {
    let host = url
        .host_str()
        .unwrap_or("site")
        .trim_start_matches("www.")
        .to_string();
    DirectSiteIntent {
        site_label: host,
        seed_url: url,
    }
}

fn extract_explicit_url(text: &str) -> Option<Url> {
    for token in text.split_whitespace() {
        let cleaned = token.trim_matches(|c: char| ".,;:!?()[]\"'".contains(c));
        let with_scheme = if cleaned.starts_with("http://") || cleaned.starts_with("https://") {
            cleaned.to_string()
        } else if cleaned.contains('.') && !cleaned.contains(' ') {
            format!("https://{cleaned}")
        } else {
            continue;
        };
        if let Ok(url) = Url::parse(&with_scheme) {
            if url.host_str().is_some() {
                return Some(url);
            }
        }
    }
    None
}

fn domain_after_preposition(lower: &str) -> Option<String> {
    for prep in [" from ", " on ", " at ", " at site ", " from site "] {
        let Some(idx) = lower.rfind(prep) else {
            continue;
        };
        let tail = &lower[idx + prep.len()..];
        if let Some(domain) = first_domain_in_text(tail) {
            return Some(domain);
        }
    }
    None
}

fn first_likely_site_domain(lower: &str) -> Option<String> {
    let hints = [
        "summarize",
        "summary",
        "latest news",
        "headlines",
        "read ",
        "open ",
        "visit ",
    ];
    if !hints.iter().any(|h| lower.contains(h)) {
        return None;
    }
    first_domain_in_text(lower)
}

fn first_domain_in_text(text: &str) -> Option<String> {
    let bytes = text.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        while i < bytes.len() && !is_domain_char(bytes[i]) {
            i += 1;
        }
        let start = i;
        while i < bytes.len() && is_domain_char(bytes[i]) {
            i += 1;
        }
        if i > start {
            let slice = &text[start..i];
            if looks_like_domain(slice) {
                let host = normalize_host(slice);
                if !is_search_or_generic_host(&host) {
                    return Some(host);
                }
            }
        }
    }
    None
}

fn is_domain_char(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'.' || b == b'-'
}

fn looks_like_domain(token: &str) -> bool {
    let token = token.trim_matches('.');
    if token.len() < 4 || token.len() > 253 {
        return false;
    }
    if !token.contains('.') {
        return false;
    }
    let parts: Vec<&str> = token.split('.').collect();
    if parts.len() < 2 {
        return false;
    }
    parts.iter().all(|part| {
        !part.is_empty()
            && part.len() <= 63
            && part.starts_with(|c: char| c.is_ascii_alphanumeric())
            && part
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || c == '-')
    })
}

fn normalize_host(domain: &str) -> String {
    domain
        .trim()
        .trim_start_matches("www.")
        .trim_end_matches('.')
        .to_ascii_lowercase()
}

fn is_search_or_generic_host(host: &str) -> bool {
    matches!(
        host,
        "google.com"
            | "google.co.in"
            | "bing.com"
            | "duckduckgo.com"
            | "yahoo.com"
            | "wikipedia.org"
            | "reddit.com"
            | "twitter.com"
            | "x.com"
            | "facebook.com"
            | "instagram.com"
            | "youtube.com"
    ) || host.ends_with(".search")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_domain_after_from() {
        let intent = detect("summarize latest news from ndtv.com").expect("intent");
        assert_eq!(intent.site_label, "ndtv.com");
        assert_eq!(intent.seed_url.host_str(), Some("ndtv.com"));
    }

    #[test]
    fn detects_explicit_url() {
        let intent = detect("Please read https://www.ndtv.com/").expect("intent");
        assert!(intent.seed_url.as_str().contains("ndtv.com"));
    }

    #[test]
    fn skips_open_ended() {
        assert!(detect("Compare privacy browsers for Android").is_none());
    }
}
