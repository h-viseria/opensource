# THIS FILE IS AUTO-GENERATED. DO NOT MODIFY!!

# Copyright 2020-2023 Tauri Programme within The Commons Conservancy
# SPDX-License-Identifier: Apache-2.0
# SPDX-License-Identifier: MIT

-keep class com.picosurf.android.* {
  native <methods>;
}

-keep class com.picosurf.android.WryActivity {
  public <init>(...);

  void setWebView(com.picosurf.android.RustWebView);
  java.lang.Class getAppClass(...);
  int getId();
  java.lang.String getVersion();
  int startActivity(...);
}

-keep class com.picosurf.android.Ipc {
  public <init>(...);

  @android.webkit.JavascriptInterface public <methods>;
}

-keep class com.picosurf.android.RustWebView {
  public <init>(...);

  void loadUrlMainThread(...);
  void loadHTMLMainThread(...);
  void evalScript(...);
}

-keep class com.picosurf.android.RustWebChromeClient,com.picosurf.android.RustWebViewClient {
  public <init>(...);
}
