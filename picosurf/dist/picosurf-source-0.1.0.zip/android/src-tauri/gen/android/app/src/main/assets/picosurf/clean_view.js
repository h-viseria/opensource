(function picosurfCleanViewBootstrap() {
  if (window.__picosurfCleanView && window.__picosurfCleanView.tapAtNative) {
    return;
  }

  const MARKER = "data-picosurf-clean-view-ui";
  let active = window.__picosurfCleanView?.status?.()?.active ?? false;
  let hovered = null;
  let overlay = null;
  let bound = false;

  function ensureOverlay() {
    if (overlay && overlay.isConnected) {
      return overlay;
    }
    overlay = document.createElement("div");
    overlay.setAttribute(MARKER, "overlay");
    Object.assign(overlay.style, {
      position: "fixed",
      pointerEvents: "none",
      zIndex: "2147483646",
      border: "2px solid #3b82f6",
      background: "rgba(59, 130, 246, 0.14)",
      boxSizing: "border-box",
      display: "none",
      borderRadius: "2px",
      transition: "left 80ms linear, top 80ms linear, width 80ms linear, height 80ms linear",
    });
    (document.documentElement || document.body).appendChild(overlay);
    return overlay;
  }

  function isUiNode(el) {
    return !!(el && el.closest && el.closest("[" + MARKER + "]"));
  }

  function isProtected(el) {
    return !el || el === document.documentElement || el === document.body;
  }

  function isSkippable(el) {
    if (!(el instanceof Element)) return true;
    const tag = el.tagName;
    if (tag === "HTML" || tag === "SVG" || tag === "PATH" || tag === "G") return true;
    const style = getComputedStyle(el);
    if (style.pointerEvents === "none") return true;
    if (style.visibility === "hidden" || style.display === "none") return true;
    const rect = el.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return true;
    return false;
  }

  /** Map Android view touch coords → document viewport coords for elementsFromPoint. */
  function nativeToClient(vx, vy, viewW, viewH, padTop, padBottom) {
    const vw = Math.max(1, Number(viewW) || 1);
    const vh = Math.max(1, Number(viewH) || 1);
    const top = Number(padTop) || 0;
    const bottom = Number(padBottom) || 0;
    const contentH = Math.max(1, vh - top - bottom);
    const yInContent = vy - top;
    let x = (vx / vw) * window.innerWidth;
    let y = (yInContent / contentH) * window.innerHeight;
    const vv = window.visualViewport;
    if (vv) {
      x = x - vv.offsetLeft;
      y = y - vv.offsetTop;
    }
    return { x, y };
  }

  function promoteTarget(el) {
    const promoteTags = ["ARTICLE", "SECTION", "LI", "FIGURE", "ASIDE", "DIV", "A", "H1", "H2", "H3"];
    let node = el;
    for (let depth = 0; depth < 8 && node && node.parentElement; depth++) {
      const parent = node.parentElement;
      if (isProtected(parent)) break;
      if (!promoteTags.includes(parent.tagName)) break;
      const prect = parent.getBoundingClientRect();
      const crect = node.getBoundingClientRect();
      if (prect.width >= crect.width * 0.9 && prect.height >= crect.height * 0.9) {
        node = parent;
      } else {
        break;
      }
    }
    return node;
  }

  function pickTarget(x, y) {
    const stack = document.elementsFromPoint(x, y) || [];
    for (const el of stack) {
      if (!(el instanceof Element)) continue;
      if (isUiNode(el)) continue;
      if (isProtected(el)) continue;
      if (isSkippable(el)) continue;
      return promoteTarget(el);
    }
    const single = document.elementFromPoint(x, y);
    if (single instanceof Element && !isUiNode(single) && !isProtected(single) && !isSkippable(single)) {
      return promoteTarget(single);
    }
    return null;
  }

  function positionOverlay(el) {
    const box = ensureOverlay();
    const rect = el.getBoundingClientRect();
    box.style.display = "block";
    box.style.left = rect.left + "px";
    box.style.top = rect.top + "px";
    box.style.width = Math.max(rect.width, 1) + "px";
    box.style.height = Math.max(rect.height, 1) + "px";
    hovered = el;
  }

  function clearOverlay() {
    if (overlay) {
      overlay.style.display = "none";
    }
    hovered = null;
  }

  function hideElement(el) {
    const target = promoteTarget(el);
    target.style.setProperty("display", "none", "important");
    target.setAttribute("data-picosurf-clean-view-hidden", "1");
  }

  function pointerXY(event) {
    if (event.touches && event.touches.length) {
      return { x: event.touches[0].clientX, y: event.touches[0].clientY };
    }
    if (event.changedTouches && event.changedTouches.length) {
      return { x: event.changedTouches[0].clientX, y: event.changedTouches[0].clientY };
    }
    return { x: event.clientX, y: event.clientY };
  }

  function onPointerMove(event) {
    if (!active) return;
    const { x, y } = pointerXY(event);
    const el = pickTarget(x, y);
    if (!el) {
      clearOverlay();
      return;
    }
    if (el !== hovered) {
      positionOverlay(el);
    }
  }

  function onPointerActivate(event) {
    if (!active) return;
    const { x, y } = pointerXY(event);
    const el = pickTarget(x, y);
    if (!el) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    hideElement(el);
    clearOverlay();
  }

  function onKeyDown(event) {
    if (!active) return;
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      stop();
    }
  }

  function onViewportChange() {
    if (active && hovered) {
      positionOverlay(hovered);
    }
  }

  function bind() {
    if (bound) return;
    document.addEventListener("mousemove", onPointerMove, true);
    document.addEventListener("click", onPointerActivate, true);
    document.addEventListener("touchstart", onPointerMove, { capture: true, passive: false });
    document.addEventListener("touchmove", onPointerMove, { capture: true, passive: false });
    document.addEventListener("touchend", onPointerActivate, { capture: true, passive: false });
    document.addEventListener("keydown", onKeyDown, true);
    window.addEventListener("scroll", onViewportChange, true);
    window.addEventListener("resize", onViewportChange, true);
    if (window.visualViewport) {
      window.visualViewport.addEventListener("scroll", onViewportChange);
      window.visualViewport.addEventListener("resize", onViewportChange);
    }
    bound = true;
  }

  function unbind() {
    if (!bound) return;
    document.removeEventListener("mousemove", onPointerMove, true);
    document.removeEventListener("click", onPointerActivate, true);
    document.removeEventListener("touchstart", onPointerMove, true);
    document.removeEventListener("touchmove", onPointerMove, true);
    document.removeEventListener("touchend", onPointerActivate, true);
    document.removeEventListener("keydown", onKeyDown, true);
    window.removeEventListener("scroll", onViewportChange, true);
    window.removeEventListener("resize", onViewportChange, true);
    if (window.visualViewport) {
      window.visualViewport.removeEventListener("scroll", onViewportChange);
      window.visualViewport.removeEventListener("resize", onViewportChange);
    }
    bound = false;
  }

  function start() {
    if (active) {
      return { ok: true, active: true };
    }
    active = true;
    bind();
    ensureOverlay();
    if (document.documentElement) {
      document.documentElement.style.cursor = "crosshair";
      document.documentElement.setAttribute("data-picosurf-clean-view", "active");
    }
    return { ok: true, active: true };
  }

  function stop() {
    if (!active) {
      return { ok: true, active: false };
    }
    active = false;
    unbind();
    clearOverlay();
    if (document.documentElement) {
      document.documentElement.style.cursor = "";
      document.documentElement.removeAttribute("data-picosurf-clean-view");
    }
    return { ok: true, active: false };
  }

  function status() {
    return { ok: true, active: active };
  }

  function hoverAt(x, y) {
    if (!active) {
      return { ok: true, active: false };
    }
    const el = pickTarget(x, y);
    if (!el) {
      clearOverlay();
      return { ok: true, active: true };
    }
    if (el !== hovered) {
      positionOverlay(el);
    }
    return { ok: true, active: true };
  }

  function tapAt(x, y) {
    if (!active) {
      return { ok: true, active: false };
    }
    const el = pickTarget(x, y);
    if (!el) {
      clearOverlay();
      return { ok: true, active: true };
    }
    hideElement(el);
    clearOverlay();
    return { ok: true, active: true };
  }

  function hoverAtNative(vx, vy, viewW, viewH, padTop, padBottom) {
    const { x, y } = nativeToClient(vx, vy, viewW, viewH, padTop, padBottom);
    return hoverAt(x, y);
  }

  function tapAtNative(vx, vy, viewW, viewH, padTop, padBottom) {
    const { x, y } = nativeToClient(vx, vy, viewW, viewH, padTop, padBottom);
    return tapAt(x, y);
  }

  window.__picosurfCleanView = {
    start,
    stop,
    status,
    hoverAt,
    tapAt,
    hoverAtNative,
    tapAtNative,
  };

  if (active) {
    bind();
    ensureOverlay();
  }
})();
