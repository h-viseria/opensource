package com.picosurf.android

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

/** Hidden WebView for research fetch only — never shown or shared with Browse. */
object ResearchShell {
    private var webView: WebView? = null
    @Volatile
    private var pageReady = false
    private var settledUrl = ""
    private var settledTitle = ""

    fun ensure(activity: Activity) {
        if (webView != null) return
        activity.runOnUiThread {
            if (webView != null) return@runOnUiThread
            val wv = WebView(activity)
            wv.visibility = View.GONE
            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            wv.webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    pageReady = false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    val w = view ?: return
                    w.evaluateJavascript(
                        "(function(){ try { return JSON.stringify({ url: location.href, title: document.title || '' }); } catch(e) { return JSON.stringify({ url: location.href, title: '' }); } })()",
                    ) { result ->
                        applySettledFromEval(result)
                    }
                }
            }
            val decor = activity.window.decorView as ViewGroup
            decor.addView(wv, ViewGroup.LayoutParams(0, 0))
            webView = wv
        }
    }

    private fun normalizeEvalResult(result: String?): String {
        if (result.isNullOrBlank() || result == "null" || result == "undefined") {
            return "null"
        }
        var raw = result.trim()
        if (raw.startsWith("\"") && raw.endsWith("\"")) {
            raw = raw.substring(1, raw.length - 1)
                .replace("\\\\", "\\")
                .replace("\\\"", "\"")
        }
        return raw
    }

    private fun applySettledFromEval(result: String?) {
        val raw = normalizeEvalResult(result)
        if (raw == "null" || raw.isEmpty()) return
        try {
            val json = JSONObject(raw)
            val url = json.optString("url", "").trim()
            val title = json.optString("title", "").trim()
            if (url.isEmpty()) return
            settledUrl = url
            settledTitle = title
            pageReady = true
        } catch (_: Exception) {
        }
    }

    fun loadUrl(url: String) {
        pageReady = false
        val w = webView ?: return
        w.post { w.loadUrl(url) }
    }

    fun currentUrl(): String? = webView?.url

    fun settledPageMeta(): JSONObject {
        return JSONObject().apply {
            put("url", settledUrl.ifEmpty { currentUrl().orEmpty() })
            put("title", settledTitle)
            put("ready", pageReady)
        }
    }

    fun evalJson(script: String, callback: (String?) -> Unit) {
        val w = webView
        if (w == null) {
            callback(null)
            return
        }
        w.post {
            val handler = Handler(Looper.getMainLooper())
            var finished = false
            lateinit var timeout: Runnable
            fun finish(result: String?) {
                if (finished) return
                finished = true
                handler.removeCallbacks(timeout)
                callback(result)
            }
            timeout = Runnable { finish("{\"ok\":false,\"error\":\"eval timeout\"}") }
            handler.postDelayed(timeout, 12000L)
            w.evaluateJavascript(script) { result -> finish(result) }
        }
    }
}
