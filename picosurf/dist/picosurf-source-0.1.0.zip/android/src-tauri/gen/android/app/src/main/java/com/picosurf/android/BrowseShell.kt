package com.picosurf.android



import android.app.Activity

import android.graphics.Color

import android.util.Log

import android.view.MotionEvent

import android.view.ViewGroup

import android.webkit.WebView

import android.webkit.WebViewClient

import org.json.JSONObject



/** Full-page browse content behind the transparent Tauri UI webview. */

object BrowseShell {

    private const val TAG = "BrowseShell"

    private var content: WebView? = null

    private var hostActivity: Activity? = null

    private var uiChrome: WebView? = null

    private var attached = false

    private var pendingUrl: String? = null

    private var chromeTopPx = 0

    private var chromeBottomPx = 0

    private var touchPassthrough = false



    private var settledUrl: String = ""

    private var settledTitle: String = ""

    @Volatile

    private var pageReady = false



    fun prepare(activity: Activity, uiWebView: WebView) {

        if (attached) return

        hostActivity = activity

        uiChrome = uiWebView

        uiWebView.post {

            if (attached) return@post

            try {

                val root = uiWebView.parent as? ViewGroup

                if (root == null) {

                    uiWebView.post { prepare(activity, uiWebView) }

                    return@post

                }

                val browse = WebView(activity)

                browse.settings.javaScriptEnabled = true

                browse.settings.domStorageEnabled = true

                browse.settings.mediaPlaybackRequiresUserGesture = false

                browse.webViewClient = object : WebViewClient() {

                    override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {

                        pageReady = false

                    }



                    override fun onPageFinished(view: WebView?, url: String?) {

                        val w = view ?: return

                        injectCleanViewBootstrap(w)

                        w.evaluateJavascript(

                            "(function(){ try { return JSON.stringify({ url: location.href, title: document.title || '' }); } catch(e) { return JSON.stringify({ url: location.href, title: '' }); } })()",

                        ) { result ->

                            applySettledFromEval(result)

                        }

                    }

                }

                content = browse



                root.addView(

                    browse,

                    0,

                    ViewGroup.LayoutParams(

                        ViewGroup.LayoutParams.MATCH_PARENT,

                        ViewGroup.LayoutParams.MATCH_PARENT,

                    ),

                )

                uiWebView.setBackgroundColor(Color.TRANSPARENT)

                browse.setBackgroundColor(Color.WHITE)

                uiWebView.bringToFront()

                attached = true

                applyUiTouchRouting()

                pendingUrl?.let { browse.loadUrl(it) }

                pendingUrl = null

            } catch (ex: Exception) {

                Log.e(TAG, "prepare failed", ex)

            }

        }

    }



    private fun normalizeEvalResult(result: String?): String {
        if (result.isNullOrBlank() || result == "null" || result == "undefined") {
            return "null"
        }
        var raw = result.trim()
        if (raw.startsWith("\"") && raw.endsWith("\"")) {
            raw = raw.substring(1, raw.length - 1)
                .replace("\\\\", "\\")
                .replace("\\\"", "\"")
        }
        return raw
    }

    private fun applySettledFromEval(result: String?) {

        val raw = normalizeEvalResult(result)

        if (raw == "null" || raw.isEmpty()) return

        try {

            val json = JSONObject(raw)

            val url = json.optString("url", "").trim()

            val title = json.optString("title", "").trim()

            if (url.isEmpty()) return

            settledUrl = url

            settledTitle = title

            pageReady = true

        } catch (ex: Exception) {

            Log.w(TAG, "page settled parse failed", ex)

        }

    }



    fun loadUrl(url: String) {

        pendingUrl = url

        pageReady = false

        val w = content ?: return

        w.post { w.loadUrl(url) }

    }



    fun reload() {

        pageReady = false

        content?.post { content?.reload() }

    }



    fun goBack(): Boolean {

        val w = content ?: return false

        if (w.canGoBack()) {

            pageReady = false

            w.post { w.goBack() }

            return true

        }

        return false

    }



    fun goForward(): Boolean {

        val w = content ?: return false

        if (w.canGoForward()) {

            pageReady = false

            w.post { w.goForward() }

            return true

        }

        return false

    }



    fun currentUrl(): String? = content?.url



    fun pageTitle(): String = settledTitle.ifEmpty { content?.title?.trim().orEmpty() }



    fun pageMetaReady(): Boolean = pageReady



    fun settledPageMeta(): JSONObject {

        return JSONObject().apply {

            put("url", settledUrl.ifEmpty { currentUrl().orEmpty() })

            put("title", settledTitle)

            put("ready", pageReady)

        }

    }



    fun setTouchPassthrough(enabled: Boolean) {

        touchPassthrough = enabled

        applyUiTouchRouting()

        if (enabled) {

            content?.requestFocus()

        }

    }



    fun setChromeInsets(topLogicalPx: Int, bottomLogicalPx: Int) {

        val density = hostActivity?.resources?.displayMetrics?.density ?: 1f

        chromeTopPx = (topLogicalPx * density + 0.5f).toInt()

        chromeBottomPx = (bottomLogicalPx * density + 0.5f).toInt()

        content?.post {

            content?.setPadding(0, chromeTopPx, 0, chromeBottomPx)

            content?.clipToPadding = true

        }

        applyUiTouchRouting()

    }



    private fun applyUiTouchRouting() {

        val ui = uiChrome ?: return

        if (!touchPassthrough) {
            ui.setOnTouchListener(null)
            return
        }

        ui.setOnTouchListener { _, event ->
            val h = ui.height.toFloat()
            if (h <= 0f) return@setOnTouchListener false
            val y = event.y
            if (y < chromeTopPx || y > h - chromeBottomPx) {
                false
            } else {
                val target = content ?: return@setOnTouchListener false
                val copy = MotionEvent.obtain(event)
                try {
                    target.dispatchTouchEvent(copy)
                } finally {
                    copy.recycle()
                }
                true
            }
        }

    }



    private fun injectCleanViewBootstrap(webView: WebView) {

        val activity = hostActivity ?: return

        try {

            activity.assets.open("picosurf/clean_view.js").bufferedReader().use { reader ->

                val js = reader.readText()

                webView.evaluateJavascript(js, null)

            }

        } catch (ex: Exception) {

            Log.w(TAG, "inject clean_view.js failed", ex)

        }

    }



    fun evalJson(script: String, callback: (String?) -> Unit) {

        val w = content

        if (w == null) {

            callback(null)

            return

        }

        w.post {

            val handler = android.os.Handler(android.os.Looper.getMainLooper())

            var finished = false

            lateinit var timeout: Runnable

            fun finish(result: String?) {

                if (finished) return

                finished = true

                handler.removeCallbacks(timeout)

                callback(result)

            }

            timeout = Runnable {

                finish("{\"ok\":false,\"error\":\"eval timeout\"}")

            }

            handler.postDelayed(timeout, 12000L)

            w.evaluateJavascript(script) { result ->

                finish(result)

            }

        }

    }

}


