package com.picosurf.android

import android.app.Activity
import app.tauri.annotation.Command
import app.tauri.annotation.InvokeArg
import app.tauri.annotation.TauriPlugin
import app.tauri.plugin.Invoke
import app.tauri.plugin.JSObject
import app.tauri.plugin.Plugin

@InvokeArg
class ResearchLoadUrlArgs {
    lateinit var url: String
}

@InvokeArg
class ResearchEvalJsonArgs {
    lateinit var script: String
}

private fun normalizeEvalResult(result: String?): String {
    if (result.isNullOrBlank() || result == "null" || result == "undefined") {
        return "null"
    }
    var raw = result.trim()
    if (raw.startsWith("\"") && raw.endsWith("\"")) {
        raw = raw.substring(1, raw.length - 1)
            .replace("\\\\", "\\")
            .replace("\\\"", "\"")
    }
    return raw
}

@TauriPlugin
class ResearchShellPlugin(private val activity: Activity) : Plugin(activity) {
    @Command
    fun loadUrl(invoke: Invoke) {
        try {
            ResearchShell.ensure(activity)
            val args = invoke.parseArgs(ResearchLoadUrlArgs::class.java)
            ResearchShell.loadUrl(args.url)
            invoke.resolve()
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun getUrl(invoke: Invoke) {
        try {
            val ret = JSObject()
            ret.put("url", ResearchShell.currentUrl() ?: "")
            invoke.resolve(ret)
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun getPageMeta(invoke: Invoke) {
        try {
            val meta = ResearchShell.settledPageMeta()
            val ret = JSObject()
            ret.put("url", meta.optString("url", ""))
            ret.put("title", meta.optString("title", ""))
            ret.put("ready", meta.optBoolean("ready", false))
            invoke.resolve(ret)
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun evalJson(invoke: Invoke) {
        try {
            val args = invoke.parseArgs(ResearchEvalJsonArgs::class.java)
            ResearchShell.evalJson(args.script) { result ->
                val ret = JSObject()
                ret.put("raw", normalizeEvalResult(result))
                invoke.resolve(ret)
            }
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }
}
