package com.picosurf.android

import android.os.Bundle
import androidx.activity.enableEdgeToEdge

import android.webkit.WebView

class MainActivity : TauriActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    enableEdgeToEdge()
    super.onCreate(savedInstanceState)
    ResearchShell.ensure(this)
  }

  override fun onWebViewCreate(webView: WebView) {
    super.onWebViewCreate(webView)
    try {
      BrowseShell.prepare(this, webView)
    } catch (ex: Exception) {
      android.util.Log.e("PicoSurf", "BrowseShell.prepare", ex)
    }
  }
}
