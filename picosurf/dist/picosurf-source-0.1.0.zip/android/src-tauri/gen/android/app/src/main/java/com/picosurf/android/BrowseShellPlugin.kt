package com.picosurf.android

import android.app.Activity
import app.tauri.annotation.Command
import app.tauri.annotation.InvokeArg
import app.tauri.annotation.TauriPlugin
import app.tauri.plugin.Invoke
import app.tauri.plugin.JSObject
import app.tauri.plugin.Plugin

@InvokeArg
class LoadUrlArgs {
    lateinit var url: String
}

@InvokeArg
class InsetsArgs {
    var topPx: Int = 0
    var bottomPx: Int = 0
    var browseOverlay: Boolean = false
}

@InvokeArg
class EvalJsonArgs {
    lateinit var script: String
}

@InvokeArg
class TouchPassthroughArgs {
    var enabled: Boolean = false
}

/** Android WebView returns JSON-encoded strings; normalize for Rust parsing. */
private fun normalizeEvalResult(result: String?): String {
    if (result.isNullOrBlank() || result == "null" || result == "undefined") {
        return "null"
    }
    var raw = result.trim()
    if (raw.startsWith("\"") && raw.endsWith("\"")) {
        raw = raw.substring(1, raw.length - 1)
            .replace("\\\\", "\\")
            .replace("\\\"", "\"")
    }
    return raw
}

@TauriPlugin
class BrowseShellPlugin(private val activity: Activity) : Plugin(activity) {
    @Command
    fun loadUrl(invoke: Invoke) {
        try {
            val args = invoke.parseArgs(LoadUrlArgs::class.java)
            BrowseShell.loadUrl(args.url)
            invoke.resolve()
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun reload(invoke: Invoke) {
        try {
            BrowseShell.reload()
            invoke.resolve()
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun goBack(invoke: Invoke) {
        try {
            val ret = JSObject()
            ret.put("handled", BrowseShell.goBack())
            invoke.resolve(ret)
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun goForward(invoke: Invoke) {
        try {
            val ret = JSObject()
            ret.put("handled", BrowseShell.goForward())
            invoke.resolve(ret)
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun getUrl(invoke: Invoke) {
        try {
            val ret = JSObject()
            ret.put("url", BrowseShell.currentUrl() ?: "")
            invoke.resolve(ret)
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun getTitle(invoke: Invoke) {
        try {
            val ret = JSObject()
            ret.put("title", BrowseShell.pageTitle())
            invoke.resolve(ret)
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun evalJson(invoke: Invoke) {
        try {
            val args = invoke.parseArgs(EvalJsonArgs::class.java)
            BrowseShell.evalJson(args.script) { result ->
                val ret = JSObject()
                ret.put("raw", normalizeEvalResult(result))
                invoke.resolve(ret)
            }
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun setInsets(invoke: Invoke) {
        try {
            val args = invoke.parseArgs(InsetsArgs::class.java)
            BrowseShell.setChromeInsets(args.topPx, args.bottomPx, args.browseOverlay)
            invoke.resolve()
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun setTouchPassthrough(invoke: Invoke) {
        try {
            val args = invoke.parseArgs(TouchPassthroughArgs::class.java)
            BrowseShell.setTouchPassthrough(args.enabled)
            invoke.resolve()
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }

    @Command
    fun getPageMeta(invoke: Invoke) {
        try {
            val meta = BrowseShell.settledPageMeta()
            val ret = JSObject()
            ret.put("url", meta.optString("url", ""))
            ret.put("title", meta.optString("title", ""))
            ret.put("ready", meta.optBoolean("ready", false))
            invoke.resolve(ret)
        } catch (ex: Exception) {
            invoke.reject(ex.message)
        }
    }
}
