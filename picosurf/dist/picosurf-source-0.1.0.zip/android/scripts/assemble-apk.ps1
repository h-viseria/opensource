# Package APK after jniLibs are synced (sets Java 17/21 for Gradle).
$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "ensure-java-for-gradle.ps1")
Set-Location (Join-Path $appRoot "src-tauri\gen\android")
& .\gradlew.bat assembleArm64Release `
    -x rustBuildArm64Release `
    -x rustBuildUniversalRelease `
    -x rustBuildArmRelease `
    -x rustBuildX86Release `
    -x rustBuildX86_64Release
if ($LASTEXITCODE -ne 0) { throw "Gradle failed with exit code $LASTEXITCODE" }
