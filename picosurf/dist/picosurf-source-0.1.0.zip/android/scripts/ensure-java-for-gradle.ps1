# Use Java 17 or 21 for Gradle (Java 25+ fails with "Unsupported class file major version 69").

function Get-JavaMajorVersion {
    param([Parameter(Mandatory = $true)][string]$JavaExe)
    if (-not (Test-Path $JavaExe)) { return -1 }
    $text = [string](cmd /c "`"$JavaExe`" -version 2>&1")
    if ($text -match 'version "(\d+)') { return [int]$matches[1] }
    if ($text -match 'version "1\.(\d+)') { return [int]$matches[1] }
    return -1
}

function Get-JavaHomeCandidates {
    $roots = [System.Collections.Generic.List[string]]::new()

    $appRoot = Split-Path -Parent $PSScriptRoot
    $localFile = Join-Path $appRoot "java.home.local"
    if (Test-Path $localFile) {
        $line = (Get-Content $localFile -ErrorAction SilentlyContinue | Where-Object { $_ -and -not $_.StartsWith("#") } | Select-Object -First 1)
        if ($line) { $roots.Add($line.Trim()) }
    }

    foreach ($p in @(
            $env:JAVA_HOME,
            "C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot",
            "C:\projects\android\android-studio\jbr",
            "$env:LOCALAPPDATA\Programs\Android Studio\jbr",
            "$env:ProgramFiles\Android\Android Studio\jbr",
            ${env:ProgramFiles(x86)} + "\Android\Android Studio\jbr"
        )) {
        if ($p -and (Test-Path (Join-Path $p "bin\java.exe"))) {
            $roots.Add($p)
        }
    }

    foreach ($pattern in @(
            "C:\Program Files\Microsoft\jdk-17*",
            "C:\Program Files\Microsoft\jdk-21*",
            "$env:ProgramFiles\Java\jdk-21*",
            "$env:ProgramFiles\Java\jdk-17*",
            "$env:ProgramFiles\Eclipse Adoptium\jdk-21*",
            "$env:ProgramFiles\Eclipse Adoptium\jdk-17*"
        )) {
        Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | ForEach-Object { $roots.Add($_.FullName) }
    }

    return $roots | Select-Object -Unique
}

function Find-GradleJavaHome {
    foreach ($javaHome in (Get-JavaHomeCandidates)) {
        $java = Join-Path $javaHome "bin\java.exe"
        $major = Get-JavaMajorVersion -JavaExe $java
        if ($major -eq 17 -or $major -eq 21) {
            return @{ Home = $javaHome; Major = $major; JavaExe = $java }
        }
    }
    return $null
}

function Ensure-JavaForGradle {
    $javaExe = "java"
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME "bin\java.exe"))) {
        $javaExe = Join-Path $env:JAVA_HOME "bin\java.exe"
    } else {
        $onPath = Get-Command java -ErrorAction SilentlyContinue
        if ($onPath) { $javaExe = $onPath.Source }
    }

    $major = Get-JavaMajorVersion -JavaExe $javaExe
    if ($major -eq 17 -or $major -eq 21) {
        if ($javaExe -ne "java") {
            $bin = Split-Path $javaExe -Parent
            $env:JAVA_HOME = Split-Path $bin -Parent
            $env:PATH = $bin + ";" + $env:PATH
        }
        Write-Host "Using Java $major for Gradle ($javaExe)"
        return
    }

    if ($major -gt 0) {
        Write-Warning "Java $major at $javaExe is too new (Gradle needs 17 or 21). Studio JBR may be Java 25."
    } else {
        Write-Warning "Could not detect Java version at $javaExe; searching for JDK 17 or 21."
    }

    $found = Find-GradleJavaHome
    if (-not $found) {
        throw @"
No JDK 17 or 21 found. Install one or point to it:

  1) Microsoft JDK 17 (recommended): winget install Microsoft.OpenJDK.17
  2) Or create apps/picosurf-android/java.home.local with one line, e.g.:
     C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot

Then rerun: npm run android:assemble-apk
"@
    }

    $env:JAVA_HOME = $found.Home
    $env:PATH = (Join-Path $found.Home "bin") + ";" + $env:PATH
    Write-Host "Using Java $($found.Major) for Gradle ($($found.JavaExe))"
}

Ensure-JavaForGradle
