# Place Rust Android .so artifacts into jniLibs without symlinks (no Developer Mode / admin required).

param(
    [ValidateSet("debug", "release")]
    [string]$Profile = "release",
    [switch]$IncludeCppShared
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
$srcTauri = Join-Path $appRoot "src-tauri"
$jniRoot = Join-Path $srcTauri "gen\android\app\src\main\jniLibs"

$map = @{
    "aarch64-linux-android"   = @{ Abi = "arm64-v8a"; NdkLibDir = "aarch64-linux-android" }
    "armv7-linux-androideabi" = @{ Abi = "armeabi-v7a"; NdkLibDir = "arm-linux-androideabi" }
    "i686-linux-android"      = @{ Abi = "x86"; NdkLibDir = "i686-linux-android" }
    "x86_64-linux-android"    = @{ Abi = "x86_64"; NdkLibDir = "x86_64-linux-android" }
}

function Get-NdkRoot {
    foreach ($name in @("ANDROID_NDK_HOME", "ANDROID_NDK_ROOT", "NDK_ROOT")) {
        $v = [Environment]::GetEnvironmentVariable($name)
        if ($v -and (Test-Path -LiteralPath $v)) { return $v }
    }
    $sdk = $env:ANDROID_HOME
    if (-not $sdk) { $sdk = Join-Path $env:LOCALAPPDATA "Android\Sdk" }
    $ndkRoot = Join-Path $sdk "ndk"
    if (-not (Test-Path $ndkRoot)) { return $null }
    return (Get-ChildItem $ndkRoot -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName
}

function Sync-SoFile {
    param(
        [string]$Src,
        [string]$DestDir,
        [string]$FileName
    )
    New-Item -ItemType Directory -Force -Path $DestDir | Out-Null
    $dest = Join-Path $DestDir $FileName
    if (Test-Path $dest) {
        Remove-Item -Path $dest -Force
    }
    try {
        New-Item -ItemType HardLink -Path $dest -Target $Src -Force | Out-Null
        Write-Host "Hard-linked $dest -> $Src"
    } catch {
        Copy-Item -Path $Src -Destination $dest -Force
        Write-Host "Copied $Src -> $dest"
    }
}

$libName = "libpicosurf_android_lib.so"
$cppSharedName = "libc++_shared.so"
$copied = 0
$ndk = if ($IncludeCppShared) { Get-NdkRoot } else { $null }
if ($IncludeCppShared -and -not $ndk) {
    Write-Warning "Could not find NDK; libc++_shared.so will not be copied (llama builds may crash at launch)."
}

foreach ($target in $map.Keys) {
    $meta = $map[$target]
    $src = Join-Path $srcTauri "target\$target\$Profile\$libName"
    if (-not (Test-Path $src)) {
        continue
    }
    $destDir = Join-Path $jniRoot $meta.Abi
    Sync-SoFile -Src $src -DestDir $destDir -FileName $libName
    if ($ndk) {
        $cppSrc = Join-Path $ndk "toolchains\llvm\prebuilt\windows-x86_64\sysroot\usr\lib\$($meta.NdkLibDir)\$cppSharedName"
        if (Test-Path -LiteralPath $cppSrc) {
            Sync-SoFile -Src $cppSrc -DestDir $destDir -FileName $cppSharedName
        } else {
            Write-Warning "Missing NDK runtime: $cppSrc"
        }
    }
    $copied++
}

if ($copied -eq 0) {
    Write-Error "No $libName found under src-tauri/target/<triple>/$Profile/. Run the Rust/Android build first."
}

Write-Host "Synced $copied ABI(s). You can run: npm run android:assemble-apk"
