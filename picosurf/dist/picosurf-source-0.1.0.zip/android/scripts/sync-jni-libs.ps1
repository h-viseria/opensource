# Place Rust Android .so artifacts into jniLibs without symlinks (no Developer Mode / admin required).

param(
    [ValidateSet("debug", "release")]
    [string]$Profile = "release"
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
$srcTauri = Join-Path $appRoot "src-tauri"
$jniRoot = Join-Path $srcTauri "gen\android\app\src\main\jniLibs"

$map = @{
    "aarch64-linux-android"   = "arm64-v8a"
    "armv7-linux-androideabi" = "armeabi-v7a"
    "i686-linux-android"      = "x86"
    "x86_64-linux-android"    = "x86_64"
}

$libName = "libpicosurf_android_lib.so"
$copied = 0

foreach ($target in $map.Keys) {
    $src = Join-Path $srcTauri "target\$target\$Profile\$libName"
    if (-not (Test-Path $src)) {
        continue
    }
    $destDir = Join-Path $jniRoot $map[$target]
    New-Item -ItemType Directory -Force -Path $destDir | Out-Null
    $dest = Join-Path $destDir $libName
    if (Test-Path $dest) {
        Remove-Item -Path $dest -Force
    }
    try {
        New-Item -ItemType HardLink -Path $dest -Target $src -Force | Out-Null
        Write-Host "Hard-linked $dest -> $src"
    } catch {
        Copy-Item -Path $src -Destination $dest -Force
        Write-Host "Copied $src -> $dest"
    }
    $copied++
}

if ($copied -eq 0) {
    Write-Error "No $libName found under src-tauri/target/<triple>/$Profile/. Run the Rust/Android build first."
}

Write-Host "Synced $copied ABI(s). You can run: npm run android:assemble-apk"
