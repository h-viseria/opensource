# llama-cpp-sys builds llama.cpp with CMake. Expose cmake.exe to Cargo build scripts.
# llama-cpp-sys forwards every CMAKE_* env var to CMake as -D flags — do not set spurious CMAKE_* .
# CMake 4.x + SDK Ninja 1.12 fails configure (ninja -?); use SDK CMake 3.22.x for Android cross-builds.

function Resolve-CmakeExe {
    param([Parameter(Mandatory = $true)][string]$Candidate)

    $c = $Candidate.Trim().Trim('"')
    if ($c -match '[\\/]cmake\.exe$') {
        if (Test-Path -LiteralPath $c) { return (Resolve-Path -LiteralPath $c).Path }
        return $null
    }
    $exe = Join-Path $c "cmake.exe"
    if (Test-Path -LiteralPath $exe) { return (Resolve-Path -LiteralPath $exe).Path }
    return $null
}

function Get-AndroidSdkRoot {
    if ($env:ANDROID_HOME -and (Test-Path $env:ANDROID_HOME)) { return $env:ANDROID_HOME }
    $d = Join-Path $env:LOCALAPPDATA "Android\Sdk"
    if (Test-Path $d) { return $d }
    return $null
}

function Install-SdkCmake322 {
    $sdk = Get-AndroidSdkRoot
    if (-not $sdk) { return $false }

    $sdkmanager = @(
        (Join-Path $sdk "cmdline-tools\latest\bin\sdkmanager.bat"),
        (Join-Path $sdk "cmdline-tools\current\bin\sdkmanager.bat"),
        (Join-Path $sdk "tools\bin\sdkmanager.bat")
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $sdkmanager) {
        Write-Warning "sdkmanager not found. Install CMake 3.22.1 via Android Studio SDK Manager (SDK Tools)."
        return $false
    }

    Write-Host "==> Installing SDK CMake 3.22.1 (needed for llama; CMake 4.x breaks Ninja detect)..."
    $prev = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    cmd /c "echo y | `"$sdkmanager`" `"cmake;3.22.1`""
    $ErrorActionPreference = $prev

    $exe = Join-Path $sdk "cmake\3.22.1\bin\cmake.exe"
    return (Test-Path -LiteralPath $exe)
}

function Get-SdkCmakeExecutables {
    $sdk = Get-AndroidSdkRoot
    if (-not $sdk) { return @() }

    $cmakeRoot = Join-Path $sdk "cmake"
    if (-not (Test-Path $cmakeRoot)) { return @() }

    $items = @()
    foreach ($dir in Get-ChildItem $cmakeRoot -Directory -ErrorAction SilentlyContinue) {
        $exe = Join-Path $dir.FullName "bin\cmake.exe"
        if (-not (Test-Path -LiteralPath $exe)) { continue }
        $name = $dir.Name
        $major = 0
        $minor = 0
        if ($name -match '^(\d+)\.(\d+)') {
            $major = [int]$matches[1]
            $minor = [int]$matches[2]
        }
        # Prefer 3.22.x for llama-cpp-sys on Windows; avoid 4.x ninja -? probe.
        $rank = if ($major -eq 3 -and $minor -eq 22) { 0 }
            elseif ($major -eq 3 -and $minor -lt 22) { 1 }
            elseif ($major -eq 3) { 2 }
            else { 9 }
        $items += [PSCustomObject]@{
            Rank = $rank
            Exe  = (Resolve-Path -LiteralPath $exe).Path
            Label = $name
        }
    }
    return $items | Sort-Object Rank, Label
}

function Clear-LlamaCmakeEnvPollution {
    $keep = @{
        CMAKE_TOOLCHAIN_FILE = $true
        CMAKE_PREFIX_PATH    = $true
        CMAKE_GENERATOR      = $true
        CMAKE_BUILD_TYPE     = $true
    }
    Get-ChildItem Env: | ForEach-Object {
        $name = $_.Name
        if (-not $name.StartsWith("CMAKE_")) { return }
        if ($keep.ContainsKey($name)) { return }
        Remove-Item -Path "Env:$name" -ErrorAction SilentlyContinue
    }
    Remove-Item Env:TARGET_CMAKE -ErrorAction SilentlyContinue
    # Host-side CMake must not pick NMake when building Android deps on Windows.
    $env:CMAKE_GENERATOR = "Ninja"
}

function Get-CmakeExeCandidates {
    $list = [System.Collections.Generic.List[string]]::new()

    $appRoot = Split-Path -Parent $PSScriptRoot
    $localFile = Join-Path $appRoot "cmake.home.local"
    if (Test-Path $localFile) {
        $line = (
            Get-Content $localFile -ErrorAction SilentlyContinue |
            Where-Object { $_ -and -not $_.StartsWith("#") } |
            Select-Object -First 1
        )
        if ($line) {
            $resolved = Resolve-CmakeExe $line
            if ($resolved) {
                if (Test-CmakeVersionOkForLlama $resolved) {
                    $list.Add($resolved)
                } else {
                    Write-Warning "cmake.home.local points at CMake 4.x ($resolved). Use SDK CMake 3.22.1 instead."
                }
            }
        }
    }

    foreach ($item in (Get-SdkCmakeExecutables)) {
        if (Test-CmakeVersionOkForLlama $item.Exe) {
            $list.Add($item.Exe)
        }
    }

    $cmd = Get-Command cmake -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) {
        $list.Add($cmd.Source)
    }

    $pf86 = ${env:ProgramFiles(x86)}
    $extraPaths = @(
        "$env:ProgramFiles\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft\CMake\bin\cmake.exe"
    )
    if ($pf86) { $extraPaths += (Join-Path $pf86 "CMake\bin\cmake.exe") }
    foreach ($pattern in $extraPaths) {
        if ($pattern -and (Test-Path -LiteralPath $pattern)) {
            $list.Add((Resolve-Path -LiteralPath $pattern).Path)
        }
    }

    return $list | Select-Object -Unique
}

function Test-CmakeVersionOkForLlama {
    param([string]$CmakeExe)
    if (-not $CmakeExe -or $CmakeExe -notmatch 'cmake\.exe$') { return $false }
    if (-not (Test-Path -LiteralPath $CmakeExe)) { return $false }
    $out = & $CmakeExe --version 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0 -and $out -notmatch 'cmake version') { return $false }
    if ($out -match 'cmake version (\d+)\.(\d+)') {
        $major = [int]$matches[1]
        $minor = [int]$matches[2]
        if ($major -ge 4) { return $false }
        if ($major -eq 3 -and $minor -gt 28) { return $false }
    }
    return $true
}

function Remove-StaleLlamaCppSysBuildDirs {
    param(
        [Parameter(Mandatory = $true)][string]$CmakeExe
    )
    $appRoot = Split-Path -Parent $PSScriptRoot
    $srcTauri = Join-Path $appRoot "src-tauri"
    $expected = ($CmakeExe -replace '\\', '/')
    foreach ($triple in @(
            "aarch64-linux-android",
            "armv7-linux-androideabi",
            "i686-linux-android",
            "x86_64-linux-android"
        )) {
        $buildRoot = Join-Path $srcTauri "target\$triple\release\build"
        if (-not (Test-Path $buildRoot)) { continue }
        Get-ChildItem $buildRoot -Directory -Filter "llama-cpp-sys-2-*" -ErrorAction SilentlyContinue |
            ForEach-Object {
                $cache = Join-Path $_.FullName "out\build\CMakeCache.txt"
                $keep = $false
                if (Test-Path -LiteralPath $cache) {
                    $cacheText = Get-Content -LiteralPath $cache -Raw -ErrorAction SilentlyContinue
                    if ($cacheText -and ($cacheText -match [regex]::Escape($expected)) -and
                        ($cacheText -match 'CMAKE_GENERATOR:INTERNAL=Ninja')) {
                        $keep = $true
                    }
                    if ($cacheText -match 'NMake Makefiles|CMAKE_GENERATOR:UNINITIALIZED=Ninja') {
                        $keep = $false
                    }
                }
                if (-not $keep) {
                    Write-Host "==> Clearing stale llama-cpp-sys build cache: $($_.Name) ($triple)"
                    Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
    }
}

function Ensure-CmakeForLlama {
    Clear-LlamaCmakeEnvPollution

    $candidates = @(Get-CmakeExeCandidates)
    if ($candidates.Count -eq 0 -or ($candidates | Where-Object { Test-CmakeVersionOkForLlama $_ }).Count -eq 0) {
        if (Install-SdkCmake322) {
            $candidates = @(Get-CmakeExeCandidates)
        }
    }

    function Get-CmakeRank([string]$exe) {
        if ($exe -match '[\\/]cmake[\\/](\d+\.\d+(?:\.\d+)?)[\\/]') {
            $v = [version]$matches[1]
            if ($v.Major -eq 3 -and $v.Minor -eq 22) { return 0 }
            if ($v.Major -eq 3) { return 1 }
            return 9
        }
        return 5
    }

    $candidates = $candidates | Sort-Object { Get-CmakeRank $_ }

    foreach ($cmakeExe in $candidates) {
        if (-not (Test-CmakeVersionOkForLlama $cmakeExe)) {
            Write-Warning "Skipping CMake (too new for current Ninja bundle): $cmakeExe"
            continue
        }
        $binDir = Split-Path -Parent $cmakeExe
        if (-not ($env:PATH -split ';' | Where-Object { $_ -ieq $binDir })) {
            $env:PATH = "$binDir;$env:PATH"
        }
        # cmake crate reads CMAKE for the executable path (not forwarded by llama-cpp-sys).
        $env:CMAKE = $cmakeExe
        Write-Host "Using CMake: $cmakeExe"
        Remove-StaleLlamaCppSysBuildDirs -CmakeExe $cmakeExe
        return $cmakeExe
    }

    throw @"
CMake 3.22.x is required for llama Android builds on Windows (CMake 4.x + SDK Ninja fails).

Do one of:
  1) Android Studio -> SDK Manager -> SDK Tools -> show package details -> CMake 3.22.1
  2) sdkmanager `"cmake;3.22.1`"
  3) Point cmake.home.local at: ...\Android\Sdk\cmake\3.22.1\bin

Then rerun: npm run android:build-apk-llama
"@
}

Ensure-CmakeForLlama | Out-Null
