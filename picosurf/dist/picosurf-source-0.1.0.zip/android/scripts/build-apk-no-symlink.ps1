# Build a release APK on Windows without Developer Mode / symlink privileges.
# 1) Tauri compiles Rust + refreshes Android assets (may exit with a symlink error - OK).
# 2) Copy .so files into jniLibs (no symlinks).
# 3) Gradle packages APK while skipping Rust tasks that would invoke Tauri again.

param(
    [ValidateSet("arm64", "universal")]
    [string]$Abi = "arm64",
    [switch]$Llama
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
Set-Location $appRoot

Write-Host "==> Frontend build"
npm run build
if ($LASTEXITCODE -ne 0) { throw "npm run build failed with exit code $LASTEXITCODE" }

Write-Host "==> Tauri Android build (symlink failure at the end is expected without Developer Mode)"
if ($Llama) {
    $env:CARGO_TARGET_DIR = (Join-Path $appRoot "src-tauri\target")
    . (Join-Path $PSScriptRoot "ensure-cmake-for-llama.ps1")
    $llamaPatched = & (Join-Path $PSScriptRoot "patch-llama-cpp-sys-android.ps1")
    if ($llamaPatched) {
        Write-Host "==> llama-cpp-sys patched; clearing its Android build cache so CMake reconfigures with Ninja"
        . (Join-Path $PSScriptRoot "ensure-cmake-for-llama.ps1")
    }
    $env:ANDROID_API_LEVEL = "26"
    $env:ANDROID_PLATFORM = "android-26"
    if ($Abi -eq "arm64") {
        $env:BINDGEN_EXTRA_CLANG_ARGS = "--target=aarch64-linux-android26"
    }
    if (-not $env:ANDROID_NDK_HOME -and -not $env:ANDROID_NDK_ROOT -and -not $env:NDK_ROOT) {
        $sdk = $env:ANDROID_HOME
        if (-not $sdk) { $sdk = Join-Path $env:LOCALAPPDATA "Android\Sdk" }
        $ndkRoot = Join-Path $sdk "ndk"
        if (Test-Path $ndkRoot) {
            $latest = Get-ChildItem $ndkRoot -Directory | Sort-Object Name -Descending | Select-Object -First 1
            if ($latest) {
                $env:ANDROID_NDK_HOME = $latest.FullName
                Write-Host "Using ANDROID_NDK_HOME=$($env:ANDROID_NDK_HOME)"
            }
        }
    }
    # npm may not inherit a refreshed PATH on Windows; CMAKE* env vars are set by ensure-cmake-for-llama.ps1
    npm run tauri android build -- --apk --ci --features llama
    $tauriExit = $LASTEXITCODE
    if ($tauriExit -ne 0) {
        Write-Host "==> Retrying only if llama-cpp-sys build.rs was just patched (bindgen / CMAKE env fix)"
        $didPatch = & (Join-Path $PSScriptRoot "patch-llama-cpp-sys-android.ps1") -Quiet; $LASTEXITCODE = 0
        if ($didPatch) {
            . (Join-Path $PSScriptRoot "ensure-cmake-for-llama.ps1")
            npm run tauri android build -- --apk --ci --features llama
            $tauriExit = $LASTEXITCODE
        } else {
            Write-Host "No new llama-cpp-sys patch applied. If the log shows CMake/Ninja errors, rerun after SDK CMake 3.22.1 is installed."
        }
    }
} else {
    npm run tauri android build -- --apk --ci
    $tauriExit = $LASTEXITCODE
}
if ($tauriExit -ne 0) {
    Write-Warning "tauri android build exited with code $tauriExit (often the jniLibs symlink step)."
}

Write-Host "==> Copy native libraries into jniLibs"
& (Join-Path $PSScriptRoot "sync-jni-libs.ps1") -Profile release -IncludeCppShared:$Llama

Write-Host "==> Gradle assemble (skip Rust/Tauri jni symlink steps)"
. (Join-Path $PSScriptRoot "ensure-java-for-gradle.ps1")
$gradleDir = Join-Path $appRoot "src-tauri\gen\android"
Set-Location $gradleDir

$skipRust = @(
    "-x", "rustBuildUniversalRelease",
    "-x", "rustBuildArm64Release",
    "-x", "rustBuildArmRelease",
    "-x", "rustBuildX86Release",
    "-x", "rustBuildX86_64Release"
)

if ($Abi -eq "arm64") {
    $task = "assembleArm64Release"
    Write-Host "Building $task (typical physical phones, one ABI)"
} else {
    $task = "assembleUniversalRelease"
    Write-Host ('Building {0} (all ABIs; every target must exist under src-tauri/target/)' -f $task)
}

& .\gradlew.bat $task @skipRust
if ($LASTEXITCODE -ne 0) {
    throw "Gradle failed with exit code $LASTEXITCODE"
}

Set-Location $appRoot
Write-Host ""
Write-Host "Done. Look for APK under:"
Write-Host '  src-tauri/gen/android/app/build/outputs/apk/'
