# Build a release APK on Windows without Developer Mode / symlink privileges.
# 1) Tauri compiles Rust + refreshes Android assets (may exit with a symlink error - OK).
# 2) Copy .so files into jniLibs (no symlinks).
# 3) Gradle packages APK while skipping Rust tasks that would invoke Tauri again.

param(
    [ValidateSet("arm64", "universal")]
    [string]$Abi = "arm64"
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
Set-Location $appRoot

Write-Host "==> Frontend build"
npm run build
if ($LASTEXITCODE -ne 0) { throw "npm run build failed with exit code $LASTEXITCODE" }

Write-Host "==> Tauri Android build (symlink failure at the end is expected without Developer Mode)"
npm run tauri android build -- --apk --ci
$tauriExit = $LASTEXITCODE
if ($tauriExit -ne 0) {
    Write-Warning "tauri android build exited with code $tauriExit (often the jniLibs symlink step)."
}

Write-Host "==> Copy native libraries into jniLibs"
& (Join-Path $PSScriptRoot "sync-jni-libs.ps1") -Profile release

Write-Host "==> Gradle assemble (skip Rust/Tauri jni symlink steps)"
. (Join-Path $PSScriptRoot "ensure-java-for-gradle.ps1")
$gradleDir = Join-Path $appRoot "src-tauri\gen\android"
Set-Location $gradleDir

$skipRust = @(
    "-x", "rustBuildUniversalRelease",
    "-x", "rustBuildArm64Release",
    "-x", "rustBuildArmRelease",
    "-x", "rustBuildX86Release",
    "-x", "rustBuildX86_64Release"
)

if ($Abi -eq "arm64") {
    $task = "assembleArm64Release"
    Write-Host "Building $task (typical physical phones, one ABI)"
} else {
    $task = "assembleUniversalRelease"
    Write-Host ('Building {0} (all ABIs; every target must exist under src-tauri/target/)' -f $task)
}

& .\gradlew.bat $task @skipRust
if ($LASTEXITCODE -ne 0) {
    throw "Gradle failed with exit code $LASTEXITCODE"
}

Set-Location $appRoot
Write-Host ""
Write-Host "Done. Look for APK under:"
Write-Host '  src-tauri/gen/android/app/build/outputs/apk/'
