# llama-cpp-sys-2 bindgen on Android NDK r26+ needs --target=aarch64-linux-android26 (etc.).
param([switch]$Quiet)

function Apply-LlamaCppSysAndroidPatch {
    $registryRoot = Join-Path $env:USERPROFILE ".cargo\registry\src"
    if (-not (Test-Path $registryRoot)) {
        if (-not $Quiet) { Write-Warning "Cargo registry not found; skip llama-cpp-sys Android patch." }
        return $false
    }

    $dirs = Get-ChildItem -Path $registryRoot -Recurse -Directory -Filter "llama-cpp-sys-2-*" -ErrorAction SilentlyContinue
    if (-not $dirs) {
        if (-not $Quiet) { Write-Warning "llama-cpp-sys-2 not in registry yet (run once, then patch again)." }
        return $false
    }

    $bindgenMarker = '.clang_arg(format!("--sysroot={}", tc.sysroot))'
    $bindgenInsert = '            .clang_arg(format!("--target={}{}", tc.arch_triple, tc.api))' + [Environment]::NewLine + '            '

    $cmakeLoopNew = @"
    // Pass CMAKE_ environment variables down to CMake (skip spurious Windows/Android env pollution)
    for (key, value) in env::vars() {
        if !key.starts_with("CMAKE_") {
            continue;
        }
        if key == "CMAKE_MAKE_PROGRAM"
            || key == "CMAKE_BUILD_PARALLEL_LEVEL"
            || key == "CMAKE_GENERATOR"
        {
            continue;
        }
        if key.contains("_linux_") || key.contains("-linux-") {
            continue;
        }
        config.define(&key, &value);
    }
"@

    $ninjaPatchMarker = 'let mut config = Config::new(&llama_src);'
    $ninjaPatchInsert = @'
    let mut config = Config::new(&llama_src);

    // Windows hosts default CMake to NMake; Android NDK cross-builds need Ninja (-G, not -DCMAKE_GENERATOR).
    {
        let host = env::var("HOST").unwrap_or_default();
        let target = env::var("TARGET").unwrap_or_default();
        if host.contains("windows") && target.contains("android") {
            config.generator("Ninja");
        }
    }
'@

    $patched = $false
    foreach ($dir in $dirs) {
        $buildRs = Join-Path $dir.FullName "build.rs"
        if (-not (Test-Path $buildRs)) { continue }
        $text = [IO.File]::ReadAllText($buildRs)
        $dirPatched = $false

        if (-not $text.Contains('--target={}{}", tc.arch_triple, tc.api)')) {
            $idx = $text.IndexOf($bindgenMarker)
            if ($idx -ge 0) {
                $text = $text.Insert($idx, $bindgenInsert)
                $dirPatched = $true
                if (-not $Quiet) { Write-Host "Patched Android bindgen in $($dir.Name)" }
            } elseif (-not $Quiet) {
                Write-Warning "llama-cpp-sys build.rs layout changed in $($dir.Name); bindgen patch skipped."
            }
        }

        if ($text -match 'if key\.starts_with\("CMAKE_"\)' -and $text -notmatch 'CMAKE_MAKE_PROGRAM') {
            $text = [regex]::Replace(
                $text,
                '(?s)    // Pass CMAKE_ environment variables down to CMake\r?\n    for \(key, value\) in env::vars\(\) \{\r?\n        if key\.starts_with\("CMAKE_"\) \{\r?\n            config\.define\(&key, &value\);\r?\n        \}\r?\n    \}',
                ($cmakeLoopNew -replace "`r`n", "`n"))
            $dirPatched = $true
            if (-not $Quiet) { Write-Host "Patched CMAKE_ env forwarding in $($dir.Name)" }
        } elseif ($text -match 'CMAKE_MAKE_PROGRAM' -and $text -notmatch 'CMAKE_GENERATOR') {
            $text = [regex]::Replace(
                $text,
                '(?s)        if key == "CMAKE_MAKE_PROGRAM" \|\| key == "CMAKE_BUILD_PARALLEL_LEVEL" \{\r?\n            continue;\r?\n        \}',
                "        if key == `"CMAKE_MAKE_PROGRAM`" || key == `"CMAKE_BUILD_PARALLEL_LEVEL`" || key == `"CMAKE_GENERATOR`" {`n            continue;`n        }")
            $dirPatched = $true
            if (-not $Quiet) { Write-Host "Patched CMAKE_GENERATOR skip in $($dir.Name)" }
        }

        if ($text.Contains($ninjaPatchMarker) -and $text -notmatch 'config\.generator\("Ninja"\)') {
            $text = $text.Replace($ninjaPatchMarker, ($ninjaPatchInsert -replace "`r`n", "`n"))
            $dirPatched = $true
            if (-not $Quiet) { Write-Host "Patched Android Ninja generator in $($dir.Name)" }
        }

        if ($dirPatched) {
            [IO.File]::WriteAllText($buildRs, $text)
            $patched = $true
        }
    }
    return $patched
}

$ErrorActionPreference = "Stop"
$patched = Apply-LlamaCppSysAndroidPatch
if ($patched -and -not $Quiet) {
    Write-Host "If bindgen still fails, run: cd src-tauri; cargo clean -p llama-cpp-sys-2"
}
return $patched
