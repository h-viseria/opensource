# Debug APK (Gradle-signed with debug keystore) — easiest for emulator/device sideload.
$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "ensure-java-for-gradle.ps1")
Set-Location (Join-Path $appRoot "src-tauri\gen\android")
& .\gradlew.bat assembleArm64Debug `
    -x rustBuildArm64Debug `
    -x rustBuildUniversalDebug `
    -x rustBuildArmDebug `
    -x rustBuildX86Debug `
    -x rustBuildX86_64Debug
if ($LASTEXITCODE -ne 0) { throw "Gradle failed with exit code $LASTEXITCODE" }
Write-Host ""
Write-Host 'Debug APK (signed): src-tauri/gen/android/app/build/outputs/apk/arm64/debug/app-arm64-debug.apk'
