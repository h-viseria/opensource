# Sign an unsigned release APK with the Android debug keystore so adb install works locally.
param(
    [Parameter(Mandatory = $true)]
    [string]$UnsignedApk
)

$ErrorActionPreference = "Stop"
if (-not (Test-Path $UnsignedApk)) {
    throw "APK not found: $UnsignedApk"
}

$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = Join-Path $env:LOCALAPPDATA "Android\Sdk" }
if (-not (Test-Path $sdk)) {
    throw "Set ANDROID_HOME to your Android SDK (Android Studio -> SDK location)."
}

$buildTools = Get-ChildItem (Join-Path $sdk "build-tools") -Directory -ErrorAction SilentlyContinue |
    Sort-Object Name -Descending |
    Select-Object -First 1
if (-not $buildTools) {
    throw "No build-tools under $sdk. Install Android SDK Build-Tools in SDK Manager."
}

$apksigner = Join-Path $buildTools.FullName "apksigner.bat"
if (-not (Test-Path $apksigner)) {
    throw "apksigner not found: $apksigner"
}

$ks = Join-Path $env:USERPROFILE ".android\debug.keystore"
if (-not (Test-Path $ks)) {
    throw @"
Debug keystore missing: $ks
Open Android Studio once and run any emulator or build, or create the keystore from Studio.
"@
}

$signedApk = [System.IO.Path]::ChangeExtension($UnsignedApk, $null).TrimEnd(".")
if ($signedApk.EndsWith("-unsigned")) {
    $signedApk = $signedApk.Substring(0, $signedApk.Length - "-unsigned".Length) + "-signed.apk"
} else {
    $signedApk = $signedApk + "-signed.apk"
}

Write-Host "Signing -> $signedApk"
& $apksigner sign `
    --ks $ks `
    --ks-key-alias androiddebugkey `
    --ks-pass pass:android `
    --key-pass pass:android `
    --out $signedApk `
    $UnsignedApk
if ($LASTEXITCODE -ne 0) { throw "apksigner failed with exit code $LASTEXITCODE" }

& $apksigner verify --verbose $signedApk
if ($LASTEXITCODE -ne 0) { throw "Signed APK verification failed" }

Write-Host "Install with:"
Write-Host "  & `"$sdk\platform-tools\adb.exe`" install -r `"$signedApk`""
