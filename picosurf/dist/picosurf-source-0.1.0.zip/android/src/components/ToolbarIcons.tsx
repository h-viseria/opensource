type IconProps = {
  className?: string;
};

export function HistoryIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" width="18" height="18" aria-hidden>
      <path
        fill="currentColor"
        d="M12 2a10 10 0 0 0-7.35 16.76l-1.2 1.2 1.42 1.42 1.2-1.2A10 10 0 1 0 12 2Zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm-.5 3v4.25l3.5 2.08.75-1.23-2.75-1.62V7H11.5Z"
      />
    </svg>
  );
}

export function BookmarksIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" width="18" height="18" aria-hidden>
      <path
        fill="currentColor"
        d="M6 2h12a2 2 0 0 1 2 2v18l-8-4.5L4 22V4a2 2 0 0 1 2-2Zm0 2v14.3l6-3.4 6 3.4V4H6Z"
      />
    </svg>
  );
}
