import { useEffect, useState } from "react";
import { bookmarkList, bookmarkRemove } from "../browser/api";
import type { Bookmark } from "../types/ipc";

type BookmarksPanelProps = {
  open: boolean;
  onClose: () => void;
  onOpenUrl: (url: string) => void;
};

export function BookmarksPanel({ open, onClose, onOpenUrl }: BookmarksPanelProps) {
  const [items, setItems] = useState<Bookmark[]>([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!open) return;
    void load();
  }, [open]);

  async function load() {
    try {
      setItems(await bookmarkList());
      setMessage("");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function remove(url: string) {
    try {
      await bookmarkRemove(url);
      await load();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  if (!open) return null;

  return (
    <div className="sheet-backdrop" role="presentation" onClick={onClose}>
      <aside
        className="sheet-panel"
        aria-label="Bookmarks"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="sheet-header">
          <div>
            <h2>Bookmarks</h2>
            <p className="sheet-sub">Saved on this device.</p>
          </div>
          <button type="button" className="btn ghost" onClick={onClose}>
            Close
          </button>
        </header>
        <div className="sheet-body">
          {message ? <p className="sheet-meta">{message}</p> : null}
          <div className="sheet-list">
            {items.length === 0 ? (
              <p className="sheet-meta">No bookmarks yet. Tap ★ on a page to save it.</p>
            ) : (
              <ul>
                {items.map((item) => (
                  <li key={item.id} className="bookmark-row">
                    <button
                      type="button"
                      className="sheet-link"
                      onClick={() => {
                        onOpenUrl(item.url);
                        onClose();
                      }}
                    >
                      {item.title || item.domain || item.url}
                    </button>
                    <span className="sheet-meta">{item.domain}</span>
                    <button
                      type="button"
                      className="btn ghost bookmark-remove"
                      aria-label="Remove bookmark"
                      onClick={() => void remove(item.url)}
                    >
                      Remove
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </aside>
    </div>
  );
}
