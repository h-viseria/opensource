import { useEffect, useState } from "react";
import {
  onResearchProgress,
  researchFeatureRequestInstall,
  researchFeatureStatus,
  researchRun,
  researchStop,
  settingsGet,
  settingsSet,
} from "../browser/api";
import type { ResearchFeatureStatus, ResearchProgress } from "../types/ipc";
import { ModelPanel } from "./ModelPanel";

type ResearchPanelProps = {
  fetchReady: boolean;
  fetchError: string | null;
  onOpenReport: (html: string) => void;
  onFeatureInstalled?: () => void;
};

export function ResearchPanel({
  fetchReady,
  fetchError,
  onOpenReport,
  onFeatureInstalled,
}: ResearchPanelProps) {
  const [goal, setGoal] = useState("");
  const [feature, setFeature] = useState<ResearchFeatureStatus | null>(null);
  const [aiEnabled, setAiEnabled] = useState(false);
  const [progress, setProgress] = useState<ResearchProgress | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void researchFeatureStatus().then(setFeature).catch(() => setFeature(null));
    void settingsGet()
      .then((s) => setAiEnabled(s.aiEnabled))
      .catch(() => setAiEnabled(false));
    let unlisten: (() => void) | undefined;
    void onResearchProgress((p) => setProgress(p)).then((fn) => {
      unlisten = fn;
    });
    return () => unlisten?.();
  }, []);

  async function setResearchEnabled(enabled: boolean) {
    if (busy) return;
    setBusy(true);
    setMessage("");
    try {
      if (enabled) {
        if (!feature?.installed) {
          const status = await researchFeatureRequestInstall();
          setFeature(status);
          onFeatureInstalled?.();
        }
        const settings = await settingsGet();
        const saved = await settingsSet({ ...settings, aiEnabled: true });
        setAiEnabled(saved.aiEnabled);
        setMessage("Research enabled. Download a model, then turn on “Load model in memory”.");
      } else {
        const settings = await settingsGet();
        const saved = await settingsSet({ ...settings, aiEnabled: false });
        setAiEnabled(saved.aiEnabled);
        setMessage("Local research paused. Downloaded models stay on disk.");
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function runResearch() {
    if (!fetchReady) {
      setMessage("Research web layer is still starting…");
      return;
    }
    if (!aiEnabled || !feature?.installed) {
      setMessage("Turn on “Enable local research” first.");
      return;
    }
    setBusy(true);
    setMessage("");
    setProgress(null);
    try {
      const result = await researchRun(goal);
      setMessage(result.message);
      if (result.reportHtml) {
        onOpenReport(result.reportHtml);
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  const researchActive = Boolean(feature?.installed && aiEnabled);

  return (
    <section className="research-panel">
      <h2>Research</h2>

      <label className={`sheet-check research-toggle${busy ? " is-disabled" : ""}`}>
        <input
          type="checkbox"
          checked={researchActive}
          disabled={busy}
          onChange={(event) => void setResearchEnabled(event.target.checked)}
        />
        <span>Enable local research on this device</span>
      </label>

      {feature?.installed ? (
        <>
          <ModelPanel compact />
          {fetchError ? <p className="error">{fetchError}</p> : null}
          {!fetchReady ? <p className="hint">Preparing page fetch layer…</p> : null}
          <textarea
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="e.g. Compare privacy browsers for Android"
            rows={4}
            disabled={!researchActive}
          />
          <div className="row-actions">
            <button
              type="button"
              className="btn primary"
              disabled={busy || !goal.trim() || !fetchReady || !researchActive}
              onClick={() => void runResearch()}
            >
              {busy ? "Working…" : "Run research"}
            </button>
            {busy ? (
              <button type="button" className="btn" onClick={() => void researchStop()}>
                Stop
              </button>
            ) : null}
          </div>
        </>
      ) : (
        <p className="hint">
          Turn on the switch above to download models and run on-device research.
        </p>
      )}

      {progress ? (
        <p className="hint">
          {progress.phase}: {progress.detail}
        </p>
      ) : null}
      {message ? <p className="status">{message}</p> : null}
    </section>
  );
}
