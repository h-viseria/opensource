import { useEffect, useState } from "react";
import {
  onResearchProgress,
  researchFeatureRequestInstall,
  researchFeatureStatus,
  researchRun,
  researchStop,
} from "../browser/api";
import type { ResearchFeatureStatus, ResearchProgress } from "../types/ipc";
import { ModelPanel } from "./ModelPanel";

type ResearchPanelProps = {
  fetchReady: boolean;
  fetchError: string | null;
  onOpenReport: (html: string) => void;
};

export function ResearchPanel({ fetchReady, fetchError, onOpenReport }: ResearchPanelProps) {
  const [goal, setGoal] = useState("");
  const [feature, setFeature] = useState<ResearchFeatureStatus | null>(null);
  const [progress, setProgress] = useState<ResearchProgress | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void researchFeatureStatus().then(setFeature).catch(() => setFeature(null));
    let unlisten: (() => void) | undefined;
    void onResearchProgress((p) => setProgress(p)).then((fn) => {
      unlisten = fn;
    });
    return () => unlisten?.();
  }, []);

  async function installFeature() {
    setBusy(true);
    try {
      const status = await researchFeatureRequestInstall();
      setFeature(status);
      setMessage("Research pack enabled. Download a model below, then run a question.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function runResearch() {
    if (!fetchReady) {
      setMessage("Research web layer is still starting…");
      return;
    }
    setBusy(true);
    setMessage("");
    setProgress(null);
    try {
      const result = await researchRun(goal);
      setMessage(result.message);
      if (result.reportHtml) {
        onOpenReport(result.reportHtml);
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  if (!feature?.installed) {
    return (
      <section className="research-panel">
        <h2>Local research</h2>
        <p>
          Summarize the web on your phone. Sources are fetched over HTTPS; answers are generated on
          device with a GGUF model you download.
        </p>
        <button type="button" className="btn primary" disabled={busy} onClick={() => void installFeature()}>
          Install research pack
        </button>
        {message ? <p className="hint">{message}</p> : null}
      </section>
    );
  }

  return (
    <section className="research-panel">
      <h2>Research</h2>
      <ModelPanel compact />
      {fetchError ? <p className="error">{fetchError}</p> : null}
      {!fetchReady ? <p className="hint">Starting research fetch webview…</p> : null}
      <textarea
        value={goal}
        onChange={(e) => setGoal(e.target.value)}
        placeholder="e.g. Compare privacy browsers for Android"
        rows={4}
      />
      <div className="row-actions">
        <button
          type="button"
          className="btn primary"
          disabled={busy || !goal.trim() || !fetchReady}
          onClick={() => void runResearch()}
        >
          {busy ? "Working…" : "Run research"}
        </button>
        {busy ? (
          <button type="button" className="btn" onClick={() => void researchStop()}>
            Stop
          </button>
        ) : null}
      </div>
      {progress ? (
        <p className="hint">
          {progress.phase}: {progress.detail}
        </p>
      ) : null}
      {message ? <p className="status">{message}</p> : null}
    </section>
  );
}
