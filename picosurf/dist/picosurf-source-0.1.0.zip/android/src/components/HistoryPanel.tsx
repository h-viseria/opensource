import { FormEvent, useEffect, useState } from "react";
import {
  historyAiEnabledGet,
  historyAiEnabledSet,
  historyClear,
  historyEnabledGet,
  historyEnabledSet,
  historyList,
} from "../browser/api";
import type { HistoryVisit } from "../types/ipc";

type HistoryPanelProps = {
  open: boolean;
  onClose: () => void;
  onOpenUrl: (url: string) => void;
};

export function HistoryPanel({ open, onClose, onOpenUrl }: HistoryPanelProps) {
  const [query, setQuery] = useState("");
  const [entries, setEntries] = useState<HistoryVisit[]>([]);
  const [historyEnabled, setHistoryEnabled] = useState(false);
  const [aiHistoryEnabled, setAiHistoryEnabled] = useState(false);
  const [message, setMessage] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearing, setClearing] = useState(false);

  useEffect(() => {
    if (!open) return;
    void historyEnabledGet().then(setHistoryEnabled).catch(() => undefined);
    void historyAiEnabledGet().then(setAiHistoryEnabled).catch(() => undefined);
    void loadEntries("");
  }, [open]);

  async function loadEntries(search: string) {
    try {
      setEntries(await historyList(search, 80));
      setMessage("");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function handleSearch(event: FormEvent) {
    event.preventDefault();
    await loadEntries(query.trim());
  }

  async function toggleHistoryEnabled(enabled: boolean) {
    try {
      setHistoryEnabled(await historyEnabledSet(enabled));
      if (!enabled) {
        setAiHistoryEnabled(false);
        setMessage("Browsing history is off. New pages will not be saved.");
      } else {
        setMessage("Browsing history is on. Pages you visit will be saved locally.");
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function toggleAiHistory(enabled: boolean) {
    try {
      setAiHistoryEnabled(await historyAiEnabledSet(enabled));
      setMessage(
        enabled
          ? "The AI agent may use matching local history entries."
          : "AI will not read browsing history.",
      );
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function clearAll() {
    if (clearing) return;
    setClearing(true);
    setMessage("");
    try {
      await historyClear();
      setQuery("");
      setEntries([]);
      setConfirmClear(false);
      setMessage("History cleared.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
      await loadEntries(query.trim());
    } finally {
      setClearing(false);
    }
  }

  if (!open) return null;

  return (
    <div className="sheet-backdrop" role="presentation" onClick={onClose}>
      <aside
        className="sheet-panel"
        aria-label="Browsing history"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="sheet-header">
          <div>
            <h2>History</h2>
            <p className="sheet-sub">Stored locally on this device.</p>
          </div>
          <button type="button" className="btn ghost" onClick={onClose}>
            Close
          </button>
        </header>
        <div className="sheet-body">
          <label className="sheet-check">
            <input
              type="checkbox"
              checked={historyEnabled}
              onChange={(event) => void toggleHistoryEnabled(event.target.checked)}
            />
            Save browsing history
          </label>
          <label className={`sheet-check${historyEnabled ? "" : " is-disabled"}`}>
            <input
              type="checkbox"
              checked={aiHistoryEnabled}
              disabled={!historyEnabled}
              onChange={(event) => void toggleAiHistory(event.target.checked)}
            />
            Allow AI to use browsing history
          </label>
          <form className="sheet-search" onSubmit={(event) => void handleSearch(event)}>
            <input
              value={query}
              placeholder="Search history"
              aria-label="Search history"
              onChange={(event) => setQuery(event.target.value)}
            />
            <button type="submit" className="btn">
              Search
            </button>
          </form>
          {message ? <p className="sheet-meta">{message}</p> : null}
          {!historyEnabled ? (
            <p className="sheet-meta">
              History saving is off by default. Turn it on to record new visits.
            </p>
          ) : null}
          <div className="sheet-list">
            {entries.length === 0 ? (
              <p className="sheet-meta">No history yet.</p>
            ) : (
              <ul>
                {entries.map((entry) => (
                  <li key={entry.id}>
                    <button
                      type="button"
                      className="sheet-link"
                      onClick={() => {
                        onOpenUrl(entry.url);
                        onClose();
                      }}
                    >
                      {entry.title || entry.domain || entry.url}
                    </button>
                    <span className="sheet-meta">
                      {entry.domain} · {formatWhen(entry.visitedAt)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <footer className="sheet-footer">
          {confirmClear ? (
            <div className="sheet-confirm">
              <p>Clear all browsing history?</p>
              <div className="row-actions">
                <button type="button" className="btn ghost" disabled={clearing} onClick={() => setConfirmClear(false)}>
                  Cancel
                </button>
                <button type="button" className="btn primary" disabled={clearing} onClick={() => void clearAll()}>
                  {clearing ? "Clearing…" : "Clear"}
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              className="btn ghost"
              onClick={() => setConfirmClear(true)}
              disabled={entries.length === 0}
            >
              Clear history
            </button>
          )}
        </footer>
      </aside>
    </div>
  );
}

function formatWhen(unixSeconds: number): string {
  if (!unixSeconds) return "";
  try {
    return new Date(unixSeconds * 1000).toLocaleString();
  } catch {
    return "";
  }
}
