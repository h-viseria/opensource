import { useEffect, useState } from "react";
import {
  modelsDownload,
  modelsList,
  modelsLoad,
  modelsSelect,
  onModelProgress,
} from "../browser/api";
import type { ModelInfo, ModelProgress, ModelsListResponse } from "../types/ipc";

type ModelPanelProps = {
  compact?: boolean;
};

export function ModelPanel({ compact }: ModelPanelProps) {
  const [data, setData] = useState<ModelsListResponse | null>(null);
  const [progress, setProgress] = useState<ModelProgress | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function refresh() {
    try {
      setData(await modelsList());
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  useEffect(() => {
    void refresh();
    let unlisten: (() => void) | undefined;
    void onModelProgress(setProgress).then((fn) => {
      unlisten = fn;
    });
    return () => unlisten?.();
  }, []);

  async function act(model: ModelInfo, action: "select" | "download" | "load") {
    setBusy(true);
    setMessage("");
    try {
      if (action === "select") {
        const res = await modelsSelect(model.id);
        setMessage(res.message);
      } else if (action === "download") {
        await modelsSelect(model.id);
        setData(await modelsDownload(model.id));
        setMessage("Download complete.");
      } else {
        await modelsSelect(model.id);
        setData(await modelsLoad(model.id));
        setMessage("Model loaded.");
      }
      if (action !== "download" && action !== "load") {
        await refresh();
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  const models = [...(data?.models ?? []), ...(data?.moreModels ?? [])];

  return (
    <section className={`model-panel ${compact ? "compact" : ""}`}>
      <h3>On-device model</h3>
      {data?.hardware ? (
        <p className="hint">
          {data.hardware.ramLabel} RAM · {data.hardware.storageLabel} free
        </p>
      ) : null}
      <ul className="model-list">
        {models.map((model) => (
          <li key={model.id}>
            <div>
              <strong>{model.displayName}</strong>
              <span className="hint"> · {model.sizeLabel} · {model.status}</span>
            </div>
            <div className="model-actions">
              {model.status === "ready" ? (
                <span className="hint">Loaded</span>
              ) : model.status === "downloaded" ? (
                <button type="button" disabled={busy} onClick={() => void act(model, "load")}>
                  Load
                </button>
              ) : (
                <button type="button" disabled={busy} onClick={() => void act(model, "download")}>
                  Download
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      {progress ? (
        <p className="hint">
          {progress.phase}: {progress.message} ({Math.round((progress.received / Math.max(progress.total, 1)) * 100)}%)
        </p>
      ) : null}
      {message ? <p className="status">{message}</p> : null}
    </section>
  );
}
