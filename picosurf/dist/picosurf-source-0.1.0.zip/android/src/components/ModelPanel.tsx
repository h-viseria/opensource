import { useEffect, useMemo, useState } from "react";
import {
  modelsDownload,
  modelsList,
  modelsLoad,
  modelsSelect,
  modelsUnload,
  onModelProgress,
} from "../browser/api";
import type { ModelInfo, ModelProgress, ModelsListResponse } from "../types/ipc";

type ModelPanelProps = {
  compact?: boolean;
};

type PendingAction = {
  kind: "download" | "load" | "unload";
  modelId: string;
};

function ModelRow({
  model,
  locked,
  onDownload,
}: {
  model: ModelInfo;
  locked: boolean;
  onDownload: (model: ModelInfo) => void;
}) {
  const inMemory = model.status === "ready";
  const onDisk = model.status === "downloaded";
  return (
    <li>
      <div>
        <strong>{model.displayName}</strong>
        {model.recommended ? <span className="tag">Recommended</span> : null}
        <span className="hint">
          {" "}
          · {model.sizeLabel} · {model.status.replace(/_/g, " ")}
        </span>
      </div>
      <div className="model-actions">
        {inMemory ? (
          <span className="hint">In memory</span>
        ) : onDisk ? (
          <span className="hint">On disk</span>
        ) : (
          <button
            type="button"
            className="btn primary"
            disabled={locked}
            onClick={() => onDownload(model)}
          >
            Download
          </button>
        )}
      </div>
    </li>
  );
}

export function ModelPanel({ compact }: ModelPanelProps) {
  const [data, setData] = useState<ModelsListResponse | null>(null);
  const [progress, setProgress] = useState<ModelProgress | null>(null);
  const [pending, setPending] = useState<PendingAction | null>(null);
  const [message, setMessage] = useState("");
  const [showMore, setShowMore] = useState(false);

  const locked = pending !== null;

  async function refresh() {
    try {
      setData(await modelsList());
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  useEffect(() => {
    void refresh();
    let unlisten: (() => void) | undefined;
    void onModelProgress((p) => {
      if (p.phase === "done" || p.phase === "error") {
        setProgress(p.phase === "error" ? p : null);
      } else {
        setProgress(p);
      }
    }).then((fn) => {
      unlisten = fn;
    });
    return () => unlisten?.();
  }, []);

  const allModels = useMemo(
    () => [...(data?.models ?? []), ...(data?.moreModels ?? [])],
    [data],
  );

  const memoryTarget = useMemo(() => {
    if (!data) return null;
    const selected = data.selectedId
      ? allModels.find((m) => m.id === data.selectedId)
      : undefined;
    if (selected && (selected.status === "downloaded" || selected.status === "ready")) {
      return selected;
    }
    return (
      allModels.find((m) => m.status === "ready") ??
      allModels.find((m) => m.status === "downloaded") ??
      allModels.find((m) => m.recommended) ??
      allModels[0] ??
      null
    );
  }, [allModels, data]);

  const memoryOn = Boolean(data?.loadedId);
  const loadingMemory = pending?.kind === "load";
  const canUseMemoryToggle =
    Boolean(data?.inferenceAvailable) &&
    memoryTarget != null &&
    (memoryTarget.status === "downloaded" || memoryTarget.status === "ready" || memoryOn);

  async function downloadModel(model: ModelInfo) {
    if (locked) return;
    setPending({ kind: "download", modelId: model.id });
    setMessage("");
    setProgress(null);
    try {
      await modelsSelect(model.id);
      setData(await modelsDownload(model.id));
      setMessage("Download complete. Turn on “Load model in memory” when ready.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
      setProgress(null);
    } finally {
      setPending(null);
    }
  }

  async function setMemoryLoaded(on: boolean) {
    if (locked) return;
    if (!memoryTarget) {
      setMessage("Download a model first.");
      return;
    }
    if (!data?.inferenceAvailable) {
      setMessage(
        "This APK was built without on-device inference. Rebuild with --features llama (see README).",
      );
      return;
    }
    setMessage("");
    setProgress(null);
    if (on) {
      if (memoryTarget.status !== "downloaded" && memoryTarget.status !== "ready") {
        setMessage("Download this model before loading it into memory.");
        return;
      }
      setPending({ kind: "load", modelId: memoryTarget.id });
      try {
        await modelsSelect(memoryTarget.id);
        setData(await modelsLoad(memoryTarget.id));
        setMessage("Model loaded into memory.");
        setProgress(null);
      } catch (err) {
        setMessage(err instanceof Error ? err.message : String(err));
        setProgress(null);
      } finally {
        setPending(null);
      }
    } else {
      setPending({ kind: "unload", modelId: memoryTarget.id });
      try {
        setData(await modelsUnload());
        setMessage("Model unloaded. Files remain on disk.");
        setProgress(null);
      } catch (err) {
        setMessage(err instanceof Error ? err.message : String(err));
      } finally {
        setPending(null);
      }
    }
  }

  const featured = data?.models ?? [];
  const more = data?.moreModels ?? [];

  return (
    <section className={`model-panel ${compact ? "compact" : ""}`}>
      <h3>On-device model</h3>

      {data === null ? <p className="hint">Checking on-device inference…</p> : null}
      {data !== null && !data.inferenceAvailable ? (
        <p className="error">
          This install cannot run GGUF inference. Rebuild the APK with{" "}
          <code>--features llama</code> to enable load and research.
        </p>
      ) : null}

      <label className={`sheet-check memory-toggle${canUseMemoryToggle ? "" : " is-disabled"}`}>
        <input
          type="checkbox"
          checked={memoryOn || loadingMemory}
          disabled={!canUseMemoryToggle || locked}
          onChange={(event) => void setMemoryLoaded(event.target.checked)}
        />
        <span>
          {loadingMemory ? "Loading model into memory…" : "Load model in memory"}
        </span>
      </label>
      {memoryTarget ? (
        <p className="hint">
          Active file: {memoryTarget.displayName}
          {data?.loadedId ? ` · in RAM: ${data.loadedId}` : ""}
        </p>
      ) : (
        <p className="hint">Download a model below, then use the toggle above.</p>
      )}

      {data?.hardware ? (
        <p className="hint">
          {data.hardware.ramLabel} RAM · {data.hardware.storageLabel} free
        </p>
      ) : null}

      {featured.length === 0 && more.length === 0 ? (
        <p className="error">No models fit this device’s free storage and RAM.</p>
      ) : null}

      <ul className="model-list">
        {featured.map((model) => (
          <ModelRow
            key={model.id}
            model={model}
            locked={locked}
            onDownload={downloadModel}
          />
        ))}
      </ul>
      {!compact && more.length > 0 ? (
        <>
          {showMore ? (
            <ul className="model-list">
              {more.map((model) => (
                <ModelRow
                  key={model.id}
                  model={model}
                  locked={locked}
                  onDownload={downloadModel}
                />
              ))}
            </ul>
          ) : (
            <button type="button" className="btn" disabled={locked} onClick={() => setShowMore(true)}>
              Show more models ({more.length})
            </button>
          )}
        </>
      ) : compact && more.length > 0 ? (
        <button type="button" className="btn linkish" disabled={locked} onClick={() => setShowMore((v) => !v)}>
          {showMore ? "Hide extra models" : `More models (${more.length})`}
        </button>
      ) : null}
      {showMore && compact ? (
        <ul className="model-list">
          {more.map((model) => (
            <ModelRow key={model.id} model={model} locked={locked} onDownload={downloadModel} />
          ))}
        </ul>
      ) : null}

      {progress && progress.phase !== "done" && progress.phase !== "error" ? (
        <p className="hint">
          {progress.message} (
          {Math.round((progress.received / Math.max(progress.total, 1)) * 100)}%)
        </p>
      ) : null}
      {message ? <p className="status">{message}</p> : null}
    </section>
  );
}
