import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { listen } from "@tauri-apps/api/event";
import {
  appModeGet,
  appModeSet,
  bookmarkAdd,
  bookmarkHas,
  bookmarkRemove,
  browserBack,
  browserForward,
  browserNavigate,
  browserReload,
  browserState,
  cleanViewStart,
  cleanViewStop,
  layoutSync,
  onBrowserState,
  onCleanViewChanged,
} from "./browser/api";
import { BookmarksPanel } from "./components/BookmarksPanel";
import { HistoryPanel } from "./components/HistoryPanel";
import { BookmarksIcon, HistoryIcon } from "./components/ToolbarIcons";
import { useBrowserWebview } from "./browser/useBrowserWebview";
import { useResearchWebview } from "./browser/useResearchWebview";
import { settingsGet } from "./browser/api";
import { ResearchPanel } from "./components/ResearchPanel";
import type { AppMode, BrowserState } from "./types/ipc";
import "./App.css";

const TOOLBAR_HEIGHT = 52;
const BOTTOM_NAV_HEIGHT = 56;

export default function App() {
  const [mode, setMode] = useState<AppMode>("browse");
  const [address, setAddress] = useState("");
  const [browser, setBrowser] = useState<BrowserState | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reportHtml, setReportHtml] = useState<string | null>(null);
  const [featureInstalled, setFeatureInstalled] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [bookmarksOpen, setBookmarksOpen] = useState(false);
  const [cleanViewActive, setCleanViewActive] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const addressEditing = useRef(false);
  const browseActive = mode === "browse";
  const sheetOpen = historyOpen || bookmarksOpen;

  const applyBrowserState = useCallback((state: BrowserState) => {
    setBrowser(state);
    if (!addressEditing.current) {
      setAddress(state.url);
    }
  }, []);
  const researchActive = mode === "research";
  const { ready: browserReady, error: webviewError, embedded: embeddedBrowse } = useBrowserWebview(
    browseActive,
    {
      toolbarHeight: TOOLBAR_HEIGHT,
      bottomNavHeight: BOTTOM_NAV_HEIGHT,
    },
  );
  const { ready: researchFetchReady, error: fetchError } = useResearchWebview(
    researchActive && featureInstalled,
  );
  const fetchReady = embeddedBrowse ? featureInstalled || researchFetchReady : researchFetchReady;

  useEffect(() => {
    void settingsGet()
      .then((s) => setFeatureInstalled(s.researchFeatureInstalled))
      .catch(() => setFeatureInstalled(false));
  }, [mode]);

  useEffect(() => {
    void appModeGet()
      .then(setMode)
      .catch(() => setMode("browse"));
  }, []);

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    void listen<AppMode>("app-mode-changed", (event) => {
      setMode(event.payload);
      setReportHtml(null);
    }).then((fn) => {
      unlisten = fn;
    });
    return () => unlisten?.();
  }, []);

  useEffect(() => {
    if (mode === "research") {
      void layoutSync({
        toolbarHeight: 0,
        bottomNavHeight: 0,
        browseOverlay: false,
      }).catch(() => undefined);
    }
  }, [mode]);

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    void onBrowserState(applyBrowserState).then((fn) => {
      unlisten = fn;
    });
    return () => unlisten?.();
  }, []);

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    void onCleanViewChanged((state) => setCleanViewActive(state.active)).then((fn) => {
      unlisten = fn;
    });
    return () => unlisten?.();
  }, [applyBrowserState]);

  useEffect(() => {
    if (!browseActive || !browser?.url) {
      setBookmarked(false);
      return;
    }
    void bookmarkHas(browser.url)
      .then(setBookmarked)
      .catch(() => setBookmarked(false));
  }, [browseActive, browser?.url]);

  useEffect(() => {
    if (!browseActive || !browserReady) return;
    const sync = () => {
      void browserState()
        .then((state) => applyBrowserState(state))
        .catch(() => undefined);
    };
    sync();
    const slow = window.setInterval(sync, 3000);
    return () => window.clearInterval(slow);
  }, [browseActive, browserReady, applyBrowserState]);

  useEffect(() => {
    if (!browseActive || !browserReady || browser?.pageReady) return;
    const sync = () => {
      void browserState()
        .then((state) => applyBrowserState(state))
        .catch(() => undefined);
    };
    sync();
    const fast = window.setInterval(sync, 400);
    return () => window.clearInterval(fast);
  }, [browseActive, browserReady, browser?.pageReady, applyBrowserState]);

  useEffect(() => {
    if (browser?.pageReady === false && cleanViewActive) {
      setCleanViewActive(false);
    }
  }, [browser?.pageReady, cleanViewActive]);

  useEffect(() => {
    const disableOverlay = () => {
      void layoutSync({
        toolbarHeight: 0,
        bottomNavHeight: 0,
        browseOverlay: false,
      }).catch(() => undefined);
    };

    if (!browseActive || !embeddedBrowse || !browserReady) {
      disableOverlay();
      return disableOverlay;
    }

    const header = document.querySelector<HTMLElement>(".toolbar");
    const bottom = document.querySelector<HTMLElement>(".bottom-nav");
    if (!header || !bottom) return;

    const pushChromeInsets = () => {
      const top = Math.ceil(header.getBoundingClientRect().height);
      const bottomPx = Math.ceil(bottom.getBoundingClientRect().height);
      if (top < 1 || bottomPx < 1) return;
      void layoutSync({
        toolbarHeight: top,
        bottomNavHeight: bottomPx,
        browseOverlay: !sheetOpen,
      }).catch(() => undefined);
    };

    pushChromeInsets();
    const observer = new ResizeObserver(pushChromeInsets);
    observer.observe(header);
    observer.observe(bottom);
    window.addEventListener("orientationchange", pushChromeInsets);
    return () => {
      observer.disconnect();
      window.removeEventListener("orientationchange", pushChromeInsets);
      disableOverlay();
    };
  }, [browseActive, embeddedBrowse, browserReady, sheetOpen]);

  const switchMode = useCallback(async (next: AppMode) => {
    setMode(next);
    setReportHtml(null);
    try {
      await appModeSet(next);
    } catch {
      /* keep UI mode */
    }
  }, []);

  async function runNav(action: () => Promise<BrowserState>) {
    setBusy(true);
    setError(null);
    try {
      const state = await action();
      setBrowser(state);
      setAddress(state.url);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  function submitAddress(event: FormEvent) {
    event.preventDefault();
    void runNav(() => browserNavigate(address));
  }

  const pageContentReady = browser?.pageReady ?? false;
  const cleanViewCanStart = pageContentReady && browserReady && !busy;
  const cleanViewCanStop = cleanViewActive && !busy;

  async function toggleCleanView() {
    if (!cleanViewActive && !pageContentReady) {
      return;
    }
    setError(null);
    try {
      const header = document.querySelector<HTMLElement>(".toolbar");
      const bottom = document.querySelector<HTMLElement>(".bottom-nav");
      if (header && bottom) {
        await layoutSync({
          toolbarHeight: Math.ceil(header.getBoundingClientRect().height),
          bottomNavHeight: Math.ceil(bottom.getBoundingClientRect().height),
          browseOverlay: true,
        }).catch(() => undefined);
      }
      if (cleanViewActive) {
        const state = await cleanViewStop();
        setCleanViewActive(state.active);
      } else {
        const state = await cleanViewStart();
        setCleanViewActive(state.active);
      }
    } catch (err) {
      setCleanViewActive(false);
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function toggleBookmark() {
    if (!browser?.url) return;
    setError(null);
    try {
      if (bookmarked) {
        await bookmarkRemove(browser.url);
        setBookmarked(false);
      } else {
        await bookmarkAdd(browser.url, browser.title);
        setBookmarked(true);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  const overlayBrowse = browseActive && embeddedBrowse && browserReady;

  return (
    <div
      className={`shell${overlayBrowse ? " browse-native-overlay" : ""}${sheetOpen ? " sheet-open" : ""}${researchActive ? " research-mode" : ""}`}
    >
      <header className="toolbar">
        {browseActive ? (
          <>
            <div className="nav-row nav-row-main">
              <button type="button" className="icon-btn" disabled={busy || !browser?.canGoBack} onClick={() => void runNav(browserBack)} title="Back" aria-label="Back">
                ←
              </button>
              <button type="button" className="icon-btn" disabled={busy || !browser?.canGoForward} onClick={() => void runNav(browserForward)} title="Forward" aria-label="Forward">
                →
              </button>
              <button type="button" className="icon-btn" disabled={busy} onClick={() => void runNav(browserReload)} title="Reload" aria-label="Reload">
                ↻
              </button>
              <span className="nav-spacer" />
              <button
                type="button"
                className={`btn tool-btn clean-view-toggle${cleanViewActive ? " is-active" : ""}`}
                disabled={!(cleanViewCanStop || cleanViewCanStart)}
                aria-pressed={cleanViewActive}
                aria-label={
                  cleanViewActive
                    ? "Stop Clean View"
                    : pageContentReady
                      ? "Clean View — tap page elements on the page to hide them"
                      : "Clean View — available after the page finishes loading"
                }
                title={
                  cleanViewActive
                    ? "Stop Clean View (tap to exit selection mode)"
                    : pageContentReady
                      ? "Clean View — tap page elements to hide them"
                      : "Clean View — wait for the page to finish loading"
                }
                onClick={() => void toggleCleanView()}
              >
                {cleanViewActive ? "Stop" : "Clean View"}
              </button>
              <button
                type="button"
                className={`icon-btn${bookmarked ? " is-active" : ""}`}
                disabled={busy || !browser?.url}
                aria-label={bookmarked ? "Remove bookmark" : "Bookmark this page"}
                title={bookmarked ? "Remove bookmark" : "Bookmark this page"}
                onClick={() => void toggleBookmark()}
              >
                {bookmarked ? "★" : "☆"}
              </button>
              <button
                type="button"
                className={`icon-btn${historyOpen ? " is-active" : ""}`}
                aria-label={historyOpen ? "Close history" : "Browsing history"}
                title={historyOpen ? "Close history" : "Browsing history"}
                onClick={() => {
                  setHistoryOpen((open) => !open);
                  setBookmarksOpen(false);
                }}
              >
                <HistoryIcon />
              </button>
              <button
                type="button"
                className={`icon-btn${bookmarksOpen ? " is-active" : ""}`}
                aria-label={bookmarksOpen ? "Close bookmarks" : "Bookmarks"}
                title={bookmarksOpen ? "Close bookmarks" : "Bookmarks"}
                onClick={() => {
                  setBookmarksOpen((open) => !open);
                  setHistoryOpen(false);
                }}
              >
                <BookmarksIcon />
              </button>
            </div>
            <form className="address-form" onSubmit={submitAddress}>
              <input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                onFocus={() => {
                  addressEditing.current = true;
                }}
                onBlur={() => {
                  addressEditing.current = false;
                }}
                placeholder="Search or enter address (? forces search)"
                spellCheck={false}
              />
              <button type="submit" className="btn" disabled={busy}>
                Go
              </button>
            </form>
            {!browserReady && !embeddedBrowse ? <p className="hint">Starting browser…</p> : null}
            {webviewError ? <p className="error">{webviewError}</p> : null}
            {error ? <p className="error">{error}</p> : null}
          </>
        ) : (
          <div className="toolbar-title">
            <strong>PicoSurf</strong> — Research
          </div>
        )}
      </header>

      <main className={`content ${browseActive ? "browse" : "research"}`}>
        {researchActive && reportHtml ? (
          <div className="research-report">
            <div className="research-report-bar">
              <button type="button" className="btn" onClick={() => setReportHtml(null)}>
                Back to research
              </button>
            </div>
            <iframe className="report-frame" title="Research report" srcDoc={reportHtml} />
          </div>
        ) : overlayBrowse ? null : browseActive ? (
          <p className="browse-placeholder">Page content appears in the browser layer below this toolbar.</p>
        ) : (
          <ResearchPanel
            fetchReady={fetchReady}
            fetchError={fetchError}
            onOpenReport={setReportHtml}
            onFeatureInstalled={() => setFeatureInstalled(true)}
          />
        )}
      </main>

      <HistoryPanel
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        onOpenUrl={(url) => void runNav(() => browserNavigate(url))}
      />
      <BookmarksPanel
        open={bookmarksOpen}
        onClose={() => setBookmarksOpen(false)}
        onOpenUrl={(url) => void runNav(() => browserNavigate(url))}
      />

      <nav className="bottom-nav">
        <button
          type="button"
          className={mode === "browse" ? "tab active" : "tab"}
          onClick={() => void switchMode("browse")}
        >
          Browse
        </button>
        <button
          type="button"
          className={mode === "research" ? "tab active" : "tab"}
          onClick={() => void switchMode("research")}
        >
          Research
        </button>
      </nav>
    </div>
  );
}
