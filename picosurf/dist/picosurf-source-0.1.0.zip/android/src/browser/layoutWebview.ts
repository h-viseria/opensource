import { LogicalPosition, LogicalSize } from "@tauri-apps/api/dpi";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { Webview } from "@tauri-apps/api/webview";

export async function layoutChildWebview(
  webview: Webview,
  toolbarHeight: number,
  bottomNavHeight: number,
): Promise<void> {
  const appWindow = getCurrentWindow();
  const factor = await appWindow.scaleFactor();
  const physical = await appWindow.innerSize();
  const width = physical.width / factor;
  const height = Math.max(120, physical.height / factor - toolbarHeight - bottomNavHeight);

  await webview.setPosition(new LogicalPosition(0, toolbarHeight));
  await webview.setSize(new LogicalSize(Math.max(160, width), height));
}
