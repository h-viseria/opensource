import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import type {
  AndroidSettings,
  AppMode,
  Bookmark,
  BrowserState,
  CleanViewState,
  HistoryVisit,
  LayoutSync,
  ModelProgress,
  ModelsListResponse,
  ModelSelectResponse,
  ResearchFeatureStatus,
  ResearchProgress,
  ResearchRunResult,
} from "../types/ipc";

export async function settingsGet(): Promise<AndroidSettings> {
  return invoke("settings_get");
}

export async function settingsSet(settings: AndroidSettings): Promise<AndroidSettings> {
  return invoke("settings_set", { settings });
}

export async function appModeGet(): Promise<AppMode> {
  return invoke("app_mode_get");
}

export async function appModeSet(mode: AppMode): Promise<AppMode> {
  return invoke("app_mode_set", { mode });
}

export async function layoutSync(layout: LayoutSync): Promise<void> {
  return invoke("layout_sync", { layout });
}

export async function browserNavigate(input: string): Promise<BrowserState> {
  return invoke("browser_navigate", { input });
}

export async function browserBack(): Promise<BrowserState> {
  return invoke("browser_back");
}

export async function browserForward(): Promise<BrowserState> {
  return invoke("browser_forward");
}

export async function browserReload(): Promise<BrowserState> {
  return invoke("browser_reload");
}

export async function browserState(): Promise<BrowserState> {
  return invoke("browser_state");
}

export async function browseUsesEmbeddedFrame(): Promise<boolean> {
  return invoke("browse_uses_embedded_frame");
}

export async function browserEnsure(): Promise<void> {
  return invoke("browser_ensure");
}

export async function omniboxResolve(input: string): Promise<string> {
  return invoke("omnibox_resolve", { input });
}

export async function researchFeatureStatus(): Promise<ResearchFeatureStatus> {
  return invoke("research_feature_status");
}

export async function researchFeatureRequestInstall(): Promise<ResearchFeatureStatus> {
  return invoke("research_feature_request_install");
}

export async function researchRun(goal: string): Promise<ResearchRunResult> {
  return invoke("research_run", { goal });
}

export async function researchStop(): Promise<void> {
  return invoke("research_stop");
}

export async function modelsList(): Promise<ModelsListResponse> {
  return invoke("models_list");
}

export async function modelsSelect(modelId: string): Promise<ModelSelectResponse> {
  return invoke("models_select", { modelId });
}

export async function modelsDownload(modelId: string): Promise<ModelsListResponse> {
  return invoke("models_download", { modelId });
}

export async function modelsLoad(modelId: string): Promise<ModelsListResponse> {
  return invoke("models_load", { modelId });
}

export async function modelsUnload(): Promise<ModelsListResponse> {
  return invoke("models_unload");
}

export async function onBrowserState(
  handler: (state: BrowserState) => void,
): Promise<() => void> {
  return listen<BrowserState>("browser-state", (event) => handler(event.payload));
}

export async function onResearchProgress(
  handler: (progress: ResearchProgress) => void,
): Promise<() => void> {
  return listen<ResearchProgress>("research-progress", (event) => handler(event.payload));
}

export async function onModelProgress(
  handler: (progress: ModelProgress) => void,
): Promise<() => void> {
  return listen<ModelProgress>("model-progress", (event) => handler(event.payload));
}

export async function historyList(query = "", limit = 50): Promise<HistoryVisit[]> {
  return invoke("history_list", { query, limit });
}

export async function historyClear(): Promise<void> {
  return invoke("history_clear");
}

export async function historyEnabledGet(): Promise<boolean> {
  return invoke("history_enabled_get");
}

export async function historyEnabledSet(enabled: boolean): Promise<boolean> {
  return invoke("history_enabled_set", { enabled });
}

export async function historyAiEnabledGet(): Promise<boolean> {
  return invoke("history_ai_enabled_get");
}

export async function historyAiEnabledSet(enabled: boolean): Promise<boolean> {
  return invoke("history_ai_enabled_set", { enabled });
}

export async function bookmarkList(): Promise<Bookmark[]> {
  return invoke("bookmark_list");
}

export async function bookmarkAdd(url?: string, title?: string): Promise<Bookmark> {
  return invoke("bookmark_add", { url: url ?? null, title: title ?? null });
}

export async function bookmarkRemove(url: string): Promise<void> {
  return invoke("bookmark_remove", { url });
}

export async function bookmarkHas(url?: string): Promise<boolean> {
  return invoke("bookmark_has", { url: url ?? null });
}

export async function cleanViewStart(): Promise<CleanViewState> {
  return invoke("clean_view_start");
}

export async function cleanViewStop(): Promise<CleanViewState> {
  return invoke("clean_view_stop");
}

export async function cleanViewStatus(): Promise<CleanViewState> {
  return invoke("clean_view_status");
}

export async function onCleanViewChanged(
  handler: (state: CleanViewState) => void,
): Promise<() => void> {
  return listen<CleanViewState>("clean-view-changed", (event) => handler(event.payload));
}
