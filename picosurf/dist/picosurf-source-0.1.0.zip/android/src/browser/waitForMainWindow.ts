import { getCurrentWindow } from "@tauri-apps/api/window";

/** Main window from getCurrentWindow() already exists; do not wait on tauri://created. */
export async function waitForMainWindow(timeoutMs = 8000): Promise<void> {
  const appWindow = getCurrentWindow();
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      await appWindow.scaleFactor();
      return;
    } catch {
      await new Promise((r) => window.setTimeout(r, 50));
    }
  }
  throw new Error("Window not ready");
}
