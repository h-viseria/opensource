import { useEffect, useRef, useState } from "react";

import { getCurrentWindow } from "@tauri-apps/api/window";

import { Webview } from "@tauri-apps/api/webview";

import { browseUsesEmbeddedFrame, browserNavigate, layoutSync } from "./api";

import { layoutChildWebview } from "./layoutWebview";

import { waitForMainWindow } from "./waitForMainWindow";

import { formatTauriError, usesEmbeddedBrowseFrame } from "./platform";



const BROWSER_LABEL = "browser";

const START_URL = "https://duckduckgo.com/";



type LayoutMetrics = {

  toolbarHeight: number;

  bottomNavHeight: number;

};



export function useBrowserWebview(enabled: boolean, layout: LayoutMetrics) {

  const webviewRef = useRef<Webview | null>(null);

  const [ready, setReady] = useState(false);

  const [error, setError] = useState<string | null>(null);

  const [embedded, setEmbedded] = useState(() => usesEmbeddedBrowseFrame());



  useEffect(() => {

    if (!enabled) {

      setReady(false);

      return;

    }



    let cancelled = false;



    void (async () => {

      try {

        await waitForMainWindow();

        if (cancelled) return;



        let useEmbedded = usesEmbeddedBrowseFrame();

        try {

          useEmbedded = useEmbedded || (await browseUsesEmbeddedFrame());

        } catch {

          /* keep heuristic */

        }

        setEmbedded(useEmbedded);



        if (useEmbedded) {
          await layoutSync({
            toolbarHeight: layout.toolbarHeight,
            bottomNavHeight: layout.bottomNavHeight,
            browseOverlay: true,
          }).catch(() => undefined);
          setReady(true);
          // Let BrowseShell.prepare finish, then load the start page without blocking UI ready.
          window.setTimeout(() => {
            void browserNavigate(START_URL).catch(() => undefined);
          }, 400);
          return;
        }



        const appWindow = getCurrentWindow();

        const webview = new Webview(appWindow, BROWSER_LABEL, {

          url: START_URL,

          x: 0,

          y: layout.toolbarHeight,

          width: 360,

          height: 600,

        });



        await new Promise<void>((resolve, reject) => {

          const timeout = window.setTimeout(() => reject(new Error("Browser webview timeout")), 12000);

          webview.once("tauri://created", () => {

            window.clearTimeout(timeout);

            resolve();

          });

          webview.once("tauri://error", (event) => {

            window.clearTimeout(timeout);

            reject(new Error(formatTauriError(event.payload)));

          });

        });



        if (cancelled) {

          await webview.close().catch(() => undefined);

          return;

        }



        webviewRef.current = webview;

        setReady(true);

        await layoutChildWebview(webview, layout.toolbarHeight, layout.bottomNavHeight);

        await layoutSync({

          toolbarHeight: layout.toolbarHeight,

          bottomNavHeight: layout.bottomNavHeight,

        }).catch(() => undefined);

      } catch (err) {

        if (!cancelled) {

          setError(err instanceof Error ? err.message : String(err));

          setReady(false);

        }

      }

    })();



    return () => {

      cancelled = true;

    };

  }, [enabled]);



  useEffect(() => {

    if (embedded || !enabled || !ready || !webviewRef.current) return;

    void layoutChildWebview(

      webviewRef.current,

      layout.toolbarHeight,

      layout.bottomNavHeight,

    ).catch(() => undefined);

    void layoutSync({

      toolbarHeight: layout.toolbarHeight,

      bottomNavHeight: layout.bottomNavHeight,

      browseOverlay: true,

    }).catch(() => undefined);

  }, [embedded, enabled, ready, layout.toolbarHeight, layout.bottomNavHeight]);



  return { ready, error, embedded };

}


