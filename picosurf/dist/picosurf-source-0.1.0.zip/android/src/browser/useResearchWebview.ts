import { useEffect, useState } from "react";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { Webview } from "@tauri-apps/api/webview";
import { waitForMainWindow } from "./waitForMainWindow";
import { formatTauriError, usesEmbeddedBrowseFrame } from "./platform";

const RESEARCH_LABEL = "research-fetch";

/** Hidden webview used only for search + page fetch during Research runs. */
export function useResearchWebview(enabled: boolean) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const embedded = usesEmbeddedBrowseFrame();

  useEffect(() => {
    if (!enabled) {
      setReady(false);
      return;
    }

    let cancelled = false;

    void (async () => {
      try {
        await waitForMainWindow();
        if (cancelled) return;

        if (embedded) {
          setError("Research page fetch webview is not available on Android yet.");
          setReady(false);
          return;
        }

        const appWindow = getCurrentWindow();
        const webview = new Webview(appWindow, RESEARCH_LABEL, {
          url: "about:blank",
          x: 0,
          y: 0,
          width: 1,
          height: 1,
        });

        await new Promise<void>((resolve, reject) => {
          const timeout = window.setTimeout(() => reject(new Error("Research webview timeout")), 12000);
          webview.once("tauri://created", () => {
            window.clearTimeout(timeout);
            resolve();
          });
          webview.once("tauri://error", (event) => {
            window.clearTimeout(timeout);
            reject(new Error(formatTauriError(event.payload)));
          });
        });

        if (!cancelled) {
          setReady(true);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : String(err));
          setReady(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [enabled, embedded]);

  return { ready, error };
}
