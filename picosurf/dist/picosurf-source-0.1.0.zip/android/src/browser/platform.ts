type TauriInternals = {
  metadata?: {
    currentPlatform?: string;
  };
};

/** Tauri Android/iOS: child webviews cannot be created from JS (desktop-only API). */
export function usesEmbeddedBrowseFrame(): boolean {
  const platform = (window as unknown as { __TAURI_INTERNALS__?: TauriInternals })
    .__TAURI_INTERNALS__?.metadata?.currentPlatform;
  if (platform === "android" || platform === "ios") {
    return true;
  }
  if (typeof navigator !== "undefined") {
    return /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  }
  return false;
}

export function formatTauriError(payload: unknown): string {
  if (payload instanceof Error) return payload.message;
  if (typeof payload === "string") return payload;
  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    if (typeof record.message === "string") return record.message;
    if (typeof record.error === "string") return record.error;
  }
  try {
    return JSON.stringify(payload);
  } catch {
    return String(payload);
  }
}
