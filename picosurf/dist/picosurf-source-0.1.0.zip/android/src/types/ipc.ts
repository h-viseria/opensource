export type AppMode = "browse" | "research";

export type BrowserState = {
  url: string;
  title: string;
  canGoBack: boolean;
  canGoForward: boolean;
  /** True when the embedded browse WebView has finished loading the current page. */
  pageReady?: boolean;
};

export type SearchSettings = {
  engine: string;
  researchEngine?: string;
  customTemplate: string;
};

export type ResearchLimits = {
  maxQueries: number;
  maxResultsPerQuery: number;
  maxPages: number;
  maxDepth: number;
  maxRuntimeSecs: number;
  maxExtractChars: number;
};

export type AndroidSettings = {
  mode: AppMode;
  search: SearchSettings;
  research: ResearchLimits;
  aiEnabled: boolean;
  historyEnabled: boolean;
  aiHistoryEnabled: boolean;
  researchFeatureInstalled: boolean;
  selectedModelId: string | null;
};

export type CleanViewState = {
  active: boolean;
};

export type HistoryVisit = {
  id: string;
  url: string;
  title: string;
  domain: string;
  visitedAt: number;
};

export type Bookmark = {
  id: string;
  url: string;
  title: string;
  domain: string;
  savedAt: number;
};

export type LayoutSync = {
  toolbarHeight: number;
  bottomNavHeight: number;
  /** When true, page-area touches go to the browse WebView under the transparent UI. */
  browseOverlay?: boolean;
};

export type ResearchFeatureStatus = {
  installed: boolean;
  playDeliveryReady: boolean;
};

export type ResearchProgress = {
  phase: string;
  detail: string;
};

export type ResearchRunResult = {
  ok: boolean;
  message: string;
  reportHtml: string | null;
  reportId: string | null;
};

export type ModelStatus = "not_downloaded" | "downloaded" | "ready";

export type ModelInfo = {
  id: string;
  displayName: string;
  family: string;
  parameterSize: string;
  quantization: string;
  sizeBytes: number;
  sizeLabel: string;
  ramHint: string;
  status: ModelStatus;
  recommended?: boolean;
  featured?: boolean;
};

export type HardwareInfo = {
  os: string;
  arch: string;
  ramBytes: number;
  ramLabel: string;
  cpuCores: number;
  storageFreeBytes: number;
  storageLabel: string;
};

export type ModelsListResponse = {
  models: ModelInfo[];
  moreModels: ModelInfo[];
  selectedId: string | null;
  downloadEnabled: boolean;
  loadedId: string | null;
  hardware: HardwareInfo;
  configPath?: string;
};

export type ModelSelectResponse = {
  selectedId: string;
  needsDownload: boolean;
  downloadEnabled: boolean;
  message: string;
};

export type ModelProgress = {
  modelId: string;
  phase: string;
  received: number;
  total: number;
  message: string;
};
