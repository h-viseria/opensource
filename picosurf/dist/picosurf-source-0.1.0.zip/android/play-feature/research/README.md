# Play Feature Delivery — `research` module

This folder holds the **dynamic feature module** skeleton for on-device research + llama runtime.

## When to wire it

After you run `npm run tauri android init -- --ci` (requires Java 17 + Android Studio), merge these files into the generated Gradle tree under `src-tauri/gen/android/`:

1. Register `:research` in `settings.gradle.kts` (`include(":research")`).
2. Set `dynamicFeatures = setOf(":research")` on the `:app` module.
3. Copy `build.gradle.kts` and `src/main/AndroidManifest.xml` from this directory into `gen/android/research/`.
4. Replace the stub `ResearchFeatureInstall.kt` hook with Play `SplitInstallManager` (on-demand module `research`).

Until then, the app uses `research_feature_request_install` in Rust as a **dev stub** (persists `researchFeatureInstalled` in settings).

See `docs/ANDROID-RESEARCH-BUILD-SPEC.md` §2.3.
