# PicoSurf Android

Separate Tauri 2 mobile app — **does not share build output with the Windows desktop** tree at the repo root.

Product scope (v1): **Browse | Research** per [docs/ANDROID-RESEARCH-BUILD-SPEC.md](../../docs/ANDROID-RESEARCH-BUILD-SPEC.md).

## Layout

| Path | Role |
|------|------|
| `src/` | React shell (toolbar, bottom nav, Research UI) |
| `src-tauri/` | Rust commands, settings, browse history |
| `play-feature/research/` | Gradle skeleton for Play Feature Delivery (merge after `android init`) |

## Prerequisites

- Node.js 20+
- Rust stable + `rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android`
- **Java 17** (Android Studio or JDK)
- Android SDK / NDK via Android Studio

## First-time Android setup

```powershell
cd apps\picosurf-android
npm install
npm run tauri android init -- --ci
```

If `android init` fails with “Java not found”, install Android Studio and set `JAVA_HOME` to its JBR (e.g. `C:\Program Files\Android\Android Studio\jbr`).

## Develop

```powershell
cd apps\picosurf-android
npm run tauri android dev
```

Desktop-only smoke test (Rust + Vite, no device):

```powershell
npm run dev
npm run tauri dev
```

## Build release APK / AAB

```powershell
npm run tauri android build -- --apk --ci
# or
npm run tauri android build -- --aab --ci
```

APK output (when the build finishes):  
`src-tauri\gen\android\app\build\outputs\apk\universal\release\app-universal-release.apk`

### Windows without Developer Mode / admin

Android builds still run **on your Windows PC**. Tauri tries to **symlink** compiled `.so` files into `jniLibs/`; that step needs Developer Mode or admin. You do **not** need either if you use the copy-based flow:

```powershell
cd apps\picosurf-android
npm run android:build-apk
```

That script builds the web UI, runs `tauri android build` (Rust + assets; **ignore** the symlink error at the end), copies libs into `jniLibs`, then runs Gradle with Rust tasks skipped so nothing tries to symlink again.

Output (arm64, most phones):

`src-tauri\gen\android\app\build\outputs\apk\arm64\release\app-arm64-release-unsigned.apk`

Release APKs are **unsigned** until you configure a release keystore. For local install / emulator, either **sign with the debug key** or build **debug**:

```powershell
npm run android:sign-apk -- "src-tauri\gen\android\app\build\outputs\apk\arm64\release\app-arm64-release-unsigned.apk"
# then adb install the *-signed.apk

npm run android:sync-jni -- -Profile debug   # if you only built release .so so far, rebuild debug Rust or use sign path above
npm run android:assemble-apk-debug           # app-arm64-debug.apk (already signed)
```

**Already compiled Rust** and only need to package:

```powershell
npm run android:sync-jni
npm run android:assemble-apk
```

If IT can enable it: **Settings → Privacy & security → For developers → Developer Mode** lets `npm run tauri android build -- --apk --ci` work in one step.

### Gradle: Java 25 / `Unsupported class file major version 69`

Recent **Android Studio JBR is Java 25**, which Gradle cannot use yet. You need **JDK 17 or 21** for `gradlew` (Studio is still fine for the SDK).

This machine often has Microsoft OpenJDK 17 at  
`C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot` — the assemble scripts search for it automatically.

Or set once per terminal:

```powershell
$env:JAVA_HOME = "C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot"
npm run android:assemble-apk
```

Persistent override: copy `java.home.local.example` to `java.home.local` with your JDK path.

### Browse on Android

Wry allows only **one** Tauri webview per activity. PicoSurf keeps that webview for the React toolbar and adds a separate **content** `WebView` behind it (`BrowseShell`) for full-page browsing (Chrome-style, no iframe, no “Open in browser”).

## Current implementation status

- **Browse:** desktop child webview; **Android** dual-layer shell (transparent UI + content webview); **iOS** overlay/iframe path until a similar shell exists.
- **Research:** hidden WebView `research-fetch`, plan → search → visit → synthesize pipeline, HTML reports on disk + in-app viewer.
- **Models:** catalogue, HTTPS download + SHA-256 verify, load into inference engine.
- **Llama:** optional Cargo feature `llama` (requires CMake on Windows dev hosts). Default build uses a stub engine for UI/dev without native inference.
- **Play Feature Delivery:** Gradle templates in `play-feature/research/`; Rust install flag is a dev stand-in until SplitInstall is merged after `android init`.

### Build with inference (desktop smoke test or release)

```powershell
cd apps\picosurf-android\src-tauri
cargo check --features llama
```

Android device build (after `android init`):

```powershell
cd apps\picosurf-android
npm run tauri android build -- --aab -- --features llama
```

Desktop PicoSurf at the repo root is unchanged.
