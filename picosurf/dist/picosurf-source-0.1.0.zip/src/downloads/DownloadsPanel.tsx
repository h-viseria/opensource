import { useEffect, useState } from "react";
import { downloadsClear, downloadsList, onDownloadLogUpdated } from "../browser/api";
import { isTauri } from "../browser/tauriEnv";
import type { DownloadRecord } from "../types/ipc";

type DownloadsPanelProps = {
  open: boolean;
  onClose: () => void;
  onOpenUrl: (url: string) => void;
};

export function DownloadsPanel({ open, onClose, onOpenUrl }: DownloadsPanelProps) {
  const [entries, setEntries] = useState<DownloadRecord[]>([]);
  const [message, setMessage] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearing, setClearing] = useState(false);

  useEffect(() => {
    if (!open || !isTauri()) return;
    void loadEntries();
  }, [open]);

  useEffect(() => {
    if (!open || !isTauri()) return;
    let unlisten: (() => void) | undefined;
    void onDownloadLogUpdated(() => {
      void loadEntries();
    }).then((fn) => {
      unlisten = fn;
    });
    return () => {
      unlisten?.();
    };
  }, [open]);

  async function loadEntries() {
    if (!isTauri()) {
      setEntries([]);
      return;
    }
    try {
      setEntries(await downloadsList(80));
      setMessage("");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function clearAll() {
    if (!isTauri() || clearing) return;
    setClearing(true);
    setMessage("");
    try {
      await downloadsClear();
      setEntries([]);
      setConfirmClear(false);
      setMessage("Download list cleared. Files remain in your Downloads folder.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
      await loadEntries();
    } finally {
      setClearing(false);
    }
  }

  return (
    <aside
      className={`downloads-panel${open ? " is-open" : ""}`}
      aria-hidden={!open}
      inert={!open}
      aria-label="Downloads"
    >
      <header className="ai-header">
        <div>
          <h1>Downloads</h1>
          <p>Files save to your Windows Downloads folder.</p>
        </div>
        <button type="button" className="btn ghost" onClick={onClose}>
          Hide
        </button>
      </header>
      <p className="inspect-meta history-note">
        This list is stored locally. Websites cannot read it.
      </p>
      {message ? <p className="inspect-meta">{message}</p> : null}
      <div className="history-list" aria-live="polite">
        {entries.length === 0 ? (
          <p className="inspect-meta">No downloads yet.</p>
        ) : (
          <ul>
            {entries.map((entry) => (
              <li key={entry.id} className="history-item">
                <span className="download-file">{entry.fileName}</span>
                <button
                  type="button"
                  className="history-link download-source"
                  onClick={() => onOpenUrl(entry.sourceUrl)}
                >
                  {entry.domain || entry.sourceUrl}
                </button>
                <span className="history-meta">{formatWhen(entry.downloadedAt)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
      <footer className="history-footer">
        {confirmClear ? (
          <div className="panel-confirm" role="group" aria-label="Confirm clear download list">
            <p>Clear PicoSurf&apos;s download list?</p>
            <div className="model-confirm-actions">
              <button
                type="button"
                className="btn ghost"
                disabled={clearing}
                onClick={() => setConfirmClear(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn primary"
                disabled={clearing}
                onClick={() => void clearAll()}
              >
                {clearing ? "Clearing…" : "Yes, clear"}
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            className="btn ghost"
            onClick={() => setConfirmClear(true)}
            disabled={entries.length === 0}
          >
            Clear list
          </button>
        )}
      </footer>
    </aside>
  );
}

function formatWhen(unixSeconds: number): string {
  if (!unixSeconds) return "unknown time";
  try {
    return new Date(unixSeconds * 1000).toLocaleString();
  } catch {
    return "unknown time";
  }
}
