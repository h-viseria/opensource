import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import type {
  ActionResult,
  AgentConfirm,
  AgentLimits,
  AgentOutcome,
  AiStatus,
  BrowserState,
  CleanViewState,
  ChatTurn,
  GenerateResult,
  InspectResult,
  LayoutSync,
  ModelProgress,
  ModelSelectResponse,
  ModelsListResponse,
  OmniboxDecision,
  PageInfo,
  SavedPage,
  ScreenshotResult,
  ScrollDirection,
  AppSettings,
  AdBlockStatus,
  AssistantMode,
  AgentFlow,
  AgentFlowSummary,
  HistoryVisit,
  DownloadRecord,
} from "../types/ipc";

export async function browserNavigate(url: string): Promise<BrowserState> {
  return invoke("browser_navigate", { url });
}

export async function browserBack(): Promise<BrowserState> {
  return invoke("browser_back");
}

export async function browserForward(): Promise<BrowserState> {
  return invoke("browser_forward");
}

export async function browserReload(): Promise<BrowserState> {
  return invoke("browser_reload");
}

export async function browserState(): Promise<BrowserState> {
  return invoke("browser_state");
}

export async function layoutSync(layout: LayoutSync): Promise<void> {
  return invoke("layout_sync", { layout });
}

export async function modelsList(): Promise<ModelsListResponse> {
  return invoke("models_list");
}

export async function modelsSelect(modelId: string): Promise<ModelSelectResponse> {
  return invoke("models_select", { modelId });
}

export async function modelsDownload(modelId: string): Promise<ModelsListResponse> {
  return invoke("models_download", { modelId });
}

export async function modelsCancel(): Promise<void> {
  return invoke("models_cancel");
}

export async function modelsLoad(modelId: string): Promise<ModelsListResponse> {
  return invoke("models_load", { modelId });
}

export async function modelsUnload(): Promise<ModelsListResponse> {
  return invoke("models_unload");
}

export async function aiGenerate(
  messages: ChatTurn[],
  attachPage = false,
): Promise<GenerateResult> {
  return invoke("ai_generate", { messages, attachPage });
}

export async function aiTask(goal: string): Promise<AgentOutcome> {
  return invoke("ai_task", { goal });
}

export async function aiConfirm(): Promise<AgentOutcome> {
  return invoke("ai_confirm");
}

export async function aiStop(): Promise<void> {
  return invoke("ai_stop");
}

export async function agentLimitsGet(): Promise<AgentLimits> {
  return invoke("agent_limits_get");
}

export async function agentLimitsSet(limits: AgentLimits): Promise<AgentLimits> {
  return invoke("agent_limits_set", { limits });
}

export async function settingsGet(): Promise<AppSettings> {
  return invoke("settings_get");
}

export async function settingsSet(settings: AppSettings): Promise<AppSettings> {
  return invoke("settings_set", { settings });
}

export async function adBlockStatus(): Promise<AdBlockStatus> {
  return invoke("ad_block_status");
}

export async function adBlockRefresh(): Promise<
  Pick<AdBlockStatus, "ruleHosts" | "updatedAt" | "sources">
> {
  return invoke("ad_block_refresh");
}

export async function assistantModeGet(): Promise<AssistantMode> {
  return invoke("assistant_mode_get");
}

export async function assistantModeSet(
  mode: AssistantMode,
  customFlowId?: string | null,
): Promise<AssistantMode> {
  return invoke("assistant_mode_set", { mode, customFlowId: customFlowId ?? null });
}

export async function agentFlowsList(): Promise<AgentFlowSummary[]> {
  return invoke("agent_flows_list");
}

export async function agentFlowsGet(id: string): Promise<AgentFlow | null> {
  return invoke("agent_flows_get", { id });
}

export async function agentFlowsSave(flow: AgentFlow): Promise<AgentFlow> {
  return invoke("agent_flows_save", { flow });
}

export async function agentFlowsDelete(id: string): Promise<void> {
  return invoke("agent_flows_delete", { id });
}

export async function historyList(query = "", limit = 50): Promise<HistoryVisit[]> {
  return invoke("history_list", { query, limit });
}

export async function historyClear(): Promise<void> {
  return invoke("history_clear");
}

export async function historyEnabledGet(): Promise<boolean> {
  return invoke("history_enabled_get");
}

export async function historyEnabledSet(enabled: boolean): Promise<boolean> {
  return invoke("history_enabled_set", { enabled });
}

export async function historyAiEnabledGet(): Promise<boolean> {
  return invoke("history_ai_enabled_get");
}

export async function historyAiEnabledSet(enabled: boolean): Promise<boolean> {
  return invoke("history_ai_enabled_set", { enabled });
}

export async function downloadsList(limit = 50): Promise<DownloadRecord[]> {
  return invoke("downloads_list", { limit });
}

export async function downloadsClear(): Promise<void> {
  return invoke("downloads_clear");
}

export async function omniboxInterpret(input: string): Promise<OmniboxDecision> {
  return invoke("omnibox_interpret", { input });
}

export async function savedList(): Promise<SavedPage[]> {
  return invoke("saved_list");
}

export async function savedSearch(query: string): Promise<SavedPage[]> {
  return invoke("saved_search", { query });
}

export async function saveWithAi(): Promise<AgentOutcome> {
  return invoke("save_with_ai");
}

export function onModelProgress(handler: (progress: ModelProgress) => void) {
  return listen<ModelProgress>("model-progress", (event) => handler(event.payload));
}

export function onAiToken(handler: (text: string) => void) {
  return listen<{ text: string }>("ai-token", (event) => handler(event.payload.text));
}

export function onAiStatus(handler: (status: AiStatus) => void) {
  return listen<AiStatus>("ai-status", (event) => handler(event.payload));
}

export function onAiConfirm(handler: (confirm: AgentConfirm) => void) {
  return listen<AgentConfirm>("ai-confirm", (event) => handler(event.payload));
}

export function onBrowserState(handler: (state: BrowserState) => void) {
  return listen<BrowserState>("browser-state", (event) => handler(event.payload));
}

export function onDownloadLogUpdated(handler: () => void) {
  return listen("download-log-updated", () => handler());
}

export async function browserInspect(): Promise<InspectResult> {
  return invoke("browser_inspect");
}

export async function browserPageInfo(): Promise<PageInfo> {
  return invoke("browser_page_info");
}

export async function browserClick(
  elementId: number,
  generation: number,
  confirmed = false,
): Promise<ActionResult> {
  return invoke("browser_click", { elementId, generation, confirmed });
}

export async function browserType(
  elementId: number,
  generation: number,
  text: string,
): Promise<ActionResult> {
  return invoke("browser_type", { elementId, generation, text });
}

export async function browserScroll(direction: ScrollDirection): Promise<ActionResult> {
  return invoke("browser_scroll", { direction });
}

export async function browserScreenshot(): Promise<ScreenshotResult> {
  return invoke("browser_screenshot");
}

export async function cleanViewStart(): Promise<CleanViewState> {
  return invoke("clean_view_start");
}

export async function cleanViewStop(): Promise<CleanViewState> {
  return invoke("clean_view_stop");
}

export async function cleanViewStatus(): Promise<CleanViewState> {
  return invoke("clean_view_status");
}

export function onCleanViewChanged(handler: (state: CleanViewState) => void) {
  return listen<CleanViewState>("clean-view-changed", (event) => handler(event.payload));
}
