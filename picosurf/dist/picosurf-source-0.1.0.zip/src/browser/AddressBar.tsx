import { FormEvent, useEffect, useState } from "react";
import { AssistantModeSelect } from "../components/AssistantModeSelect";
import type { AgentFlowSummary, AssistantMode } from "../types/ipc";

type AddressBarProps = {
  url: string;
  disabled?: boolean;
  assistantMode: AssistantMode;
  customFlowId: string | null;
  customFlows: AgentFlowSummary[];
  onAssistantModeChange: (mode: AssistantMode, customFlowId?: string | null) => void;
  onSubmit: (value: string) => void;
};

export function AddressBar({
  url,
  disabled,
  assistantMode,
  customFlowId,
  customFlows,
  onAssistantModeChange,
  onSubmit,
}: AddressBarProps) {
  const [value, setValue] = useState(url);

  useEffect(() => {
    setValue(url);
  }, [url]);

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const next = value.trim();
    if (!next) return;
    onSubmit(next);
  }

  return (
    <form className="address-form" onSubmit={handleSubmit}>
      <AssistantModeSelect
        compact
        value={assistantMode}
        customFlowId={customFlowId}
        customFlows={customFlows}
        disabled={disabled}
        onChange={onAssistantModeChange}
      />
      <input
        className="address-input"
        value={value}
        disabled={disabled}
        spellCheck={false}
        autoCorrect="off"
        autoCapitalize="off"
        placeholder="Search, enter address, or ask the assistant — ? forces web search"
        aria-label="Address bar"
        onChange={(event) => setValue(event.target.value)}
        onFocus={(event) => event.currentTarget.select()}
      />
    </form>
  );
}
