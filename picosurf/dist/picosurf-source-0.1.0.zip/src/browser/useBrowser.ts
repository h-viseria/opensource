import { useCallback, useEffect, useState } from "react";
import {
  browserBack,
  browserForward,
  browserNavigate,
  browserReload,
  browserState,
  onBrowserState,
} from "./api";
import { isTauri } from "./tauriEnv";
import type { BrowserState } from "../types/ipc";

const EMPTY: BrowserState = {
  url: "",
  title: "",
  canGoBack: false,
  canGoForward: false,
};

export function useBrowser() {
  const [state, setState] = useState<BrowserState>(EMPTY);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isTauri()) return;
    let unlisten: (() => void) | undefined;
    browserState()
      .then(setState)
      .catch(() => undefined);
    onBrowserState(setState).then((fn) => {
      unlisten = fn;
    });
    return () => {
      unlisten?.();
    };
  }, []);

  const run = useCallback(async (op: () => Promise<BrowserState>) => {
    setBusy(true);
    setError(null);
    try {
      setState(await op());
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }, []);

  return {
    state,
    error,
    busy,
    navigate: (url: string) => run(() => browserNavigate(url)),
    back: () => run(browserBack),
    forward: () => run(browserForward),
    reload: () => run(browserReload),
  };
}
