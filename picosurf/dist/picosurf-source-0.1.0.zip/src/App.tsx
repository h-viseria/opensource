import { useCallback, useEffect, useRef, useState } from "react";
import { AddressBar } from "./browser/AddressBar";
import {
  agentFlowsList,
  assistantModeSet,
  cleanViewStart,
  settingsGet,
  cleanViewStatus,
  cleanViewStop,
  layoutSync,
  omniboxInterpret,
  onCleanViewChanged,
} from "./browser/api";
import { isTauri } from "./browser/tauriEnv";
import { useBrowser } from "./browser/useBrowser";
import { IconButton } from "./components/IconButton";
import { AiPanel, type PendingAi } from "./ai/AiPanel";
import { DevToolsPanel } from "./ai/DevTools";
import { HelpPanel } from "./ai/HelpPanel";
import { HistoryPanel } from "./history/HistoryPanel";
import { DownloadsPanel } from "./downloads/DownloadsPanel";
import { PrivacyPanel } from "./pages/Privacy";
import type { AgentFlowSummary, AssistantMode } from "./types/ipc";

const SIDEBAR_WIDTH = 360;
const DEFAULT_ASSISTANT_MODE: AssistantMode = "research";

export default function App() {
  const chromeRef = useRef<HTMLDivElement>(null);
  const toolbarRef = useRef<HTMLElement>(null);
  const { state, error, busy, navigate, back, forward, reload } = useBrowser();
  const [aiOpen, setAiOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [downloadsOpen, setDownloadsOpen] = useState(false);
  const [devOpen, setDevOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [pendingAi, setPendingAi] = useState<PendingAi | null>(null);
  const [assistantMode, setAssistantMode] = useState<AssistantMode>(DEFAULT_ASSISTANT_MODE);
  const [customFlowId, setCustomFlowId] = useState<string | null>(null);
  const [customFlows, setCustomFlows] = useState<AgentFlowSummary[]>([]);
  const [cleanViewActive, setCleanViewActive] = useState(false);
  const sidebarOpen = aiOpen || devOpen || helpOpen || historyOpen || downloadsOpen;

  useEffect(() => {
    if (!isTauri()) return;
    void settingsGet()
      .then((settings) => {
        setAssistantMode(settings.assistantMode);
        setCustomFlowId(settings.customFlowId);
      })
      .catch(() => {
        setAssistantMode(DEFAULT_ASSISTANT_MODE);
        setCustomFlowId(null);
      });
    void agentFlowsList()
      .then(setCustomFlows)
      .catch(() => setCustomFlows([]));
  }, [devOpen]);

  useEffect(() => {
    if (!isTauri()) return;
    let unlisten: (() => void) | undefined;
    void onCleanViewChanged((state) => setCleanViewActive(state.active)).then((fn) => {
      unlisten = fn;
    });
    return () => {
      unlisten?.();
    };
  }, []);

  useEffect(() => {
    if (!isTauri() || !cleanViewActive) return;
    const interval = window.setInterval(() => {
      void cleanViewStatus()
        .then((state) => setCleanViewActive(state.active))
        .catch(() => setCleanViewActive(false));
    }, 400);
    return () => window.clearInterval(interval);
  }, [cleanViewActive]);

  const handleAssistantModeChange = useCallback(
    (mode: AssistantMode, flowId?: string | null) => {
      setAssistantMode(mode);
      setCustomFlowId(flowId ?? null);
      if (!isTauri()) return;
      void assistantModeSet(mode, flowId ?? null).catch(() => {
        void settingsGet().then((settings) => {
          setAssistantMode(settings.assistantMode);
          setCustomFlowId(settings.customFlowId);
        });
      });
    },
    [],
  );

  const syncLayout = useCallback(() => {
    if (!isTauri()) return;
    const toolbarHeight = toolbarRef.current?.getBoundingClientRect().height ?? 52;
    void layoutSync({
      toolbarHeight,
      sidebarWidth: SIDEBAR_WIDTH,
      sidebarOpen,
    });
  }, [sidebarOpen]);

  useEffect(() => {
    syncLayout();
    const frame = chromeRef.current;
    if (!frame) return;
    const observer = new ResizeObserver(() => syncLayout());
    observer.observe(frame);
    window.addEventListener("resize", syncLayout);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", syncLayout);
    };
  }, [syncLayout]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.altKey && event.key === "ArrowLeft") {
        event.preventDefault();
        void back();
      } else if (event.altKey && event.key === "ArrowRight") {
        event.preventDefault();
        void forward();
      } else if (event.key === "F5") {
        event.preventDefault();
        void reload();
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "l") {
        event.preventDefault();
        document.querySelector<HTMLInputElement>(".address-input")?.focus();
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "r") {
        event.preventDefault();
        void reload();
      } else if (event.key === "Escape" && cleanViewActive) {
        event.preventDefault();
        void cleanViewStop().then((state) => setCleanViewActive(state.active));
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [back, forward, reload, cleanViewActive]);

  async function toggleCleanView() {
    if (!isTauri()) return;
    try {
      if (cleanViewActive) {
        const state = await cleanViewStop();
        setCleanViewActive(state.active);
        return;
      }
      const state = await cleanViewStart();
      setCleanViewActive(state.active);
    } catch {
      setCleanViewActive(false);
    }
  }

  async function handleOmnibox(value: string) {
    const trimmed = value.trim();
    if (!trimmed) return;
    if (!isTauri()) {
      void navigate(trimmed);
      return;
    }
    try {
      const decision = await omniboxInterpret(trimmed);
      if (decision.kind === "navigate" || decision.kind === "search") {
        void navigate(decision.value);
        return;
      }
      setDevOpen(false);
      setHelpOpen(false);
      setHistoryOpen(false);
      setDownloadsOpen(false);
      setAiOpen(true);
      setPendingAi({
        id: Date.now(),
        text: decision.value,
        mode: decision.kind === "summarize" ? "chat" : "task",
      });
    } catch {
      void navigate(trimmed);
    }
  }

  return (
    <div ref={chromeRef} className={`chrome${sidebarOpen ? " sidebar-open" : ""}`}>
      <header ref={toolbarRef} className="toolbar">
        <div className="nav-cluster">
          <IconButton label="Back" disabled={!state.canGoBack || busy} onClick={() => void back()}>
            <BackIcon />
          </IconButton>
          <IconButton
            label="Forward"
            disabled={!state.canGoForward || busy}
            onClick={() => void forward()}
          >
            <ForwardIcon />
          </IconButton>
          <IconButton label="Reload" disabled={busy} onClick={() => void reload()}>
            <ReloadIcon />
          </IconButton>
        </div>
        <AddressBar
          url={state.url}
          disabled={busy}
          assistantMode={assistantMode}
          customFlowId={customFlowId}
          customFlows={customFlows}
          onAssistantModeChange={handleAssistantModeChange}
          onSubmit={(value) => void handleOmnibox(value)}
        />
        <button
          type="button"
          className={`ai-toggle clean-view-toggle${cleanViewActive ? " is-active" : ""}`}
          aria-pressed={cleanViewActive}
          aria-label={
            cleanViewActive
              ? "Exit Clean View selection mode"
              : "Enter Clean View to hide page elements"
          }
          title={
            cleanViewActive
              ? "Clean View on — click page elements to hide, Esc to exit"
              : "Clean View — select and hide page elements"
          }
          disabled={busy || !isTauri()}
          onClick={() => void toggleCleanView()}
        >
          <CleanViewIcon />
          Clean View
        </button>
        <button
          type="button"
          className={`ai-toggle${historyOpen ? " is-active" : ""}`}
          aria-pressed={historyOpen}
          aria-label={historyOpen ? "Hide history" : "Open history"}
          onClick={() => {
            setHistoryOpen((open) => !open);
            setAiOpen(false);
            setDevOpen(false);
            setHelpOpen(false);
            setDownloadsOpen(false);
          }}
        >
          <HistoryIcon />
          History
        </button>
        <button
          type="button"
          className={`ai-toggle${downloadsOpen ? " is-active" : ""}`}
          aria-pressed={downloadsOpen}
          aria-label={downloadsOpen ? "Hide downloads" : "Open downloads"}
          onClick={() => {
            setDownloadsOpen((open) => !open);
            setAiOpen(false);
            setDevOpen(false);
            setHelpOpen(false);
            setHistoryOpen(false);
          }}
        >
          <DownloadIcon />
          Downloads
        </button>
        <button
          type="button"
          className={`ai-toggle${aiOpen ? " is-active" : ""}`}
          aria-pressed={aiOpen}
          aria-label={aiOpen ? "Hide assistant" : "Open assistant"}
          onClick={() => {
            setAiOpen((open) => !open);
            setDevOpen(false);
            setHelpOpen(false);
            setHistoryOpen(false);
            setDownloadsOpen(false);
          }}
        >
          <SparkIcon />
          AI
        </button>
        <button
          type="button"
          className={`ai-toggle${devOpen ? " is-active" : ""}`}
          aria-pressed={devOpen}
          aria-label={devOpen ? "Hide developer tools" : "Open developer tools"}
          title="DevTools"
          onClick={() => {
            setDevOpen((open) => !open);
            setAiOpen(false);
            setHelpOpen(false);
            setHistoryOpen(false);
            setDownloadsOpen(false);
          }}
        >
          <DevIcon />
        </button>
        <button
          type="button"
          className={`ai-toggle${helpOpen ? " is-active" : ""}`}
          aria-pressed={helpOpen}
          aria-label={helpOpen ? "Hide help" : "Open help"}
          onClick={() => {
            setHelpOpen((open) => !open);
            setAiOpen(false);
            setDevOpen(false);
            setHistoryOpen(false);
            setDownloadsOpen(false);
          }}
        >
          <HelpIcon />
          Help
        </button>
      </header>
      <div className="workspace">
        <div className="page-slot" aria-hidden="true">
          {error ? <p className="page-error">{error}</p> : null}
          {state.title ? <span className="sr-only">{state.title}</span> : null}
          {!isTauri() ? (
            <p className="page-preview">Website pages render here in the Windows app via WebView2.</p>
          ) : null}
        </div>
        <AiPanel
          open={aiOpen}
          onClose={() => setAiOpen(false)}
          onOpenPrivacy={() => setPrivacyOpen(true)}
          onOpenUrl={(url) => void navigate(url)}
          pending={pendingAi}
          onPendingConsumed={() => setPendingAi(null)}
          assistantMode={assistantMode}
          customFlowId={customFlowId}
          customFlows={customFlows}
          onAssistantModeChange={handleAssistantModeChange}
        />
        <DevToolsPanel open={devOpen} onClose={() => setDevOpen(false)} />
        <HelpPanel open={helpOpen} onClose={() => setHelpOpen(false)} />
        <HistoryPanel
          open={historyOpen}
          onClose={() => setHistoryOpen(false)}
          onOpenUrl={(url) => void navigate(url)}
        />
        <DownloadsPanel
          open={downloadsOpen}
          onClose={() => setDownloadsOpen(false)}
          onOpenUrl={(url) => void navigate(url)}
        />
      </div>
      <PrivacyPanel open={privacyOpen} onClose={() => setPrivacyOpen(false)} />
    </div>
  );
}

function BackIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M10.2 3.2 5.4 8l4.8 4.8"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ForwardIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M5.8 3.2 10.6 8 5.8 12.8"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ReloadIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M13 8a5 5 0 1 1-1.4-3.5M13 3.2V6H10.2"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function HistoryIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M8 2.5a5.5 5.5 0 1 1 0 11A5.5 5.5 0 0 1 8 2.5Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
      />
      <path
        d="M8 5v3.2l2.2 1.3"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M8 2.5v7M8 9.5 5.8 7.3M8 9.5l2.2-2.2"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.5 12.5h9"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

function SparkIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M8 1.6 9.1 6l4.5.3L10 9.2l1.2 4.4L8 11.2 4.8 13.6 6 9.2 2.4 6.3 6.9 6z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function DevIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M5.5 4.5 3 8l2.5 3.5M10.5 4.5 13 8l-2.5 3.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M9.4 3.8 6.6 12.2"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

function HelpIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <circle cx="8" cy="8" r="5.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="M6.2 6.1c.2-1 1-1.6 1.9-1.6 1.1 0 2 .7 2 1.7 0 1.3-1.4 1.5-1.8 2.3-.1.2-.1.4-.1.6"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <circle cx="8" cy="11.2" r="0.55" fill="currentColor" />
    </svg>
  );
}

function CleanViewIcon() {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="M2.5 4.5h11M5 8h6M7 11.5h2"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
      <rect
        x="2"
        y="2.5"
        width="12"
        height="11"
        rx="1.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.2"
      />
    </svg>
  );
}
