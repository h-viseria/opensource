type PrivacyPanelProps = {
  open: boolean;
  onClose: () => void;
};

export function PrivacyPanel({ open, onClose }: PrivacyPanelProps) {
  if (!open) return null;

  return (
    <div className="modal-backdrop" role="presentation" onClick={onClose}>
      <article
        className="modal privacy"
        role="dialog"
        aria-modal="true"
        aria-labelledby="privacy-title"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 id="privacy-title">Privacy</h2>
        <p>
          PicoSurf is a local browser. Pages load in an isolated WebView. The toolbar and
          assistant UI cannot be scripted by those pages.
        </p>
        <ul>
          <li>No account and no cloud AI in this app.</li>
          <li>No telemetry or analytics in this build.</li>
          <li>The assistant stays closed until you open it.</li>
          <li>Models download only after you confirm, are checksummed, and stay on this device.</li>
          <li>
            If you include the current page, PicoSurf copies visible text in Rust and sends it only
            to the local model as untrusted data. It is not uploaded and is not mixed into system
            instructions.
          </li>
          <li>
            Page actions are optional. The model may propose one inspect, click, type, scroll, or
            navigate step at a time. Purchases, form submit, sign-in, password fields, and checkout
            URLs wait for your confirmation. There are no silent purchases.
          </li>
          <li>
            A task uses the DevTools action / navigation / time limits (defaults: 8, 3, 90s). You
            can Cancel a stuck task. The model cannot run JavaScript, read your disk, or skip
            confirmation. If you ask to open a URL, PicoSurf puts it in the address bar and loads
            that page first.
          </li>
          <li>
            <strong>Research</strong> mode uses the same browser WebView as you do. PicoSurf opens
            the configured search engine, reads results locally, then summarizes with the on-device
            model. There is no search API and no cloud AI. Answers only cite pages that were
            actually opened.
          </li>
          <li>
            <strong>Agent</strong> mode runs the same page-action loop from the address bar or AI
            panel: each step sends sanitized element lists and page text to the local model only.
            Screenshots are optional actions saved on disk; pixels are not sent to the model by
            default. Pick Agent when you want multi-step browse tasks instead of a research report.
          </li>
          <li>
            Prefix the address bar with ? or search: to force a normal web search without AI routing.
          </li>
          <li>
            Save with AI stores the current URL, title, and a local summary on this device. “What
            did I save about …” searches that list only. Nothing is uploaded.
          </li>
        </ul>
        <div className="modal-actions">
          <button type="button" className="btn primary" onClick={onClose}>
            Close
          </button>
        </div>
      </article>
    </div>
  );
}
