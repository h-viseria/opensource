export type BrowserState = {
  url: string;
  title: string;
  canGoBack: boolean;
  canGoForward: boolean;
};

export type CleanViewState = {
  active: boolean;
};

export type LayoutSync = {
  toolbarHeight: number;
  sidebarWidth: number;
  sidebarOpen: boolean;
};

export type ModelStatus = "not_downloaded" | "downloaded" | "ready";

export type ModelInfo = {
  id: string;
  displayName: string;
  family: string;
  parameterSize: string;
  quantization: string;
  sizeBytes: number;
  sizeLabel: string;
  ramHint: string;
  status: ModelStatus;
  recommended?: boolean;
  featured?: boolean;
};

export type ModelsListResponse = {
  models: ModelInfo[];
  moreModels: ModelInfo[];
  selectedId: string | null;
  downloadEnabled: boolean;
  loadedId: string | null;
  hardware?: HardwareInfo;
  configPath?: string | null;
};

export type HardwareInfo = {
  os: string;
  arch: string;
  ramBytes: number;
  ramLabel: string;
  cpuCores: number;
  storageFreeBytes: number;
  storageLabel: string;
};

export type ModelSelectResponse = {
  selectedId: string;
  needsDownload: boolean;
  downloadEnabled: boolean;
  message: string;
};

export type ModelProgress = {
  modelId: string;
  phase: string;
  received: number;
  total: number;
  message: string;
};

export type ChatTurn = {
  role: "user" | "assistant" | "system";
  content: string;
};

export type GenerateResult = {
  text: string;
  stopped: boolean;
  message: string;
  usedPage?: boolean;
  pageOrigin?: string;
};

export type AiStatus = {
  phase: "reading_page" | "generating" | "acting" | "needs_confirmation" | "done" | string;
  message: string;
};

export type AgentOutcome = {
  status: string;
  message: string;
  activity: string[];
  sources?: CitedSource[];
  viewUrl?: string;
  viewKind?: string;
};

export type CitedSource = {
  url: string;
  title: string;
  domain: string;
};

export type AgentConfirm = {
  action: string;
  message: string;
  elementLabel: string;
};

export type AgentLimits = {
  maxActions: number;
  maxNavigations: number;
  maxRuntimeSecs: number;
};

export type SearchSettings = {
  engine: string;
  researchEngine: string;
  customTemplate: string;
};

export type ResearchLimits = {
  maxQueries: number;
  maxResultsPerQuery: number;
  maxPages: number;
  maxDepth: number;
  maxRuntimeSecs: number;
  maxExtractChars: number;
};

export type AssistantMode = "research" | "agent" | "auto" | "custom";

export type AgentStructureLevel = "off" | "minimal" | "standard" | "detailed";

export type PipelineNodeId =
  | "discover"
  | "selectSites"
  | "searchAndVisit"
  | "extract"
  | "pageAgent"
  | "synthesize"
  | "report";

export type DiscoveryMode = "openWeb" | "pinnedDomainsOnly" | "searchThenPickSites";

export type SynthesisFormat = "bullets" | "numberedList" | "comparisonTable" | "executiveSummary";

export type PipelineNode = {
  id: PipelineNodeId;
  enabled: boolean;
  hint: string;
};

export type ExtractField = {
  label: string;
  hint: string;
};

export type AgentFlowConfig = {
  pipeline: PipelineNode[];
  discovery: {
    mode: DiscoveryMode;
    hint: string;
    queryTemplates: string[];
  };
  sources: {
    pinnedDomains: string[];
    maxSites: number;
  };
  extract: {
    fields: ExtractField[];
    hint: string;
  };
  synthesize: {
    format: SynthesisFormat;
    hint: string;
    reportLabel: string;
  };
  pageAgent: {
    enabled: boolean;
    perSite: boolean;
    goalTemplate: string;
    hint: string;
  };
};

export type AgentFlow = {
  id: string;
  name: string;
  schemaVersion: number;
  createdAt: number;
  updatedAt: number;
  config: AgentFlowConfig;
};

export type AgentFlowSummary = {
  id: string;
  name: string;
  updatedAt: number;
};

export type HistoryVisit = {
  id: string;
  url: string;
  title: string;
  domain: string;
  visitedAt: number;
};

export type DownloadRecord = {
  id: string;
  sourceUrl: string;
  fileName: string;
  filePath: string;
  domain: string;
  downloadedAt: number;
};

export type AppSettings = {
  search: SearchSettings;
  research: ResearchLimits;
  aiEnabled: boolean;
  saveWithAiEnabled: boolean;
  agentLimits: AgentLimits;
  agentStructureLevel: AgentStructureLevel;
  assistantMode: AssistantMode;
  historyEnabled: boolean;
  aiHistoryEnabled: boolean;
  adBlockEnabled: boolean;
  customFlowId: string | null;
};

export type AdBlockStatus = {
  enabled: boolean;
  ruleHosts: number;
  updatedAt: number;
  sources: string[];
};

export type OmniboxDecision = {
  kind: string;
  value: string;
};

export type SavedPage = {
  id: string;
  url: string;
  title: string;
  domain: string;
  savedAt: string;
  summary: string;
  tags: string[];
};

export type PageBounds = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export type PageInfo = {
  url: string;
  origin: string;
  title: string;
  readyState: string;
  lang: string;
  untrustedText: string;
  elementCount: number;
  generation: number;
};

export type PageElement = {
  id: number;
  generation: number;
  tag: string;
  role: string;
  text: string;
  ariaLabel: string;
  placeholder: string;
  href: string;
  enabled: boolean;
  visible: boolean;
  bounds: PageBounds;
  dangerous: boolean;
  typeable: boolean;
  inputType?: string;
  name?: string;
  elementId?: string;
  className?: string;
  readOnly?: boolean;
};

export type InspectResult = {
  page: PageInfo;
  elements: PageElement[];
};

export type ActionResult = {
  executed: boolean;
  needsConfirmation: boolean;
  message: string;
  page: PageInfo;
};

export type ScreenshotResult = {
  width: number;
  height: number;
  devicePixelRatio: number;
  url: string;
  note: string;
  fullPage?: boolean;
  pngBase64?: string;
};

export type ScrollDirection = "up" | "down" | "left" | "right" | "top" | "bottom";
