type IconButtonProps = {
  label: string;
  disabled?: boolean;
  active?: boolean;
  onClick: () => void;
  children: React.ReactNode;
};

export function IconButton({
  label,
  disabled,
  active,
  onClick,
  children,
}: IconButtonProps) {
  return (
    <button
      type="button"
      className={`icon-btn${active ? " is-active" : ""}`}
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
