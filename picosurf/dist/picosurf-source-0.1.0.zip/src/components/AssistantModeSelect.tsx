import type { AgentFlowSummary, AssistantMode } from "../types/ipc";

type AssistantModeSelectProps = {
  value: AssistantMode;
  customFlowId: string | null;
  customFlows: AgentFlowSummary[];
  onChange: (mode: AssistantMode, customFlowId?: string | null) => void;
  compact?: boolean;
  disabled?: boolean;
};

export function AssistantModeSelect({
  value,
  customFlowId,
  customFlows,
  onChange,
  compact = false,
  disabled = false,
}: AssistantModeSelectProps) {
  return (
    <fieldset
      className={`assistant-mode${compact ? " is-compact" : ""}`}
      aria-label="Assistant mode"
      disabled={disabled}
    >
      <legend className="sr-only">Assistant mode</legend>
      <label className="assistant-mode-option" title="Default multi-source web research">
        <input
          type="radio"
          name="assistant-mode"
          checked={value === "research"}
          onChange={() => onChange("research", null)}
        />
        <span>Research</span>
      </label>
      <label
        className="assistant-mode-option"
        title="Multi-step browse: navigate, search, click, and type on pages"
      >
        <input
          type="radio"
          name="assistant-mode"
          checked={value === "agent"}
          onChange={() => onChange("agent", null)}
        />
        <span>Agent</span>
      </label>
      <label className="assistant-mode-option" title="Guess research vs page actions from wording">
        <input
          type="radio"
          name="assistant-mode"
          checked={value === "auto"}
          onChange={() => onChange("auto", null)}
        />
        <span>Auto</span>
      </label>
      {customFlows.length > 0 ? (
        <div className="assistant-mode-custom">
          <span className="assistant-mode-custom-label">Custom</span>
          {customFlows.map((flow) => (
            <label
              key={flow.id}
              className="assistant-mode-option"
              title="Structured flow from DevTools"
            >
              <input
                type="radio"
                name="assistant-mode"
                checked={value === "custom" && customFlowId === flow.id}
                onChange={() => onChange("custom", flow.id)}
              />
              <span>{flow.name}</span>
            </label>
          ))}
        </div>
      ) : null}
    </fieldset>
  );
}

export function assistantModeHint(
  mode: AssistantMode,
  customFlows: AgentFlowSummary[],
  customFlowId: string | null,
): string {
  if (mode === "research") return "Web sources and local reports";
  if (mode === "agent") return "Step-by-step actions on live pages";
  if (mode === "auto") return "Guess from your wording";
  const name = customFlows.find((flow) => flow.id === customFlowId)?.name;
  return name ? `Custom flow: ${name}` : "Custom flow (pick one in DevTools)";
}

export function assistantModeTaskHint(
  mode: AssistantMode,
  customFlows: AgentFlowSummary[],
  customFlowId: string | null,
): string {
  const base = assistantModeHint(mode, customFlows, customFlowId);
  if (mode === "agent") {
    return `${base} The assistant reads the page and runs actions until done or limits are hit. Risky steps ask for confirmation.`;
  }
  if (mode === "research") {
    return `${base} Research answers open in the main view. Prefix the address bar with ? to force a normal web search.`;
  }
  if (mode === "auto") {
    return `${base} Use Agent for reliable multi-step browsing; Research for multi-site reports. ? forces a web search.`;
  }
  return `${base} Prefix the address bar with ? to force a normal web search.`;
}
