import { FormEvent, useEffect, useState } from "react";
import {
  historyAiEnabledGet,
  historyAiEnabledSet,
  historyClear,
  historyEnabledGet,
  historyEnabledSet,
  historyList,
} from "../browser/api";
import { isTauri } from "../browser/tauriEnv";
import type { HistoryVisit } from "../types/ipc";

type HistoryPanelProps = {
  open: boolean;
  onClose: () => void;
  onOpenUrl: (url: string) => void;
};

export function HistoryPanel({ open, onClose, onOpenUrl }: HistoryPanelProps) {
  const [query, setQuery] = useState("");
  const [entries, setEntries] = useState<HistoryVisit[]>([]);
  const [historyEnabled, setHistoryEnabled] = useState(true);
  const [aiHistoryEnabled, setAiHistoryEnabled] = useState(false);
  const [message, setMessage] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearing, setClearing] = useState(false);

  useEffect(() => {
    if (!open || !isTauri()) return;
    void historyEnabledGet()
      .then(setHistoryEnabled)
      .catch((err: unknown) => setMessage(err instanceof Error ? err.message : String(err)));
    void historyAiEnabledGet()
      .then(setAiHistoryEnabled)
      .catch((err: unknown) => setMessage(err instanceof Error ? err.message : String(err)));
    void loadEntries("");
  }, [open]);

  async function loadEntries(search: string) {
    if (!isTauri()) {
      setEntries([]);
      return;
    }
    try {
      setEntries(await historyList(search, 80));
      setMessage("");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function handleSearch(event: FormEvent) {
    event.preventDefault();
    await loadEntries(query.trim());
  }

  async function toggleHistoryEnabled(enabled: boolean) {
    if (!isTauri()) {
      setHistoryEnabled(enabled);
      if (!enabled) {
        setAiHistoryEnabled(false);
      }
      return;
    }
    try {
      setHistoryEnabled(await historyEnabledSet(enabled));
      if (!enabled) {
        setAiHistoryEnabled(false);
        setMessage("Browsing history is off. New pages will not be saved.");
      } else {
        setMessage("Browsing history is on. Pages you visit will be saved locally.");
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function toggleAiHistory(enabled: boolean) {
    if (!isTauri()) {
      setAiHistoryEnabled(enabled);
      return;
    }
    try {
      setAiHistoryEnabled(await historyAiEnabledSet(enabled));
      setMessage(
        enabled
          ? "The AI agent may use matching local history entries."
          : "AI will not read browsing history.",
      );
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function clearAll() {
    if (!isTauri() || clearing) return;
    setClearing(true);
    setMessage("");
    try {
      await historyClear();
      setQuery("");
      setEntries([]);
      setConfirmClear(false);
      setMessage("History cleared.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
      await loadEntries(query.trim());
    } finally {
      setClearing(false);
    }
  }

  return (
    <aside
      className={`history-panel${open ? " is-open" : ""}`}
      aria-hidden={!open}
      inert={!open}
      aria-label="Browsing history"
    >
      <header className="ai-header">
        <div>
          <h1>History</h1>
          <p>Stored locally on this device. Websites cannot read this list.</p>
        </div>
        <button type="button" className="btn ghost" onClick={onClose}>
          Hide
        </button>
      </header>
      <div className="history-options">
        <label className="history-opt-in ai-include-page">
          <input
            type="checkbox"
            checked={historyEnabled}
            onChange={(event) => void toggleHistoryEnabled(event.target.checked)}
          />
          Save browsing history
        </label>
        <label className={`history-opt-in ai-include-page${historyEnabled ? "" : " is-disabled"}`}>
          <input
            type="checkbox"
            checked={aiHistoryEnabled}
            disabled={!historyEnabled}
            onChange={(event) => void toggleAiHistory(event.target.checked)}
          />
          Allow AI to use browsing history
        </label>
        <p className="inspect-meta history-note">
          AI access is off by default. When enabled, the local agent may see matching entries from
          this list — never from webpage scripts.
        </p>
      </div>
      <form className="history-search" onSubmit={(event) => void handleSearch(event)}>
        <input
          value={query}
          placeholder="Search history"
          aria-label="Search history"
          onChange={(event) => setQuery(event.target.value)}
        />
        <button type="submit" className="btn primary">
          Search
        </button>
      </form>
      {message ? <p className="inspect-meta">{message}</p> : null}
      {!historyEnabled ? (
        <p className="inspect-meta history-disabled-note">
          History saving is off. Turn it on above to record new visits, or clear existing entries
          below.
        </p>
      ) : null}
      <div className="history-list" aria-live="polite">
        {entries.length === 0 ? (
          <p className="inspect-meta">No history yet. Pages you visit will appear here.</p>
        ) : (
          <ul>
            {entries.map((entry) => (
              <li key={entry.id} className="history-item">
                <button
                  type="button"
                  className="history-link"
                  onClick={() => onOpenUrl(entry.url)}
                >
                  {entry.title || entry.domain || entry.url}
                </button>
                <span className="history-meta">
                  {entry.domain} · {formatWhen(entry.visitedAt)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
      <footer className="history-footer">
        {confirmClear ? (
          <div className="panel-confirm" role="group" aria-label="Confirm clear history">
            <p>Clear all browsing history on this device?</p>
            <div className="model-confirm-actions">
              <button
                type="button"
                className="btn ghost"
                disabled={clearing}
                onClick={() => setConfirmClear(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn primary"
                disabled={clearing}
                onClick={() => void clearAll()}
              >
                {clearing ? "Clearing…" : "Yes, clear"}
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            className="btn ghost"
            onClick={() => setConfirmClear(true)}
            disabled={entries.length === 0}
          >
            Clear history
          </button>
        )}
      </footer>
    </aside>
  );
}

function formatWhen(unixSeconds: number): string {
  if (!unixSeconds) return "unknown time";
  try {
    return new Date(unixSeconds * 1000).toLocaleString();
  } catch {
    return "unknown time";
  }
}
