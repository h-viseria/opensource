import { useEffect, useState } from "react";
import {
  browserClick,
  browserInspect,
  browserScroll,
  browserType,
  onBrowserState,
} from "../browser/api";
import { isTauri } from "../browser/tauriEnv";
import type { ActionResult, PageElement, PageInfo, ScrollDirection } from "../types/ipc";

const PREVIEW_PAGE: PageInfo = {
  url: "https://duckduckgo.com/",
  origin: "https://duckduckgo.com",
  title: "DuckDuckGo",
  readyState: "complete",
  lang: "en",
  untrustedText: "",
  elementCount: 2,
  generation: 1,
};

const PREVIEW_ELEMENTS: PageElement[] = [
  {
    id: 1,
    generation: 1,
    tag: "input",
    role: "combobox",
    text: "",
    ariaLabel: "Search",
    placeholder: "Search the web",
    href: "",
    enabled: true,
    visible: true,
    bounds: { x: 40, y: 80, width: 320, height: 40 },
    dangerous: false,
    typeable: true,
  },
  {
    id: 2,
    generation: 1,
    tag: "button",
    role: "button",
    text: "Search",
    ariaLabel: "",
    placeholder: "",
    href: "",
    enabled: true,
    visible: true,
    bounds: { x: 370, y: 80, width: 72, height: 40 },
    dangerous: false,
    typeable: false,
  },
];

export function PageInspect() {
  const [page, setPage] = useState<PageInfo | null>(isTauri() ? null : PREVIEW_PAGE);
  const [elements, setElements] = useState<PageElement[]>(isTauri() ? [] : PREVIEW_ELEMENTS);
  const [selectedId, setSelectedId] = useState<number | null>(isTauri() ? null : 1);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(
    isTauri()
      ? "Inspect the current page to list clickable and typeable elements."
      : "Preview only. Page actions run in the Windows app.",
  );
  const [pending, setPending] = useState<PageElement | null>(null);

  const selected = elements.find((item) => item.id === selectedId) ?? null;

  useEffect(() => {
    if (!isTauri()) return;
    let active = true;
    let lastUrl = "";
    let unlisten: (() => void) | undefined;
    void onBrowserState((state) => {
      if (!active) return;
      if (lastUrl && state.url !== lastUrl) {
        setElements([]);
        setSelectedId(null);
        setPending(null);
        setPage(null);
        setMessage("Page changed. Inspect again before clicking.");
      }
      lastUrl = state.url;
    }).then((fn) => {
      if (!active) {
        fn();
        return;
      }
      unlisten = fn;
    });
    return () => {
      active = false;
      unlisten?.();
    };
  }, []);

  async function inspect() {
    setBusy(true);
    setPending(null);
    try {
      if (!isTauri()) {
        setPage(PREVIEW_PAGE);
        setElements(PREVIEW_ELEMENTS);
        setSelectedId(1);
        setMessage("Preview snapshot. Live inspect needs the Windows app.");
        return;
      }
      const result = await browserInspect();
      setPage(result.page);
      setElements(result.elements);
      setSelectedId(result.elements[0]?.id ?? null);
      setMessage(
        result.elements.length
          ? `Found ${result.elements.length} elements on this page.`
          : "No interactive elements were visible.",
      );
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function applyAction(run: () => Promise<ActionResult>) {
    setBusy(true);
    try {
      const result = await run();
      setMessage(result.message);
      setPage(result.page);
      if (result.needsConfirmation && selected) {
        setPending(selected);
      } else {
        setPending(null);
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  function click(confirmed = false) {
    if (!selected) return;
    if (!isTauri()) {
      setMessage(
        selected.dangerous && !confirmed
          ? `Confirm before clicking '${label(selected)}'.`
          : `Would click ${label(selected)}.`,
      );
      if (selected.dangerous && !confirmed) setPending(selected);
      else setPending(null);
      return;
    }
    void applyAction(() => browserClick(selected.id, selected.generation, confirmed));
  }

  function typeInto() {
    if (!selected) return;
    if (!isTauri()) {
      setMessage(`Would type into ${label(selected)}.`);
      return;
    }
    void applyAction(() => browserType(selected.id, selected.generation, draft));
  }

  function scroll(direction: ScrollDirection) {
    if (!isTauri()) {
      setMessage(`Would scroll ${direction}.`);
      return;
    }
    void applyAction(() => browserScroll(direction));
  }

  return (
    <section className="page-inspect" aria-label="Page inspect">
      <div className="inspect-heading">
        <h2>Page</h2>
        <button type="button" className="btn primary" disabled={busy} onClick={() => void inspect()}>
          Inspect
        </button>
      </div>
      <p className="inspect-meta">
        {page ? `${page.title || page.url || "Untitled"} · ${page.elementCount} elements` : "Not inspected yet"}
      </p>
      <div className="inspect-toolbar" role="group" aria-label="Scroll">
        <button type="button" className="btn ghost" disabled={busy} onClick={() => scroll("up")}>
          Up
        </button>
        <button type="button" className="btn ghost" disabled={busy} onClick={() => scroll("down")}>
          Down
        </button>
        <button type="button" className="btn ghost" disabled={busy} onClick={() => scroll("top")}>
          Top
        </button>
        <button type="button" className="btn ghost" disabled={busy} onClick={() => scroll("bottom")}>
          Bottom
        </button>
      </div>
      <p className="inspect-message">{message}</p>
      <ul className="inspect-list">
        {elements.length === 0 ? (
          <li className="inspect-empty">Inspect the page to see elements the assistant may use later.</li>
        ) : (
          elements.map((item) => (
            <li key={`${item.generation}-${item.id}`}>
              <button
                type="button"
                className={`inspect-item${item.id === selectedId ? " is-selected" : ""}${
                  item.dangerous ? " is-dangerous" : ""
                }`}
                onClick={() => setSelectedId(item.id)}
              >
                <span className="inspect-tag">
                  #{item.id} {item.tag}
                  {item.dangerous ? " · confirm" : ""}
                  {item.typeable ? " · type" : ""}
                </span>
                <span className="inspect-text">{label(item)}</span>
              </button>
            </li>
          ))
        )}
      </ul>
      <div className="inspect-actions">
        <button type="button" className="btn ghost" disabled={busy || !selected} onClick={() => click(false)}>
          Click
        </button>
        <input
          className="inspect-type"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder={selected?.typeable ? "Text to type" : "Select a field first"}
          disabled={busy || !selected?.typeable}
        />
        <button
          type="button"
          className="btn ghost"
          disabled={busy || !selected?.typeable || !draft}
          onClick={typeInto}
        >
          Type
        </button>
      </div>
      {pending ? (
        <div className="model-confirm" role="dialog" aria-labelledby="inspect-confirm-title">
          <h2 id="inspect-confirm-title">Confirm this click?</h2>
          <p>
            This looks like a submit, purchase, sign-in, or similar control. Click &lsquo;
            {label(pending)}&rsquo; only if you mean to.
          </p>
          <div className="model-confirm-actions">
            <button type="button" className="btn ghost" onClick={() => setPending(null)}>
              Cancel
            </button>
            <button
              type="button"
              className="btn primary"
              onClick={() => {
                const target = pending;
                setPending(null);
                setSelectedId(target.id);
                void applyAction(() =>
                  isTauri()
                    ? browserClick(target.id, target.generation, true)
                    : Promise.resolve({
                        executed: false,
                        needsConfirmation: false,
                        message: `Would click ${label(target)}.`,
                        page: page ?? PREVIEW_PAGE,
                      }),
                );
              }}
            >
              Click anyway
            </button>
          </div>
        </div>
      ) : null}
    </section>
  );
}

function label(item: PageElement) {
  return item.text || item.ariaLabel || item.placeholder || item.href || item.tag;
}
