import { FormEvent, useEffect, useRef, useState } from "react";
import {
  aiConfirm,
  aiGenerate,
  aiStop,
  aiTask,
  onAiConfirm,
  onAiStatus,
  onAiToken,
  saveWithAi,
} from "../browser/api";
import { isTauri } from "../browser/tauriEnv";
import type {
  AgentConfirm,
  AgentFlowSummary,
  AgentOutcome,
  AssistantMode,
  ChatTurn,
  CitedSource,
} from "../types/ipc";
import {
  AssistantModeSelect,
  assistantModeHint,
  assistantModeTaskHint,
} from "../components/AssistantModeSelect";
import { ModelSelect } from "./ModelSelect";

export type PendingAi = {
  id: number;
  text: string;
  mode: "task" | "chat";
};

type AiPanelProps = {
  open: boolean;
  onClose: () => void;
  onOpenPrivacy: () => void;
  onOpenUrl?: (url: string) => void;
  pending?: PendingAi | null;
  onPendingConsumed?: () => void;
  assistantMode: AssistantMode;
  customFlowId: string | null;
  customFlows: AgentFlowSummary[];
  onAssistantModeChange: (mode: AssistantMode, customFlowId?: string | null) => void;
};

export function AiPanel({
  open,
  onClose,
  onOpenPrivacy,
  onOpenUrl,
  pending,
  onPendingConsumed,
  assistantMode,
  customFlowId,
  customFlows,
  onAssistantModeChange,
}: AiPanelProps) {
  const [draft, setDraft] = useState("");
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [working, setWorking] = useState(false);
  const [includePage, setIncludePage] = useState(true);
  const [allowActions, setAllowActions] = useState(true);
  const [status, setStatus] = useState("");
  const [activity, setActivity] = useState<string[]>([]);
  const [sources, setSources] = useState<CitedSource[]>([]);
  const [reportOpened, setReportOpened] = useState(false);
  const [confirm, setConfirm] = useState<AgentConfirm | null>(null);
  const [messages, setMessages] = useState<ChatTurn[]>([]);
  const streamRef = useRef("");

  useEffect(() => {
    if (!isTauri()) return;
    let active = true;
    let unlistenToken: (() => void) | undefined;
    let unlistenStatus: (() => void) | undefined;
    let unlistenConfirm: (() => void) | undefined;
    void onAiToken((text) => {
      if (!active) return;
      streamRef.current += text;
      setMessages((current) => {
        const next = [...current];
        const last = next[next.length - 1];
        if (last?.role === "assistant") {
          next[next.length - 1] = { role: "assistant", content: streamRef.current };
        } else {
          next.push({ role: "assistant", content: streamRef.current });
        }
        return next;
      });
    }).then((fn) => {
      if (!active) fn();
      else unlistenToken = fn;
    });
    void onAiStatus((event) => {
      if (!active) return;
      setStatus(event.message);
      if (
        event.phase === "acting" ||
        event.phase === "reading_page" ||
        event.phase === "generating" ||
        event.phase === "needs_confirmation"
      ) {
        setWorking(true);
        setActivity((current) => {
          if (current[current.length - 1] === event.message) return current;
          return [...current, event.message].slice(-16);
        });
      }
      if (
        event.phase === "stopped" ||
        event.phase === "done" ||
        event.phase === "error" ||
        event.phase === "limited" ||
        event.phase === "ask"
      ) {
        setWorking(false);
        setBusy(false);
        if (event.phase === "stopped") setConfirm(null);
      }
    }).then((fn) => {
      if (!active) fn();
      else unlistenStatus = fn;
    });
    void onAiConfirm((payload) => {
      if (!active) return;
      setConfirm(payload);
    }).then((fn) => {
      if (!active) fn();
      else unlistenConfirm = fn;
    });
    return () => {
      active = false;
      unlistenToken?.();
      unlistenStatus?.();
      unlistenConfirm?.();
    };
  }, []);

  useEffect(() => {
    if (!pending || !ready || busy || working) return;
    const next = pending;
    onPendingConsumed?.();
    if (next.mode === "chat") void sendChat(next.text, true);
    else void runTask(next.text);
  }, [pending?.id, ready, busy, working]);

  function applyOutcome(history: ChatTurn[], outcome: AgentOutcome) {
    const openedReport = Boolean(outcome.viewUrl);
    setReportOpened(openedReport);
    if (outcome.activity.length && !openedReport) {
      setActivity(outcome.activity.slice(-12));
    } else if (outcome.activity.length && openedReport) {
      setActivity([]);
    }
    if (outcome.sources?.length && !openedReport) {
      setSources(outcome.sources);
    } else {
      setSources([]);
    }
    if (outcome.status === "needs_confirmation") {
      setConfirm({
        action: "confirm",
        message: outcome.message,
        elementLabel: "",
      });
      setStatus(outcome.message);
      setWorking(true);
      return;
    }
    setWorking(false);
    setConfirm(null);
    setMessages([...history, { role: "assistant", content: outcome.message }]);
    setStatus(outcome.status === "done" ? "" : outcome.message);
  }

  async function runTask(text: string) {
    const trimmed = text.trim();
    if (!trimmed || !ready || busy) return;
    const history: ChatTurn[] = [...messages, { role: "user", content: trimmed }];
    setMessages(history);
    setDraft("");
    streamRef.current = "";
    setActivity([]);
    setSources([]);
    setReportOpened(false);
    setConfirm(null);
    setBusy(true);
    setWorking(true);
    setStatus("Working on the page…");
    try {
      if (!isTauri()) {
        setMessages([
          ...history,
          {
            role: "assistant",
            content:
              "Preview only. In the Windows app PicoSurf would inspect this page and take confirmed steps locally.",
          },
        ]);
        return;
      }
      applyOutcome(history, await aiTask(trimmed));
    } catch (err) {
      setConfirm(null);
      setWorking(false);
      setMessages([
        ...history,
        { role: "assistant", content: err instanceof Error ? err.message : String(err) },
      ]);
      setStatus("");
    } finally {
      setBusy(false);
    }
  }

  async function sendChat(text: string, attachPage: boolean) {
    const trimmed = text.trim();
    if (!trimmed || !ready || busy) return;
    const history: ChatTurn[] = [...messages, { role: "user", content: trimmed }];
    setMessages(history);
    setDraft("");
    streamRef.current = "";
    setActivity([]);
    setSources([]);
    setReportOpened(false);
    setConfirm(null);
    setBusy(true);
    setWorking(true);
    setStatus(attachPage ? "Reading page…" : "Answering…");
    try {
      if (!isTauri()) {
        setMessages([
          ...history,
          {
            role: "assistant",
            content: attachPage
              ? "Preview only. In the Windows app PicoSurf would read this page locally and answer from untrusted page data."
              : "Preview only. Local generation runs in the Windows app after a model is loaded.",
          },
        ]);
        return;
      }
      const result = await aiGenerate(history, attachPage);
      if (!streamRef.current && result.text) {
        setMessages([...history, { role: "assistant", content: result.text }]);
      }
      if (result.usedPage && result.pageOrigin) {
        setStatus(`Used page ${result.pageOrigin}`);
      } else {
        setStatus(result.message || "");
      }
    } catch (err) {
      setWorking(false);
      setMessages([
        ...history,
        { role: "assistant", content: err instanceof Error ? err.message : String(err) },
      ]);
      setStatus("");
    } finally {
      setBusy(false);
      setWorking(false);
    }
  }

  async function handleConfirm() {
    if (!ready || busy) return;
    const history = messages;
    setBusy(true);
    setWorking(true);
    setStatus("Continuing…");
    try {
      applyOutcome(history, await aiConfirm());
    } catch (err) {
      setConfirm(null);
      setMessages([
        ...history,
        { role: "assistant", content: err instanceof Error ? err.message : String(err) },
      ]);
      setStatus("");
    } finally {
      setBusy(false);
    }
  }

  async function handleCancel() {
    setConfirm(null);
    setStatus("Stopping…");
    setWorking(true);
    try {
      await aiStop();
    } catch {
      /* already stopped */
    }
  }

  async function handleSave() {
    if (!ready || busy) return;
    const history: ChatTurn[] = [...messages, { role: "user", content: "Save this page with AI" }];
    setMessages(history);
    streamRef.current = "";
    setActivity([]);
    setSources([]);
    setReportOpened(false);
    setConfirm(null);
    setBusy(true);
    setWorking(true);
    setStatus("Saving this page locally…");
    try {
      if (!isTauri()) {
        setMessages([
          ...history,
          {
            role: "assistant",
            content: "Preview only. In the Windows app PicoSurf would save a local summary of this page.",
          },
        ]);
        return;
      }
      applyOutcome(history, await saveWithAi());
    } catch (err) {
      setWorking(false);
      setMessages([
        ...history,
        { role: "assistant", content: err instanceof Error ? err.message : String(err) },
      ]);
      setStatus("");
    } finally {
      setBusy(false);
    }
  }

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (allowActions) void runTask(draft);
    else void sendChat(draft, includePage);
  }

  const waiting = Boolean(confirm) && !busy;
  const showCancel = busy || waiting || working || Boolean(confirm);

  return (
    <aside
      className={`ai-panel${open ? " is-open" : ""}`}
      aria-hidden={!open}
      inert={!open}
      aria-label="PicoSurf assistant"
    >
      <header className="ai-header">
        <div>
          <h1>Assistant</h1>
          <p>Local only. Page text is data, not instructions.</p>
        </div>
        <div className="ai-header-actions">
          {showCancel ? (
            <button type="button" className="btn danger" onClick={() => void handleCancel()}>
              Cancel
            </button>
          ) : null}
          <button type="button" className="btn ghost" onClick={onClose}>
            Hide
          </button>
        </div>
      </header>
      <div className="ai-mode-row">
        <AssistantModeSelect
          value={assistantMode}
          customFlowId={customFlowId}
          customFlows={customFlows}
          onChange={onAssistantModeChange}
          disabled={busy || working}
        />
        <p className="ai-mode-hint">
          {assistantModeHint(assistantMode, customFlows, customFlowId)}
        </p>
      </div>
      <ModelSelect onReadyChange={setReady} />
      <div className="ai-log" aria-live="polite">
        {messages.length === 0 ? (
          <p className="ai-empty">
            {ready
              ? allowActions
                ? assistantModeTaskHint(assistantMode, customFlows, customFlowId)
                : "Ask about this page, or summarize it. Webpage text stays on this device and is treated as untrusted data."
              : "Chat stays off until a local model is downloaded and loaded."}
          </p>
        ) : (
          messages.map((item, index) => (
            <p key={`${item.role}-${index}`} className={`ai-bubble is-${item.role}`}>
              {item.content}
            </p>
          ))
        )}
        {activity.length > 0 && (working || !reportOpened) ? (
          <ul className="ai-activity">
            {activity.map((line, index) => (
              <li key={`${index}-${line}`}>{line}</li>
            ))}
          </ul>
        ) : null}
        {sources.length > 0 && !reportOpened ? (
          <div className="ai-sources">
            <h2>Sources</h2>
            <ul>
              {sources.map((source) => (
                <li key={source.url}>
                  <button
                    type="button"
                    className="ai-source-link"
                    onClick={() => onOpenUrl?.(source.url)}
                  >
                    {source.title || source.domain}
                  </button>
                  <span>{source.domain}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
      {showCancel ? (
        <div className="ai-cancel-bar">
          <span>{waiting ? "Waiting for your confirmation" : "Working… Cancel if this is stuck."}</span>
          <button type="button" className="btn danger" onClick={() => void handleCancel()}>
            Cancel
          </button>
        </div>
      ) : null}
      {confirm ? (
        <div className="ai-confirm">
          <h2>Confirm this step</h2>
          <p>{confirm.message}</p>
          <div className="ai-confirm-actions">
            <button
              type="button"
              className="btn primary"
              disabled={busy}
              onClick={() => void handleConfirm()}
            >
              Confirm
            </button>
            <button
              type="button"
              className="btn ghost"
              onClick={() => void handleCancel()}
            >
              Cancel
            </button>
          </div>
        </div>
      ) : null}
      {status ? <p className="ai-status">{status}</p> : null}
      <form className="ai-composer" onSubmit={handleSubmit}>
        <div className="ai-tools">
          <button
            type="button"
            className="btn ghost"
            disabled={!ready || busy || waiting}
            onClick={() => void sendChat("Summarize this page.", true)}
          >
            Summarize page
          </button>
          <button
            type="button"
            className="btn ghost"
            disabled={!ready || busy || waiting}
            onClick={() => void handleSave()}
          >
            Save with AI
          </button>
          <label className="ai-include-page">
            <input
              type="checkbox"
              checked={allowActions}
              onChange={(event) => setAllowActions(event.target.checked)}
              disabled={busy || waiting}
            />
            Allow page actions
          </label>
          {allowActions ? null : (
            <label className="ai-include-page">
              <input
                type="checkbox"
                checked={includePage}
                onChange={(event) => setIncludePage(event.target.checked)}
                disabled={busy}
              />
              Include current page
            </label>
          )}
        </div>
        <textarea
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder={
            ready
              ? allowActions
                ? "Research a topic, shop with confirmation, or ask about this page"
                : includePage
                  ? "Ask about this page"
                  : "Ask PicoSurf (no page attached)"
              : "Ask PicoSurf after a model is ready"
          }
          rows={3}
          disabled={!ready || busy || waiting}
        />
        {showCancel ? (
          <button
            type="button"
            className="btn ghost"
            onClick={() => void handleCancel()}
          >
            Stop
          </button>
        ) : (
          <button type="submit" className="btn primary" disabled={!ready || !draft.trim()}>
            Send
          </button>
        )}
      </form>
      <button type="button" className="privacy-link" onClick={onOpenPrivacy}>
        Privacy
      </button>
    </aside>
  );
}
