type HelpPanelProps = {
  open: boolean;
  onClose: () => void;
};

export function HelpPanel({ open, onClose }: HelpPanelProps) {
  return (
    <aside
      className={`help-panel dev-panel${open ? " is-open" : ""}`}
      aria-hidden={!open}
      inert={!open}
      aria-label="PicoSurf help"
    >
      <header className="ai-header">
        <div>
          <h1>Help</h1>
          <p>Features, side panels, and optional configuration files.</p>
        </div>
        <button type="button" className="btn ghost" onClick={onClose}>
          Hide
        </button>
      </header>

      <article className="help-doc">
        <section>
          <h2>Toolbar and browsing</h2>
          <ul>
            <li>
              <strong>Back / Forward / Reload</strong> — control the main browser view (WebView2).
            </li>
            <li>
              <strong>Address bar</strong> — enter a URL, run a normal web search, or ask the
              assistant. Prefix with <code>?</code> or <code>search:</code> to force a web search
              instead of AI routing.
            </li>
            <li>
              <strong>Assistant mode</strong> — pill buttons left of the address bar (same choices in
              the AI panel). See <em>Assistant modes</em> below.
            </li>
            <li>
              <strong>Clean View</strong> — click elements on the page to hide them; press Esc to
              exit. Does not affect the chrome UI.
            </li>
          </ul>
        </section>

        <section>
          <h2>Assistant modes</h2>
          <p>
            Pick a mode before you ask in the address bar or AI panel. The choice is saved locally.
            Turn on <strong>AI enabled</strong> in DevTools for address-bar routing.
          </p>
          <ul>
            <li>
              <strong>Research</strong> (default) — multi-source answers. PicoSurf searches the web,
              opens several result pages, extracts text, and builds a local HTML report in the main
              view with cited sources. Best for “compare options”, “top 5 …”, or broad questions.
            </li>
            <li>
              <strong>Agent</strong> — one goal, many steps on live pages. Examples: “Go to
              trafigura.com and search for India jobs”, “Open Amazon and search for milk, add to
              cart”. PicoSurf loops: read the page (interactive elements + sanitized text), ask the
              local model for the next action, execute it, wait for the page to settle, repeat until
              done or limits hit. Does not send page screenshots to the model by default; actions use
              the element list and visible text. Explicit phrases still work: summarize this page,
              save with AI, search saved articles.
            </li>
            <li>
              <strong>Auto</strong> — guesses Research vs page actions from your wording. Convenient
              but easy to mis-route; use <em>Agent</em> when you want reliable multi-step browsing
              and <em>Research</em> when you want a report.
            </li>
            <li>
              <strong>Custom</strong> — runs a named pipeline you built in DevTools (discovery, site
              pick, visit, extract, report). Not the same as Agent mode; it follows your saved flow
              steps.
            </li>
            <li>
              Force a normal web search (no AI routing): prefix the address bar with <code>?</code> or{" "}
              <code>search:</code>.
            </li>
          </ul>
        </section>

        <section>
          <h2>AI panel</h2>
          <p>
            Open <strong>AI</strong> to chat with the loaded local model and run tasks. A model must
            be downloaded and loaded before chat and agent actions work.
          </p>
          <ul>
            <li>
              <strong>Assistant mode</strong> — same Research / Agent / Auto / Custom pills as the
              toolbar; changing either place updates both.
            </li>
            <li>
              <strong>Model list</strong> — pick a featured model, or expand{" "}
              <em>Show more models</em> for additional built-in entries. Download, then Load.
            </li>
            <li>
              <strong>Include current page</strong> — attach sanitized page text to chat (untrusted
              data; treated as content only).
            </li>
            <li>
              <strong>Allow page actions</strong> — required for Agent tasks and address-bar{" "}
              <em>task</em> routing. When on, the local agent can inspect, click, type, clear fields,
              check boxes, pick dropdown options, press keys, scroll, wait for loads, search DOM
              snippets, capture screenshots (saved locally), and handle script dialogs. Purchases,
              checkout, sign-in, and similar steps ask for confirmation. When off, chat is read-only
              about the page.
            </li>
            <li>
              <strong>Cancel / Confirm</strong> — during a task, Cancel stops the loop; Confirm
              approves a sensitive step the agent paused for.
            </li>
          </ul>
        </section>

        <section>
          <h2>History</h2>
          <ul>
            <li>
              <strong>Visit history</strong> — recent URLs on this device. Search and open entries
              again.
            </li>
            <li>
              <strong>Record history</strong> — toggle whether new visits are stored locally.
            </li>
            <li>
              <strong>AI history</strong> — optional separate log for AI-related activity (off by
              default).
            </li>
            <li>
              <strong>Clear history</strong> — removes stored visits on this device.
            </li>
          </ul>
        </section>

        <section>
          <h2>Downloads</h2>
          <p>
            Lists files downloaded through the browser, with source URL and local path. Clear the
            list from the panel when needed.
          </p>
        </section>

        <section>
          <h2>DevTools</h2>
          <p>
            Open the toolbar <strong>DevTools</strong> button (code icon). Settings are stored
            locally under PicoSurf app data.
          </p>

          <h3>Custom agent flows</h3>
          <ul>
            <li>
              <strong>New flow / Save / Delete</strong> — named research pipelines stored on disk.
            </li>
            <li>
              <strong>Use in assistant</strong> — selects that flow in Custom assistant mode.
            </li>
            <li>
              <strong>Pipeline steps</strong> — enable or disable discover, site pick, visit,
              extract, in-page pass, synthesize, and report.
            </li>
            <li>
              <strong>Discovery</strong> — open web, pinned domains only, or search-then-pick-sites.
              Put retailer hostnames in <em>Pinned domains</em> or a discovery hint such as{" "}
              <em>Find on amazon.in, flipkart, jiomart</em> (comma-separated).
            </li>
            <li>
              <strong>Query templates</strong> — use <code>{"{domain}"}</code>,{" "}
              <code>{"{subject}"}</code>, <code>{"{goal}"}</code>. For pinned retailers prefer{" "}
              <code>site:{"{domain}"} {"{subject}"}</code>.
            </li>
          </ul>

          <h3>Search settings</h3>
          <ul>
            <li>Default search engine and optional separate engine for AI research.</li>
            <li>Custom search URL template must include <code>{"{query}"}</code>.</li>
            <li>Research limits — max queries, pages opened, runtime, extract size.</li>
            <li>
              <strong>AI enabled</strong> — master switch for address-bar AI routing.
            </li>
            <li>
              <strong>Save with AI</strong> — local page summaries when you ask to save a page.
            </li>
            <li>
              <strong>Block ads and trackers</strong> — network filter (EasyList/EasyPrivacy).
              Blocks third-party trackers; main pages and first-party requests stay allowed. Pinned
              flow domains and search engines are allowlisted.
            </li>
          </ul>

          <h3>Ad block</h3>
          <ul>
            <li>Shows filter status and last update.</li>
            <li>
              <strong>Update filters now</strong> — downloads lists (about every 24h automatically).
            </li>
          </ul>

          <h3>Assistant limits</h3>
          <p>
            Caps for <strong>Agent</strong> mode and other page-action tasks: max actions,
            navigations, and runtime seconds per run (defaults 8 / 3 / 90). Raise them here for
            longer shopping or job-search flows; Cancel in the AI panel if a task stalls.
          </p>

          <h3>Page inspect</h3>
          <p>
            Lists interactive elements on the current page for debugging agent clicks (element IDs,
            labels, roles).
          </p>
        </section>

        <section>
          <h2>models.config (extra GGUF models)</h2>
          <p>
            Optional JSON file to add or feature extra Hugging Face GGUF models in the AI panel. Copy{" "}
            <code>models.config.example.json</code> from the project root as a starting point.
          </p>
          <p>PicoSurf looks for <code>models.config</code> in this order:</p>
          <ol>
            <li>
              Path in environment variable <code>PICOSURF_MODELS_CONFIG</code>
            </li>
            <li>Next to the PicoSurf executable</li>
            <li>Current working directory when the app starts</li>
            <li>
              <code>%LOCALAPPDATA%/PicoSurf/models.config</code>
            </li>
          </ol>
          <p>
            Built-in featured models always remain. Config entries with <code>featured: true</code>{" "}
            are merged into the featured list; others appear under <em>Show more models</em>.
          </p>
          <h3>File format (version 1)</h3>
          <pre className="help-code">{`{
  "version": 1,
  "models": [
    {
      "id": "unique-model-id",
      "displayName": "My Model Q4",
      "family": "Qwen2.5",
      "parameterSize": "3B",
      "quantization": "Q4_K_M",
      "ramHint": "8 GB+",
      "minRamBytes": 8589934592,
      "featured": false,
      "files": [
        {
          "name": "model-file.gguf",
          "url": "https://huggingface.co/.../resolve/main/model-file.gguf",
          "sizeBytes": 2104932768,
          "sha256": "64-char-hex-sha256-of-file"
        }
      ]
    }
  ]
}`}</pre>
          <ul>
            <li>
              <code>url</code> — HTTPS download from an allowed host (e.g. Hugging Face).
            </li>
            <li>
              <code>sha256</code> — full 64-character hex digest verified after download.
            </li>
            <li>
              <code>sizeBytes</code> — exact file size in bytes.
            </li>
            <li>Restart the app or reload models after editing the file.</li>
          </ul>
        </section>

        <section>
          <h2>Privacy</h2>
          <p>
            Open privacy notes from the AI panel footer. Research reports, agent activity, models, and
            saved pages stay on this device. Agent steps only use page content the browser already
            loaded; nothing is sent to a cloud LLM. External links in a report open in the same
            WebView when you choose them.
          </p>
        </section>
      </article>
    </aside>
  );
}
