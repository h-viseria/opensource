import { useEffect, useMemo, useState } from "react";
import {
  modelsCancel,
  modelsDownload,
  modelsList,
  modelsLoad,
  modelsSelect,
  onModelProgress,
} from "../browser/api";
import { isTauri } from "../browser/tauriEnv";
import type { HardwareInfo, ModelInfo, ModelProgress } from "../types/ipc";

type ModelSelectProps = {
  onReadyChange?: (ready: boolean) => void;
};

const PREVIEW_MODELS: ModelInfo[] = [
  {
    id: "qwen2.5-1.5b-instruct-q4",
    displayName: "Qwen 2.5 1.5B Instruct Q4",
    family: "Qwen2.5",
    parameterSize: "1.5B",
    quantization: "Q4_K_M",
    sizeBytes: 1_117_320_736,
    sizeLabel: "1.0 GB",
    ramHint: "4 GB+",
    status: "not_downloaded",
    recommended: true,
    featured: true,
  },
  {
    id: "qwen2.5-7b-instruct-q4",
    displayName: "Qwen 2.5 7B Instruct Q4",
    family: "Qwen2.5",
    parameterSize: "7B",
    quantization: "Q4_K_M",
    sizeBytes: 4_683_073_632,
    sizeLabel: "4.4 GB",
    ramHint: "16 GB+",
    status: "not_downloaded",
    featured: true,
  },
];

const PREVIEW_MORE: ModelInfo[] = [
  {
    id: "qwen2.5-0.5b-instruct-q4",
    displayName: "Qwen 2.5 0.5B Instruct Q4",
    family: "Qwen2.5",
    parameterSize: "0.5B",
    quantization: "Q4_K_M",
    sizeBytes: 491_400_032,
    sizeLabel: "469 MB",
    ramHint: "2 GB+",
    status: "not_downloaded",
  },
  {
    id: "qwen2.5-3b-instruct-q4",
    displayName: "Qwen 2.5 3B Instruct Q4",
    family: "Qwen2.5",
    parameterSize: "3B",
    quantization: "Q4_K_M",
    sizeBytes: 2_104_932_768,
    sizeLabel: "2.0 GB",
    ramHint: "8 GB+",
    status: "not_downloaded",
  },
];

export function ModelSelect({ onReadyChange }: ModelSelectProps) {
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [moreModels, setMoreModels] = useState<ModelInfo[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loadedId, setLoadedId] = useState<string | null>(null);
  const [downloadEnabled, setDownloadEnabled] = useState(true);
  const [configPath, setConfigPath] = useState<string | null>(null);
  const [showMore, setShowMore] = useState(false);
  const [pending, setPending] = useState<ModelInfo | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [progress, setProgress] = useState<ModelProgress | null>(null);
  const [busy, setBusy] = useState(false);
  const [hardware, setHardware] = useState<HardwareInfo | null>(null);

  function applyList(response: {
    models: ModelInfo[];
    moreModels?: ModelInfo[];
    selectedId: string | null;
    loadedId?: string | null;
    downloadEnabled: boolean;
    hardware?: HardwareInfo;
    configPath?: string | null;
  }) {
    setModels(response.models);
    setMoreModels(response.moreModels ?? []);
    setSelectedId(response.selectedId);
    setLoadedId(response.loadedId ?? null);
    setDownloadEnabled(response.downloadEnabled);
    setConfigPath(response.configPath ?? null);
    if (response.hardware) setHardware(response.hardware);
    const all = [...response.models, ...(response.moreModels ?? [])];
    onReadyChange?.(all.some((model) => model.status === "ready"));
  }

  useEffect(() => {
    if (!isTauri()) {
      applyList({
        models: PREVIEW_MODELS,
        moreModels: PREVIEW_MORE,
        selectedId: null,
        loadedId: null,
        downloadEnabled: true,
      });
      return;
    }
    modelsList()
      .then(applyList)
      .catch((err: unknown) => {
        setNotice(err instanceof Error ? err.message : String(err));
      });
    let active = true;
    let unlisten: (() => void) | undefined;
    void onModelProgress((item) => {
      if (active) setProgress(item);
    }).then((fn) => {
      if (!active) fn();
      else unlisten = fn;
    });
    return () => {
      active = false;
      unlisten?.();
    };
  }, []);

  const allModels = useMemo(() => [...models, ...moreModels], [models, moreModels]);

  const dropdownModels = useMemo(() => {
    if (!selectedId) return models;
    if (models.some((model) => model.id === selectedId)) return models;
    const selected = moreModels.find((model) => model.id === selectedId);
    return selected ? [...models, selected] : models;
  }, [models, moreModels, selectedId]);

  const selected = useMemo(
    () => allModels.find((model) => model.id === selectedId) ?? null,
    [allModels, selectedId],
  );

  async function onChange(modelId: string) {
    setNotice(null);
    if (!isTauri()) {
      const model = allModels.find((item) => item.id === modelId) ?? null;
      setSelectedId(modelId);
      if (model) setPending(model);
      return;
    }
    try {
      const result = await modelsSelect(modelId);
      setSelectedId(result.selectedId);
      const model = allModels.find((item) => item.id === modelId) ?? null;
      if (result.needsDownload && model) {
        setPending(model);
      } else {
        setBusy(true);
        setProgress({
          modelId,
          phase: "load",
          received: 0,
          total: model?.sizeBytes ?? 1,
          message: "Loading into memory…",
        });
        const list = await modelsLoad(modelId);
        applyList(list);
        setProgress(null);
        setNotice(result.message);
      }
    } catch (err) {
      setNotice(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function confirmDownload() {
    if (!pending) return;
    const model = pending;
    setPending(null);
    if (!isTauri()) {
      setNotice(`Would download ${model.displayName} after you confirm in the Windows app.`);
      return;
    }
    setBusy(true);
    setNotice(`Downloading ${model.displayName}…`);
    setProgress({
      modelId: model.id,
      phase: "download",
      received: 0,
      total: model.sizeBytes,
      message: `Downloading ${model.displayName}…`,
    });
    try {
      await modelsDownload(model.id);
      setProgress({
        modelId: model.id,
        phase: "load",
        received: 0,
        total: model.sizeBytes,
        message: `Loading ${model.displayName}…`,
      });
      const list = await modelsLoad(model.id);
      applyList(list);
      setProgress(null);
      setNotice(`${model.displayName} is ready. Chat is on.`);
    } catch (err) {
      setProgress(null);
      setNotice(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function loadOnDisk(modelId: string) {
    setBusy(true);
    setNotice("Loading model into memory. This can take a minute and PicoSurf may pause.");
    const model = allModels.find((item) => item.id === modelId);
    setProgress({
      modelId,
      phase: "load",
      received: 0,
      total: model?.sizeBytes ?? 1,
      message: "Loading into memory…",
    });
    try {
      if (!isTauri()) {
        setNotice("Preview only. Load runs in the Windows app.");
        return;
      }
      const list = await modelsLoad(modelId);
      applyList(list);
      setProgress(null);
      setNotice("Model is ready. Chat is on.");
    } catch (err) {
      setProgress(null);
      setNotice(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function pickMoreModel(model: ModelInfo) {
    setShowMore(false);
    await onChange(model.id);
  }

  const percent =
    progress && progress.total > 0 ? Math.min(100, Math.round((progress.received / progress.total) * 100)) : 0;

  return (
    <div className="model-select">
      <label className="model-label" htmlFor="model-dropdown">
        Model
      </label>
      <select
        id="model-dropdown"
        className="model-dropdown"
        value={selectedId ?? ""}
        disabled={busy}
        onChange={(event) => {
          const value = event.target.value;
          if (value) void onChange(value);
        }}
      >
        <option value="" disabled>
          Choose a local model
        </option>
        {dropdownModels.map((model) => (
          <option key={model.id} value={model.id}>
            {model.displayName}
            {model.recommended ? " · recommended" : ""}
            {model.status === "not_downloaded" ? " · not downloaded" : ""}
            {model.status === "downloaded" ? " · on disk" : ""}
            {model.status === "ready" ? " · ready" : ""}
          </option>
        ))}
      </select>
      {moreModels.length > 0 ? (
        <div className="model-more">
          <button
            type="button"
            className="btn ghost model-more-toggle"
            disabled={busy}
            aria-expanded={showMore}
            onClick={() => setShowMore((open) => !open)}
          >
            {showMore ? "Hide extra models" : `Show more models (${moreModels.length})`}
          </button>
          {showMore ? (
            <ul className="model-more-list">
              {moreModels.map((model) => (
                <li key={model.id}>
                  <button
                    type="button"
                    className={`model-more-item${selectedId === model.id ? " is-selected" : ""}`}
                    disabled={busy}
                    onClick={() => void pickMoreModel(model)}
                  >
                    <span className="model-more-name">{model.displayName}</span>
                    <span className="model-more-meta">
                      {model.sizeLabel} · {model.ramHint} RAM · {model.quantization}
                      {model.status === "ready"
                        ? " · ready"
                        : model.status === "downloaded"
                          ? " · on disk"
                          : " · not downloaded"}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      ) : null}
      {selected ? (
        <p className="model-meta">
          {selected.sizeLabel} · {selected.ramHint} RAM · {selected.quantization}
          {loadedId === selected.id ? " · loaded" : ""}
        </p>
      ) : (
        <p className="model-meta">No model loaded. Chat stays off until a model is ready.</p>
      )}
      {hardware ? (
        <p className="model-meta">
          This PC: {hardware.ramLabel} RAM · {hardware.cpuCores} cores · {hardware.storageLabel} free
        </p>
      ) : null}
      {configPath ? (
        <p className="model-meta">Extra models from {configPath}</p>
      ) : null}
      {progress ? (
        <div className="model-progress">
          <div className="model-progress-bar" style={{ width: `${percent}%` }} />
          <p>
            {progress.message} {percent}%
          </p>
          <button type="button" className="btn ghost" onClick={() => void modelsCancel()}>
            Cancel
          </button>
        </div>
      ) : null}
      {notice ? <p className="model-notice">{notice}</p> : null}
      {pending ? (
        <div className="model-confirm" role="dialog" aria-labelledby="model-confirm-title">
          <h2 id="model-confirm-title">Download this model?</h2>
          <p>
            {pending.displayName} is {pending.sizeLabel} and wants about {pending.ramHint} of RAM.
            PicoSurf will fetch it from Hugging Face over HTTPS, check SHA-256, then load it. The
            file stays on this PC.
          </p>
          <div className="model-confirm-actions">
            <button type="button" className="btn ghost" onClick={() => setPending(null)}>
              Cancel
            </button>
            <button
              type="button"
              className="btn primary"
              disabled={!downloadEnabled || busy}
              onClick={() => void confirmDownload()}
            >
              Download
            </button>
          </div>
        </div>
      ) : selected && !progress ? (
        <div className="model-confirm-actions">
          {selected.status === "not_downloaded" ? (
            <button
              type="button"
              className="btn primary"
              disabled={busy}
              onClick={() => setPending(selected)}
            >
              Download {selected.sizeLabel}
            </button>
          ) : null}
          {selected.status === "downloaded" ? (
            <button
              type="button"
              className="btn primary"
              disabled={busy}
              onClick={() => void loadOnDisk(selected.id)}
            >
              Load into memory
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
