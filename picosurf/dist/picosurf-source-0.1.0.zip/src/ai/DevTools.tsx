import { FormEvent, useEffect, useState } from "react";
import {
  adBlockRefresh,
  adBlockStatus,
  agentLimitsGet,
  agentLimitsSet,
  settingsGet,
  settingsSet,
} from "../browser/api";
import { isTauri } from "../browser/tauriEnv";
import type {
  AdBlockStatus,
  AgentLimits,
  AgentStructureLevel,
  AppSettings,
} from "../types/ipc";
import { AgentFlowsPanel } from "./AgentFlowsPanel";
import { PageInspect } from "./PageInspect";

const DEFAULT_LIMITS: AgentLimits = {
  maxActions: 8,
  maxNavigations: 3,
  maxRuntimeSecs: 90,
};

export function DevToolsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <aside
      className={`dev-panel${open ? " is-open" : ""}`}
      aria-hidden={!open}
      inert={!open}
      aria-label="PicoSurf developer tools"
    >
      <header className="ai-header">
        <div>
          <h1>DevTools</h1>
          <p>Inspect elements, configure custom agent flows, search, and assistant limits.</p>
        </div>
        <button type="button" className="btn ghost" onClick={onClose}>
          Hide
        </button>
      </header>
      <AgentFlowsPanel open={open} />
      <SearchSettingsForm open={open} />
      <AdBlockForm open={open} />
      <AgentLimitsForm />
      <AgentStructureForm />
      <PageInspect />
    </aside>
  );
}

function AgentLimitsForm() {
  const [limits, setLimits] = useState<AgentLimits>(DEFAULT_LIMITS);
  const [message, setMessage] = useState("These limits apply to the AI page-action loop.");

  useEffect(() => {
    if (!isTauri()) return;
    void agentLimitsGet()
      .then(setLimits)
      .catch((err: unknown) => setMessage(err instanceof Error ? err.message : String(err)));
  }, []);

  async function save(event: FormEvent) {
    event.preventDefault();
    const next: AgentLimits = {
      maxActions: Number(limits.maxActions) || DEFAULT_LIMITS.maxActions,
      maxNavigations: Number(limits.maxNavigations) || DEFAULT_LIMITS.maxNavigations,
      maxRuntimeSecs: Number(limits.maxRuntimeSecs) || DEFAULT_LIMITS.maxRuntimeSecs,
    };
    try {
      if (!isTauri()) {
        setLimits(next);
        setMessage("Preview only. Limits apply in the Windows app.");
        return;
      }
      const saved = await agentLimitsSet(next);
      setLimits(saved);
      setMessage(
        `Saved: ${saved.maxActions} actions, ${saved.maxNavigations} navigations, ${saved.maxRuntimeSecs}s.`,
      );
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  return (
    <form className="agent-limits" onSubmit={(event) => void save(event)}>
      <h2>Assistant limits</h2>
      <p className="inspect-meta">{message}</p>
      <label>
        Max actions
        <input
          type="number"
          min={1}
          max={40}
          value={limits.maxActions}
          onChange={(event) =>
            setLimits((current) => ({ ...current, maxActions: Number(event.target.value) }))
          }
        />
      </label>
      <label>
        Max navigations
        <input
          type="number"
          min={1}
          max={20}
          value={limits.maxNavigations}
          onChange={(event) =>
            setLimits((current) => ({ ...current, maxNavigations: Number(event.target.value) }))
          }
        />
      </label>
      <label>
        Time limit (seconds)
        <input
          type="number"
          min={15}
          max={600}
          value={limits.maxRuntimeSecs}
          onChange={(event) =>
            setLimits((current) => ({ ...current, maxRuntimeSecs: Number(event.target.value) }))
          }
        />
      </label>
      <button type="submit" className="btn primary">
        Save limits
      </button>
    </form>
  );
}

const DEFAULT_SETTINGS: AppSettings = {
  search: {
    engine: "duckduckgo",
    researchEngine: "same",
    customTemplate: "",
  },
  research: {
    maxQueries: 5,
    maxResultsPerQuery: 10,
    maxPages: 8,
    maxDepth: 3,
    maxRuntimeSecs: 120,
    maxExtractChars: 1800,
  },
  aiEnabled: true,
  saveWithAiEnabled: true,
  agentLimits: DEFAULT_LIMITS,
  agentStructureLevel: "standard",
  assistantMode: "research",
  historyEnabled: true,
  aiHistoryEnabled: false,
  adBlockEnabled: false,
  customFlowId: null,
};

function AgentStructureForm() {
  const [level, setLevel] = useState<AgentStructureLevel>("standard");
  const [message, setMessage] = useState(
    "Structured visible outline sent to the agent for replanning and next actions.",
  );

  useEffect(() => {
    if (!isTauri()) return;
    void settingsGet()
      .then((settings) => setLevel(settings.agentStructureLevel ?? "standard"))
      .catch((err: unknown) => setMessage(err instanceof Error ? err.message : String(err)));
  }, []);

  async function save(event: FormEvent) {
    event.preventDefault();
    try {
      if (!isTauri()) {
        setMessage("Preview only. Structure level applies in the Windows app.");
        return;
      }
      const current = await settingsGet();
      const saved = await settingsSet({ ...current, agentStructureLevel: level });
      setLevel(saved.agentStructureLevel ?? "standard");
      setMessage(`Saved agent structure level: ${saved.agentStructureLevel}.`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  return (
    <form className="agent-limits" onSubmit={(event) => void save(event)}>
      <h2>Agent page structure</h2>
      <p className="inspect-meta">{message}</p>
      <label>
        Visible structure for LLM
        <select
          value={level}
          onChange={(event) => setLevel(event.target.value as AgentStructureLevel)}
        >
          <option value="off">Off — text snippet and element list only</option>
          <option value="minimal">Minimal — page kind, headings, counts</option>
          <option value="standard">Standard — landmarks, links, fields (recommended)</option>
          <option value="detailed">Detailed — more links, buttons, rows</option>
        </select>
      </label>
      <button type="submit" className="btn primary">
        Save structure level
      </button>
    </form>
  );
}

function patchSettings(
  current: AppSettings | null,
  patch: (settings: AppSettings) => AppSettings,
): AppSettings | null {
  return current ? patch(current) : current;
}

function SearchSettingsForm({ open }: { open: boolean }) {
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [message, setMessage] = useState(
    "Normal address-bar search uses this engine. AI research can use the same one or another.",
  );

  useEffect(() => {
    if (!isTauri() || !open) return;
    setSettings(null);
    void settingsGet()
      .then((loaded) => {
        setSettings(loaded);
        setMessage(
          `Active: ${formatEngine(loaded.search.engine)} search` +
            (loaded.search.researchEngine === "same"
              ? " (research uses the same engine)"
              : ` · research: ${formatEngine(loaded.search.researchEngine)}`) +
            ". Results use English (hl=en / en-us).",
        );
      })
      .catch((err: unknown) => {
        setSettings(DEFAULT_SETTINGS);
        setMessage(err instanceof Error ? err.message : String(err));
      });
  }, [open]);

  async function save(event: FormEvent) {
    event.preventDefault();
    if (!settings) return;
    try {
      if (!isTauri()) {
        setMessage("Preview only. Search settings apply in the Windows app.");
        return;
      }
      const saved = await settingsSet(settings);
      setSettings(saved);
      setMessage(
        `Saved ${formatEngine(saved.search.engine)} search` +
          (saved.search.researchEngine === "same"
            ? " (research uses the same engine)."
            : ` · research: ${formatEngine(saved.search.researchEngine)}.`),
      );
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  const showCustom =
    settings?.search.engine === "custom" || settings?.search.researchEngine === "custom";

  if (!settings) {
    return (
      <form className="agent-limits">
        <h2>Search</h2>
        <p className="inspect-meta">{message}</p>
        <p className="inspect-meta">Loading search settings…</p>
      </form>
    );
  }

  return (
    <form className="agent-limits" onSubmit={(event) => void save(event)}>
      <h2>Search</h2>
      <p className="inspect-meta">{message}</p>
      <label>
        Default search engine
        <select
          value={settings.search.engine}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({
                ...loaded,
                search: { ...loaded.search, engine: event.target.value },
              })),
            )
          }
        >
          <option value="duckduckgo">DuckDuckGo</option>
          <option value="google">Google</option>
          <option value="bing">Bing</option>
          <option value="brave">Brave Search</option>
          <option value="custom">Custom</option>
        </select>
      </label>
      <label>
        AI research search engine
        <select
          value={settings.search.researchEngine}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({
                ...loaded,
                search: { ...loaded.search, researchEngine: event.target.value },
              })),
            )
          }
        >
          <option value="same">Same as default</option>
          <option value="duckduckgo">DuckDuckGo</option>
          <option value="google">Google</option>
          <option value="bing">Bing</option>
          <option value="brave">Brave Search</option>
          <option value="custom">Custom</option>
        </select>
      </label>
      {showCustom ? (
        <label>
          Custom search URL ({"{query}"})
          <input
            value={settings.search.customTemplate}
            placeholder="https://example.com/search?q={query}"
            onChange={(event) =>
              setSettings((current) =>
                patchSettings(current, (loaded) => ({
                  ...loaded,
                  search: { ...loaded.search, customTemplate: event.target.value },
                })),
              )
            }
          />
        </label>
      ) : null}
      <label>
        Max research queries
        <input
          type="number"
          min={1}
          max={8}
          value={settings.research.maxQueries}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({
                ...loaded,
                research: { ...loaded.research, maxQueries: Number(event.target.value) },
              })),
            )
          }
        />
      </label>
      <label>
        Max pages opened
        <input
          type="number"
          min={1}
          max={15}
          value={settings.research.maxPages}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({
                ...loaded,
                research: { ...loaded.research, maxPages: Number(event.target.value) },
              })),
            )
          }
        />
      </label>
      <label>
        Research time limit (seconds)
        <input
          type="number"
          min={30}
          max={600}
          value={settings.research.maxRuntimeSecs}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({
                ...loaded,
                research: { ...loaded.research, maxRuntimeSecs: Number(event.target.value) },
              })),
            )
          }
        />
      </label>
      <label className="ai-include-page">
        <input
          type="checkbox"
          checked={settings.aiEnabled}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({ ...loaded, aiEnabled: event.target.checked })),
            )
          }
        />
        AI enabled (address bar research)
      </label>
      <label className="ai-include-page">
        <input
          type="checkbox"
          checked={settings.saveWithAiEnabled}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({
                ...loaded,
                saveWithAiEnabled: event.target.checked,
              })),
            )
          }
        />
        Save with AI
      </label>
      <label className="ai-include-page">
        <input
          type="checkbox"
          checked={settings.adBlockEnabled}
          onChange={(event) =>
            setSettings((current) =>
              patchSettings(current, (loaded) => ({
                ...loaded,
                adBlockEnabled: event.target.checked,
              })),
            )
          }
        />
        Block ads and trackers (network only, EasyList)
      </label>
      <button type="submit" className="btn primary" disabled={!settings}>
        Save search settings
      </button>
    </form>
  );
}

function AdBlockForm({ open }: { open: boolean }) {
  const [status, setStatus] = useState<AdBlockStatus | null>(null);
  const [message, setMessage] = useState("Loads EasyList + EasyPrivacy; refreshes about every 24 hours.");

  useEffect(() => {
    if (!isTauri() || !open) return;
    setStatus(null);
    void adBlockStatus()
      .then(setStatus)
      .catch((err: unknown) => setMessage(err instanceof Error ? err.message : String(err)));
  }, [open]);

  async function refresh() {
    if (!isTauri()) {
      setMessage("Preview only. Ad block runs in the Windows app.");
      return;
    }
    setMessage("Downloading filter lists…");
    try {
      const next = await adBlockRefresh();
      setStatus((current) =>
        current
          ? { ...current, ruleHosts: next.ruleHosts, updatedAt: next.updatedAt, sources: next.sources }
          : { enabled: false, ...next },
      );
      setMessage("Filter lists updated.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  const updatedLabel =
    status && status.updatedAt > 0
      ? new Date(status.updatedAt * 1000).toLocaleString()
      : "Not downloaded yet";

  return (
    <section className="agent-limits">
      <h2>Ad block</h2>
      <p className="inspect-meta">{message}</p>
      {status ? (
        <p className="inspect-meta">
          {status.enabled ? "On" : "Off"} · {status.ruleHosts.toLocaleString()} blocked hosts · updated{" "}
          {updatedLabel}
          {status.sources.length > 0 ? ` · ${status.sources.join(", ")}` : ""}
        </p>
      ) : (
        <p className="inspect-meta">Loading filter status…</p>
      )}
      <button type="button" className="btn ghost" onClick={() => void refresh()}>
        Update filters now
      </button>
    </section>
  );
}

function formatEngine(id: string): string {
  switch (id) {
    case "google":
      return "Google";
    case "bing":
      return "Bing";
    case "brave":
      return "Brave";
    case "custom":
      return "Custom";
    default:
      return "DuckDuckGo";
  }
}
