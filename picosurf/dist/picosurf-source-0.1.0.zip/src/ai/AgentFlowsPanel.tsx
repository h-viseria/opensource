import { FormEvent, useEffect, useMemo, useState } from "react";
import {
  agentFlowsDelete,
  agentFlowsGet,
  agentFlowsList,
  agentFlowsSave,
  settingsGet,
  settingsSet,
} from "../browser/api";
import { isTauri } from "../browser/tauriEnv";
import type {
  AgentFlow,
  AgentFlowConfig,
  AgentFlowSummary,
  DiscoveryMode,
  PipelineNode,
  PipelineNodeId,
  SynthesisFormat,
} from "../types/ipc";

const PIPELINE_META: { id: PipelineNodeId; label: string; description: string }[] = [
  { id: "discover", label: "Discover", description: "Find candidate websites via search." },
  { id: "selectSites", label: "Select sites", description: "Pick specialist domains from results." },
  { id: "searchAndVisit", label: "Search & visit", description: "Run scoped searches and open pages." },
  { id: "extract", label: "Extract", description: "Read text from each opened page." },
  { id: "pageAgent", label: "In-page pass", description: "Re-open pages for a deeper extract pass." },
  { id: "synthesize", label: "Synthesize", description: "Compare evidence and draft the answer." },
  { id: "report", label: "Report", description: "Publish the local HTML report." },
];

function newFlow(name: string): AgentFlow {
  return {
    id: "",
    name,
    schemaVersion: 1,
    createdAt: 0,
    updatedAt: 0,
    config: defaultConfig(),
  };
}

function defaultConfig(): AgentFlowConfig {
  return {
    pipeline: PIPELINE_META.map((node) => ({
      id: node.id,
      enabled: node.id !== "pageAgent",
      hint: node.description,
    })),
    discovery: {
      mode: "searchThenPickSites",
      hint: "",
      queryTemplates: ["site:{domain} {subject}"],
    },
    sources: {
      pinnedDomains: [],
      maxSites: 4,
    },
    extract: {
      fields: [{ label: "Key facts", hint: "Prices, specs, dates, or ratings." }],
      hint: "",
    },
    synthesize: {
      format: "comparisonTable",
      hint: "",
      reportLabel: "Custom research",
    },
    pageAgent: {
      enabled: false,
      perSite: true,
      goalTemplate: "On {domain}, continue: {goal}. Focus on {fields}.",
      hint: "",
    },
  };
}

function flowPreview(flow: AgentFlow): string[] {
  const enabled = new Set(
    flow.config.pipeline.filter((node) => node.enabled).map((node) => node.id),
  );
  const lines: string[] = [];
  if (enabled.has("discover")) {
    lines.push(`Discovery: ${flow.config.discovery.mode}`);
  }
  if (flow.config.sources.pinnedDomains.length > 0) {
    lines.push(`Pinned: ${flow.config.sources.pinnedDomains.join(", ")}`);
  }
  lines.push(`Up to ${flow.config.sources.maxSites} sites`);
  if (enabled.has("extract")) {
    lines.push(
      `Extract: ${flow.config.extract.fields.map((field) => field.label).join(", ") || "Key facts"}`,
    );
  }
  if (enabled.has("pageAgent") && flow.config.pageAgent.enabled) {
    lines.push("In-page pass: on after main extract");
  }
  lines.push(`Output: ${flow.config.synthesize.format} (${flow.config.synthesize.reportLabel})`);
  return lines;
}

export function AgentFlowsPanel({ open }: { open: boolean }) {
  const [flows, setFlows] = useState<AgentFlowSummary[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [draft, setDraft] = useState<AgentFlow | null>(null);
  const [message, setMessage] = useState("Define structured agent flows (stored locally).");
  const [activeFlowId, setActiveFlowId] = useState<string | null>(null);

  useEffect(() => {
    if (!isTauri() || !open) return;
    void refreshList();
    void settingsGet()
      .then((settings) => setActiveFlowId(settings.customFlowId))
      .catch(() => setActiveFlowId(null));
  }, [open]);

  async function refreshList(selectId?: string) {
    try {
      const list = await agentFlowsList();
      setFlows(list);
      const pick = selectId ?? selectedId ?? list[0]?.id ?? null;
      setSelectedId(pick);
      if (pick) {
        const loaded = await agentFlowsGet(pick);
        setDraft(loaded ?? newFlow("Untitled flow"));
      } else {
        setDraft(null);
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function selectFlow(id: string) {
    setSelectedId(id);
    try {
      const loaded = await agentFlowsGet(id);
      setDraft(loaded ?? newFlow("Untitled flow"));
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  function updateDraft(patch: (flow: AgentFlow) => AgentFlow) {
    setDraft((current) => (current ? patch(current) : current));
  }

  function updatePipeline(nodeId: PipelineNodeId, patch: (node: PipelineNode) => PipelineNode) {
    updateDraft((flow) => ({
      ...flow,
      config: {
        ...flow.config,
        pipeline: flow.config.pipeline.map((node) => (node.id === nodeId ? patch(node) : node)),
      },
    }));
  }

  async function saveFlow(event: FormEvent) {
    event.preventDefault();
    if (!draft) return;
    try {
      const saved = await agentFlowsSave(draft);
      setDraft(saved);
      setMessage(`Saved “${saved.name}”.`);
      await refreshList(saved.id);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function createFlow() {
    const draftFlow = newFlow(`Flow ${flows.length + 1}`);
    try {
      const saved = await agentFlowsSave(draftFlow);
      setMessage(`Created “${saved.name}”.`);
      await refreshList(saved.id);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function removeFlow() {
    if (!selectedId) return;
    try {
      await agentFlowsDelete(selectedId);
      if (activeFlowId === selectedId) {
        const settings = await settingsGet();
        await settingsSet({
          ...settings,
          assistantMode: "research",
          customFlowId: null,
        });
        setActiveFlowId(null);
      }
      setMessage("Flow deleted.");
      await refreshList();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  async function useInAssistant() {
    if (!draft?.id) return;
    try {
      const settings = await settingsGet();
      await settingsSet({
        ...settings,
        assistantMode: "custom",
        customFlowId: draft.id,
      });
      setActiveFlowId(draft.id);
      setMessage(`Assistant mode set to custom flow “${draft.name}”.`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : String(err));
    }
  }

  const preview = useMemo(() => (draft ? flowPreview(draft) : []), [draft]);

  if (!open) return null;

  return (
    <section className="agent-flows agent-limits">
      <h2>Custom agent flows</h2>
      <p className="inspect-meta">{message}</p>

      <div className="flow-toolbar">
        <button type="button" className="btn ghost" onClick={() => void createFlow()}>
          New flow
        </button>
        {selectedId ? (
          <button type="button" className="btn ghost" onClick={() => void removeFlow()}>
            Delete
          </button>
        ) : null}
        {draft?.id ? (
          <button type="button" className="btn primary" onClick={() => void useInAssistant()}>
            Use in assistant
          </button>
        ) : null}
      </div>

      <label>
        Saved flows
        <select
          value={selectedId ?? ""}
          onChange={(event) => void selectFlow(event.target.value)}
        >
          {flows.length === 0 ? <option value="">No flows yet</option> : null}
          {flows.map((flow) => (
            <option key={flow.id} value={flow.id}>
              {flow.name}
              {activeFlowId === flow.id ? " (active)" : ""}
            </option>
          ))}
        </select>
      </label>

      {!draft ? (
        <p className="inspect-meta">Create a flow to configure the pipeline.</p>
      ) : (
        <form className="flow-form" onSubmit={(event) => void saveFlow(event)}>
          <label>
            Flow name
            <input
              value={draft.name}
              onChange={(event) =>
                updateDraft((flow) => ({ ...flow, name: event.target.value }))
              }
              required
              minLength={2}
              maxLength={80}
            />
          </label>

          <h3>Pipeline</h3>
          <ol className="flow-pipeline">
            {PIPELINE_META.map((meta) => {
              const node = draft.config.pipeline.find((item) => item.id === meta.id);
              if (!node) return null;
              return (
                <li key={meta.id} className={node.enabled ? "is-on" : "is-off"}>
                  <label className="flow-node-head">
                    <input
                      type="checkbox"
                      checked={node.enabled}
                      onChange={(event) =>
                        updatePipeline(meta.id, (current) => ({
                          ...current,
                          enabled: event.target.checked,
                        }))
                      }
                    />
                    <span>{meta.label}</span>
                  </label>
                  <p className="inspect-meta">{meta.description}</p>
                  <input
                    type="text"
                    placeholder="Step hint (optional)"
                    value={node.hint}
                    onChange={(event) =>
                      updatePipeline(meta.id, (current) => ({
                        ...current,
                        hint: event.target.value,
                      }))
                    }
                  />
                </li>
              );
            })}
          </ol>

          <h3>Discovery & sources</h3>
          <label>
            Discovery mode
            <select
              value={draft.config.discovery.mode}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    discovery: {
                      ...flow.config.discovery,
                      mode: event.target.value as DiscoveryMode,
                    },
                  },
                }))
              }
            >
              <option value="openWeb">Open web search</option>
              <option value="pinnedDomainsOnly">Pinned domains only</option>
              <option value="searchThenPickSites">Search, then pick sites</option>
            </select>
          </label>
          <label>
            Discovery hint (retailer domains/names are parsed here)
            <input
              value={draft.config.discovery.hint}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    discovery: { ...flow.config.discovery, hint: event.target.value },
                  },
                }))
              }
              placeholder="e.g. Find on amazon.in, flipkart, jiomart"
            />
          </label>
          <label>
            Query templates (one per line; tokens: {"{goal}"}, {"{domain}"}, {"{subject}"})
            <textarea
              rows={3}
              value={draft.config.discovery.queryTemplates.join("\n")}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    discovery: {
                      ...flow.config.discovery,
                      queryTemplates: event.target.value
                        .split("\n")
                        .map((line) => line.trim())
                        .filter(Boolean),
                    },
                  },
                }))
              }
            />
          </label>
          <label>
            Pinned domains (comma-separated hostnames)
            <input
              value={draft.config.sources.pinnedDomains.join(", ")}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    sources: {
                      ...flow.config.sources,
                      pinnedDomains: event.target.value
                        .split(/[,;\s]+/)
                        .map((item) => item.trim())
                        .filter(Boolean),
                    },
                  },
                }))
              }
            />
          </label>
          <label>
            Max sites
            <input
              type="number"
              min={1}
              max={8}
              value={draft.config.sources.maxSites}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    sources: {
                      ...flow.config.sources,
                      maxSites: Number(event.target.value),
                    },
                  },
                }))
              }
            />
          </label>

          <h3>Extraction</h3>
          {draft.config.extract.fields.map((field, index) => (
            <div key={index} className="flow-field-row">
              <input
                placeholder="Field label"
                value={field.label}
                onChange={(event) =>
                  updateDraft((flow) => {
                    const fields = [...flow.config.extract.fields];
                    fields[index] = { ...fields[index], label: event.target.value };
                    return {
                      ...flow,
                      config: {
                        ...flow.config,
                        extract: { ...flow.config.extract, fields },
                      },
                    };
                  })
                }
              />
              <input
                placeholder="Hint for the model"
                value={field.hint}
                onChange={(event) =>
                  updateDraft((flow) => {
                    const fields = [...flow.config.extract.fields];
                    fields[index] = { ...fields[index], hint: event.target.value };
                    return {
                      ...flow,
                      config: {
                        ...flow.config,
                        extract: { ...flow.config.extract, fields },
                      },
                    };
                  })
                }
              />
              <button
                type="button"
                className="btn ghost"
                onClick={() =>
                  updateDraft((flow) => ({
                    ...flow,
                    config: {
                      ...flow.config,
                      extract: {
                        ...flow.config.extract,
                        fields: flow.config.extract.fields.filter((_, i) => i !== index),
                      },
                    },
                  }))
                }
              >
                Remove
              </button>
            </div>
          ))}
          <button
            type="button"
            className="btn ghost"
            onClick={() =>
              updateDraft((flow) => ({
                ...flow,
                config: {
                  ...flow.config,
                  extract: {
                    ...flow.config.extract,
                    fields: [...flow.config.extract.fields, { label: "New field", hint: "" }],
                  },
                },
              }))
            }
          >
            Add field
          </button>

          <h3>Synthesis & report</h3>
          <label>
            Output format
            <select
              value={draft.config.synthesize.format}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    synthesize: {
                      ...flow.config.synthesize,
                      format: event.target.value as SynthesisFormat,
                    },
                  },
                }))
              }
            >
              <option value="bullets">Bullets</option>
              <option value="numberedList">Numbered list</option>
              <option value="comparisonTable">Comparison table</option>
              <option value="executiveSummary">Executive summary</option>
            </select>
          </label>
          <label>
            Report label
            <input
              value={draft.config.synthesize.reportLabel}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    synthesize: {
                      ...flow.config.synthesize,
                      reportLabel: event.target.value,
                    },
                  },
                }))
              }
            />
          </label>
          <label>
            Synthesis hint
            <input
              value={draft.config.synthesize.hint}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    synthesize: { ...flow.config.synthesize, hint: event.target.value },
                  },
                }))
              }
            />
          </label>

          <h3>In-page pass (optional)</h3>
          <label className="ai-include-page">
            <input
              type="checkbox"
              checked={draft.config.pageAgent.enabled}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    pageAgent: {
                      ...flow.config.pageAgent,
                      enabled: event.target.checked,
                    },
                  },
                }))
              }
            />
            Run a deeper pass on each visited site
          </label>
          <label className="ai-include-page">
            <input
              type="checkbox"
              checked={draft.config.pageAgent.perSite}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    pageAgent: {
                      ...flow.config.pageAgent,
                      perSite: event.target.checked,
                    },
                  },
                }))
              }
            />
            Per site (otherwise first site only)
          </label>
          <label>
            Goal template
            <input
              value={draft.config.pageAgent.goalTemplate}
              onChange={(event) =>
                updateDraft((flow) => ({
                  ...flow,
                  config: {
                    ...flow.config,
                    pageAgent: {
                      ...flow.config.pageAgent,
                      goalTemplate: event.target.value,
                    },
                  },
                }))
              }
            />
          </label>

          <div className="flow-preview">
            <h3>Preview</h3>
            <ul>
              {preview.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>

          <button type="submit" className="btn primary">
            Save flow
          </button>
        </form>
      )}
    </section>
  );
}
