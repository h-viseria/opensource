# PicoSurf architecture

PicoSurf is a privacy-first lightweight browser with an optional local AI assistant.

This document is the source of truth for process boundaries, trust, and IPC. Later phases must not weaken these rules.

## Product shape (Phase 6)

- Windows only.
- One portable-style app window. No account, no telemetry, no cloud AI.
- The AI sidebar is closed by default. Browsing works with no model downloaded.
- After you confirm, PicoSurf downloads a catalogue GGUF over HTTPS, verifies SHA-256, then loads it with llama.cpp in-process. There is no Ollama, Python, or cloud LLM.
- Chat can summarize and answer questions about the current page. Rust copies visible page text into a delimited untrusted block. It is never concatenated into system instructions. The chrome UI cannot supply the page body.
- With **Allow page actions**, a bounded Rust agent loop can inspect, click, type, scroll, and navigate. The model proposes one JSON action; Rust validates and executes it. Dangerous clicks, password fields, and login/checkout URLs pause for confirmation. There are no silent purchases.
- **Research** reuses that same `browser` WebView. PicoSurf builds a search URL for the configured engine (no search API), extracts results with a frozen helper, opens a few pages, and synthesizes locally. The answer is rendered as a temporary local HTML report and opened in the main view; the AI sidebar shows only a short status line. Source URLs are recorded in Rust; the model cannot invent citations.
- There is a single page WebView today (no tabs). Research navigation replaces the current page; Back still works. Prefix the address bar with `?` to force a normal search without AI.
- **Save with AI** stores URL, title, domain, date, local summary, and tags as JSON under the app data dir. Later “what did I save about …” is a local text search.
- Page inspect / click / type / scroll also live in a **DevTools** sidebar, closed by default, separate from the AI chat. Search engine and research limits are there too. There is no `execute_javascript` command for the AI.
- If WebView2 is missing, a native dialog appears before any window is created.

## Process boundaries

```
PicoSurf.exe
  ├── Native startup (Rust)
  │     └── WebView2 presence check (no UI webview yet)
  ├── Window `main` (Win32)
  │     ├── WebView `chrome`   TRUSTED    React UI (toolbar, address bar, AI panel)
  │     └── WebView `browser`  UNTRUSTED  System WebView2 page content
  └── Local files (user-writable)
        ├── settings / preferences
        └── models/   (Phase 3+)
```

There is no helper server, no Ollama, no Python runtime, and no cloud LLM.

The React UI and the visited website do not share a DOM. They are sibling WebViews. The site is never loaded in an iframe of the chrome UI.

## WebView trust boundary

| Surface | Label | Origin | Trust |
|---|---|---|---|
| Toolbar, address bar, AI sidebar, privacy panel | `chrome` | Tauri app origin | Trusted |
| Visited websites | `browser` | `http` / `https` / `about` | Untrusted |

The `browser` WebView must never have Tauri command permissions.

Do not grant capabilities with `"windows": ["main"]`. In Tauri 2 that would apply to every child WebView of the window, including `browser`. Capabilities for chrome must list `"webviews": ["chrome"]` and omit `windows`.

Remote pages must not be listed in capability `remote` allowlists.

Web content, PDFs, images, downloads, and page JavaScript are treated as hostile. They must not reach:

- filesystem
- shell
- arbitrary Rust functions
- the AI model except when the user asks to include the page (Rust copies visible text as untrusted data)
- application database
- credentials
- OS APIs

Only explicit Tauri commands on `chrome` may cross into Rust.

## Tauri capabilities

Phase 6 capability file: `src-tauri/capabilities/chrome.json`.

Allowed for `chrome` only:

- `core:default` (events, app metadata)
- app commands listed below

Not enabled:

- shell / process execution
- arbitrary filesystem
- HTTP from the frontend
- `core:webview` create/close of extra privileged webviews
- any permission on webview `browser`

`tauri-build` AppManifest lists every custom command so they are not implicitly allowed on all webviews.

## IPC commands (Phase 6)

All commands are invoked only from `chrome`. Rust still re-validates arguments.

| Command | Purpose |
|---|---|
| `browser_navigate` | Load an allowlisted URL in the `browser` WebView |
| `browser_back` | History back |
| `browser_forward` | History forward |
| `browser_reload` | Reload current page |
| `browser_state` | Current URL, title, back/forward flags |
| `browser_inspect` | Snapshot visible interactive elements; assign integer IDs |
| `browser_page_info` | Last inspect page metadata (URL, origin, generation) |
| `browser_click` | Click an element by ID after origin/generation checks |
| `browser_type` | Type into a text field by ID |
| `browser_scroll` | Scroll the page (up/down/left/right/top/bottom) |
| `browser_screenshot` | Viewport metrics only (no pixel capture in this phase) |
| `layout_sync` | Position the `browser` WebView under the toolbar and beside the AI panel |
| `models_list` | Catalogue, on-disk status, loaded model, hardware hints |
| `models_select` | Record the selected model; reports whether a download is needed |
| `models_download` | HTTPS download of catalogue files only; SHA-256 verified |
| `models_cancel` | Cancel an in-flight download or generation |
| `models_load` | Load a verified GGUF into llama.cpp |
| `models_unload` | Drop the loaded model from memory |
| `ai_generate` | Stream a local completion; optional `attachPage` copies current page text in Rust |
| `ai_task` | Start a bounded page-action loop for a user goal |
| `ai_confirm` | Resume the loop after the user confirms a dangerous step |
| `ai_stop` | Stop generation and cancel any agent or research task |
| `agent_limits_get` / `agent_limits_set` | Page-action loop limits |
| `settings_get` / `settings_set` | Search engine, research engine/template/limits, AI and Save-with-AI toggles |
| `omnibox_interpret` | Address-bar: URL, normal search, research, summarize, save (AI optional) |
| `saved_list` / `saved_search` | Local saved-page JSON (no network) |
| `save_with_ai` | Summarize the current page locally and store it |

Events (Rust → chrome only):

- `browser-state` — URL, title, canGoBack, canGoForward after navigations
- `model-progress` — download / verify / load progress
- `ai-status` — reading page / choosing a step / acting (no hidden chain-of-thought)
- `ai-token` — streamed token text (chat only; agent JSON is not streamed)
- `ai-confirm` — dangerous click, password type, or login/checkout navigate needs a human
- `ai-done` — generation finished

No `execute_javascript` command exists. None will be added for the AI. Page scripts used for inspect/click/type/scroll/read are frozen helpers in Rust, not caller-supplied JavaScript. The frontend cannot supply a model URL or the page body used for Q&A; only a boolean `attachPage` flag. Agent actions are JSON from the model; Rust ignores caller-supplied CSS selectors, JavaScript, file paths, and element generations.

## Navigation policy

The `browser` WebView may only navigate to:

- `https:`
- `http:`
- `about:blank`
- `http://picosurf-research.localhost/…` (local HTML reports generated on this device; served by Rust from app data, not writable by webpages)

Blocked: `file:`, `javascript:`, `data:`, `tauri:`, other custom schemes, and any other scheme.

Typed input that is not a URL is sent to the **configured** search engine (default DuckDuckGo HTML search). A custom template must contain `{query}` and be `http`/`https` only.

Research uses the same allowlist. Search-result redirect wrappers (`uddg=`, Google `/url?q=`) are unwrapped in Rust; `file:`, `javascript:`, and `data:` results are dropped.

`target=_blank` / new-window requests stay in the same `browser` WebView (single page).

## AI runtime (Phase 6)

llama.cpp is embedded behind `InferenceEngine` (`load_model`, `unload_model`, `generate`, `generate_cfg`, `is_loaded`, `model_info`).

Rules:

- Local only. No Ollama, no cloud API, no Python, no Tavily/Google/Bing/Brave search APIs.
- The model is untrusted. Chat (`ai_generate`) may only produce text. Page tasks (`ai_task`) may only propose JSON from a fixed action list: inspect, navigate, click, type, scroll, back, forward, reload, done, ask. There is no `research_web` model action; Rust orchestrates research so small models cannot drive an unbounded crawl.
- Rust parses that JSON, rejects extra/forbidden keys (JavaScript, selectors, file paths, shell, unknown fields), and executes through the same browser broker as DevTools. Navigate still goes through `security::normalize_input` / the configured search engine.
- Agent limits default to 8 actions, 3 navigations, and 90 seconds. Research defaults: 5 queries, 10 results/query, 8 pages, depth 3, 2 minutes. Change them in DevTools. Cancel stops a running or stuck task.
- Webpage text and search snippets are attached as data, never as instructions. Prompt sections: system (fixed), user task, browser state, `<untrusted_web_content>…</untrusted_web_content>`. Chat markers in page text are stripped. Source lists are owned by Rust; URLs the model invents are stripped.
- The chrome UI cannot pass page HTML or a URL for Q&A. Rust reads the `browser` WebView with a frozen helper when `attachPage` is true, or inspects it during an agent/research loop.
- The AI has no filesystem capability. Model files are written only by the model manager to `%LOCALAPPDATA%\…\models`. Saved pages are written only by the save-with-AI path to `%LOCALAPPDATA%\…\saved-pages.json`.
- The model cannot skip confirmation. Purchases, submit, sign-in, add to cart, password fields, and login/checkout URLs wait for `ai_confirm`.
- CAPTCHA / bot-block pages are skipped. PicoSurf does not solve or bypass them.

Opening the sidebar does not start inference. Loading a model does.

## Model management (Phase 3)

Built-in catalogue only. Pages cannot install models. The chrome UI cannot pass a URL; Rust fetches only catalogue HTTPS hosts (`huggingface.co` / `hf.co`).

Each entry: id, name, family, parameters, quantization, URL, size, SHA-256, RAM hint, platform.

Download in Rust, verify SHA-256, delete on mismatch. Never bundle weights in the installer. Confirm before every download.

Hardware probe (RAM, CPU cores, free storage) is used to label a recommended catalogue entry. The 7B model is never fetched unless the user confirms.

## Browser action broker (Phase 2)

Structured actions from chrome only: inspect, page info, click, type, scroll, screenshot (metrics).

The UI and (later) the AI receive element IDs, not CSS selectors or JavaScript. Each inspect bumps a generation. Rust rejects:

- unknown IDs
- IDs from a previous generation
- origin changes since inspect
- type-into on non-text controls

Dangerous clicks (submit, file, add to cart, buy now, checkout, sign in, and similar) return `needsConfirmation: true` and do not run until chrome sends `confirmed: true`.

Navigation invalidates the element map. Frozen helper scripts live in `src-tauri/src/browser/`; callers cannot supply script.

## Security policy

- Least privilege Tauri capabilities.
- Untrusted WebView has no IPC allowlist.
- LLM output is untrusted input and must match a schema.
- Agent limits: max 8 actions, max 3 navigations, 90 second timeout. Research: max 5 queries, 8 pages, 2 minutes.
- No telemetry, analytics, or accounts.

## Windows architecture

- UI: WebView2 (Evergreen system runtime).
- Portable exe is the primary distribution. Per-user NSIS is optional and must not require Administrator.
- Data: `%LOCALAPPDATA%\PicoSurf` (or a `Data` folder next to the exe if a portable marker is added later).
- Startup: if WebView2 is missing, show a native dialog (the React UI cannot run yet). Offer Microsoft’s installer (per-user, no admin) and, if present, a Fixed Runtime folder next to the exe via `WEBVIEW2_BROWSER_EXECUTABLE_FOLDER`.
- Do not assume Windows-only paths in shared logic; isolate them under `src-tauri/src/platform/`.

## Android architecture (later)

Same Rust modules and the same trust split. Android will need a platform browser controller because Tauri `eval` / child-webview APIs differ and RAM is tighter. Inference must be unloadable. Not implemented yet.

## Phase map

1. Done — Windows shell, two WebViews, navigation, optional AI chrome, WebView2 check.
2. Done — Structured page inspection and click/type/scroll with Rust validation.
3. Done — llama.cpp, GGUF download, checksums, local streaming chat (no page context).
4. Done — Sidebar summarization / page Q&A with prompt isolation.
5. Done — Bounded agent loop with confirmations.
6. **Now** — Browser-native research (WebView search, local synthesis, save with AI).
7. Android.
8. Hardening and the security test cases in the product spec.
