# PicoSurf Android — build specification (Browse + Research)

**Purpose:** Hand this document to an implementer (human or AI) to build an Android version of PicoSurf using a **single Play listing**, **Browse | Research** modes, **Play Feature Delivery** for the research/LLM runtime, and **in-app HTTPS download** for GGUF models.

**Status:** In progress — `apps/picosurf-android/` has Browse + Research pipeline, models, report UI; Play dynamic-feature Gradle skeleton pending merge after `tauri android init`. Desktop root unchanged.

**Desktop reference:** Windows PicoSurf (`ARCHITECTURE.md`, `README.md`). Reuse Rust research stack where possible; do **not** port agent/custom flows to Android v1.

---

## 1. Product summary

### 1.1 One app, two modes

| Mode | Default? | User sees | AI / models |
|------|----------|-----------|-------------|
| **Browse** | Yes (first launch) | Normal lightweight browser (address bar, back/forward, page content) | **None** — no llama, no research pipeline loaded |
| **Research** | Opt-in | Question-first UI → progress → **local report** (summary, lists, tables, citations) | Requires **Play feature module** once + **user-chosen GGUF** download |

Mode switch: prominent toggle (e.g. bottom nav or home **Browse | Research**), persisted in settings. Copy must explain that Research uses the web for sources but summarizes **on device**.

### 1.2 Explicitly out of scope (Android v1)

- **Agent mode** (multi-step click/type/replan loop)
- **Custom agent flows** (DevTools pipelines)
- **Auto** assistant mode routing (optional: force **Research-only** intent on Android)
- Desktop-parity **DevTools** (page inspect for agent, agent limits, agent structure levels)
- **WebView2-only** features unless reimplemented on Android WebView:
  - Network ad-block parity (`blocklist/webview2.rs`) — optional later
  - WebView2 script-dialog agent (`handle_dialog`) — not required for research-only
  - WebView2 `CapturePreview` screenshots — not required for research-only
- **Tabs** (optional v2; v1 may match desktop single-page WebView)
- **Cloud LLM**, accounts, telemetry

### 1.3 In scope (Android v1)

- Private **Browse** mode (HTTPS navigation, basic history/downloads optional)
- **Research** mode matching desktop **research pipeline** conceptually:
  - User goal → local plan → **configured search engine** (URL template, no search API) → open N result pages → extract visible text → **local LLM** synthesize → show report with **cited sources actually visited**
- **Local GGUF** via llama.cpp (in **feature module**), catalogue + download + SHA-256 verify (reuse `models/` Rust where possible)
- **Research limits** (max queries, pages, runtime, extract size) — reuse `ResearchLimits` / settings patterns
- Prefix `?` / `search:` on input to force normal search in Browse mode (if omnibox shared)

---

## 2. Delivery architecture (Play + models)

### 2.1 Three-layer install model

```
┌─────────────────────────────────────────────────────────────┐
│  BASE MODULE (Play install — small)                          │
│  • Browse UI + chrome WebView (Tauri)                        │
│  • Mode toggle, settings shell, privacy copy                 │
│  • IPC stubs / feature-gated calls to research               │
│  • NO llama native libs, NO research UI routes               │
└─────────────────────────────────────────────────────────────┘
                              │
         User enables Research │  Play Feature Delivery (once)
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  DYNAMIC FEATURE MODULE e.g. `research` or `local_ai`        │
│  • Research UI (question, progress, report viewer)           │
│  • Rust: research/, search/, extract, synthesis paths        │
│  • llama.cpp + JNI / linked native inference (.so arm64-v8a) │
│  • Hidden or minimal WebView used only for fetch + extract   │
└─────────────────────────────────────────────────────────────┘
                              │
         User picks model      │  In-app download (HTTPS)
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  APP PRIVATE STORAGE — models/*.gguf                         │
│  • Same catalogue semantics as desktop (featured / more)     │
│  • SHA-256 + sizeBytes verification                          │
│  • User can delete; not bundled in AAB/feature               │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Why this split

| Asset | Delivery | Reason |
|-------|----------|--------|
| Research code + llama **runtime** | **Play Feature Delivery** | Play-signed, version-locked to app, one-time opt-in UX |
| **GGUF weights** | **In-app download** | Large, user choice, rev independent of Play module size caps |
| Browser shell | **Base module** | Minimal initial download; no AI by default |

### 2.3 Play Feature Delivery (requirements)

- Ship **Android App Bundle (`.aab`)** to Play Console.
- Gradle: **`com.android.dynamic-feature`** module depending on `:app` base.
- **On-demand** delivery (not install-time required) for the research feature.
- Before `SplitInstallManager` / Play Feature Delivery API request:
  - In-app explainer: size estimate, Wi‑Fi recommendation, “includes on-device AI; web used for sources only.”
- Handle states: downloading, failed (retry), completed, insufficient storage.
- After install, feature code and native libs load from feature module context (verify Tauri 2 Android docs for dynamic features — may require custom Gradle wiring).

### 2.4 In-app model download (requirements)

- Reuse desktop rules: HTTPS allowlist (e.g. Hugging Face), `sha256`, `sizeBytes`, app-local `models/` directory.
- Optional `models.config` / env override — same discovery order as desktop where practical.
- Browse mode must work **without any model file present**.
- Research mode: if feature installed but no model loaded → prompt **Download & Load** (reuse `ModelSelect` patterns simplified for mobile).

### 2.5 Version compatibility

- Feature module and base share **one `versionCode` / AAB release**.
- Manifest inside feature or remote **`expansion_manifest.json`** (optional) should declare:
  - `minAppVersion`
  - `inferenceAbi` (e.g. `arm64-v8a`)
  - `llamaRuntimeVersion` (for breaking native ABI changes)
- GGUF catalogue entries remain independent; app rejects load if runtime incompatible.

### 2.6 Non-Play builds (optional later)

- Sideload / F-Droid may need **monolithic APK** or documented manual install of feature — out of v1 unless requested.
- Do **not** use “download `.so` from GitHub” as primary Play user path (see downsides in product discussions).

---

## 3. Research behavior (functional spec)

Align with desktop `research::run` → `research_web` (see `src-tauri/src/research/`).

### 3.1 User flow (Research mode)

1. User enters goal (natural language) in Research home.
2. Preconditions:
   - Research **feature module** installed (else trigger Play download).
   - **Model loaded** (else model picker + download).
   - **AI enabled** in settings (default on for Research mode).
3. Show **progress phases** (emit events to UI): planning → searching → visiting pages → synthesizing → done.
4. Pipeline (high level):
   - Plan queries locally (`RESEARCH_PLAN_PROMPT` / playbook — reuse Rust).
   - Navigate **research WebView** to search engine URL (settings: engine + template `{query}`).
   - Parse/extract search results (platform-specific parser if needed — desktop has DuckDuckGo/Google helpers).
   - Open up to `maxPages` allowed URLs; extract visible text (`extract.js` / read paths — reuse JS where WebView allows `evaluateJavascript`).
   - Synthesize with local LLM; citations only from pages actually opened (Rust-owned source list).
5. **Present report** to user:
   - Prefer in-app report view (WebView loading `picosurf-research://` or inline HTML like desktop `picosurf-research` custom protocol).
   - Mobile-friendly layout: summary, numbered lists, comparison tables, **tap source** → open URL in Browse mode or external browser.
6. **No** visible “user browses SERP manually” requirement — WebView may be hidden with status text (“Reading source 2/5…”).

### 3.2 Browse mode user flow

1. Address bar / URL + search (configured engine for non-URL input).
2. Standard navigation, back/forward, reload.
3. Optional: history, downloads (parity with desktop if low cost).
4. No research report host in main view unless user switches mode.
5. Toggling to Research: if feature missing → Play download flow.

### 3.3 Intent / routing (Android)

- **Browse:** `classify` / omnibox → navigate or search only; **do not** invoke `research::run`.
- **Research:** all AI tasks go to research pipeline; **ignore** agent `Intent::PageTask` paths.
- Desktop `AssistantMode` enum may be fixed to `Research` on Android or hidden in UI.

### 3.4 WebView strategy

**Option A (recommended for v1):** Two logical roles, possibly one physical WebView:

- **Browse WebView:** visible page content.
- **Research fetch WebView:** off-screen or reused instance for search/results/article fetch; must not leak cookies into Browse optionally (separate data directory if feasible).

**Option B:** Single WebView — switching modes saves/restores URL; simpler but muddier UX when research replaces visible page. Document choice in implementation notes.

Extract: port `src-tauri/src/browser/extract.js` and `read.js` for `evaluateJavascript` on Android WebView.

---

## 4. UI / UX specification

### 4.1 Navigation shell

- **Browse tab:** toolbar (back, forward, reload), address bar, optional menu (settings, privacy).
- **Research tab:** goal input, recent reports optional, model status chip (“Model: none” / name).
- **Settings:** search engine, research limits, privacy, clear data, “Manage downloaded models”, “Research module installed: yes/no”.

### 4.2 First-time Research enablement

1. User taps Research tab or toggle.
2. Modal: explains local AI + web sources + one-time download size (**fetch from Play** or static estimate).
3. User confirms → Play Feature Delivery starts.
4. On success → Research home; if no model → model onboarding.

### 4.3 Report UI

- Title, objective, body (markdown/HTML).
- Sources list with domain + title; tap opens link.
- Actions: **Share** export (text/HTML file), **Open in Browse** (optional), **New research**.
- Do not show raw SERP unless debug build.

### 4.4 Empty / error states

- No network → clear message (research requires internet for sources).
- CAPTCHA / blocked site → report notes thin evidence (reuse desktop `looks_blocked` ideas).
- Feature download failed → stay in Browse, retry button.
- Model download failed → checksum / size error from Rust.

### 4.5 Branding

- Same PicoSurf identity; Play listing title e.g. **“PicoSurf — Private browser & local research”**.
- Short description: browser free; optional on-device research add-on.

---

## 5. Code reuse map (desktop → Android)

### 5.1 Reuse with minimal changes (target)

| Rust module | Use on Android |
|-------------|----------------|
| `research/` | Core pipeline |
| `search/` | URL build + result parsing (test per engine on WebView) |
| `security/` | URL allowlists, research id validation |
| `settings/` | `ResearchLimits`, search settings (subset) |
| `models/` | Catalogue, download, verify, load |
| `ai/llama.rs`, `ai/prompt.rs` | Inference + research prompts (not agent prompts) |
| `storage/` | App data paths via Tauri Android paths |
| `saved/` | Optional v2 |

### 5.2 Feature-module only (gate from base)

- `ai/agent.rs`, `ai/task_plan.rs`, `ai/schema.rs` (agent actions) — **exclude** or stub in base APK.
- `agent_flows/` — **exclude**
- Research UI routes + commands: `ai_task` research path only, `ai_generate` for chat optional v2.

### 5.3 Reimplement / platform layer

| Area | Desktop | Android |
|------|---------|---------|
| Shell | Win32 + 2 WebViews | Tauri Android + layout |
| Ad block | WebView2 filter | Defer |
| Dialog agent | WebView2 COM | Defer |
| Screenshot | WebView2 capture | Defer |
| WebView2 bootstrap | `platform/windows.rs` | N/A |
| Hardware RAM hints | `platform/hardware.rs` | Android API for RAM → model fit |
| Research report protocol | `picosurf-research` localhost | Custom scheme or file URL in WebView |

### 5.4 Frontend (React)

- Reuse components where possible: `ModelSelect`, research-related copy, privacy panel.
- **New:** mobile layout, mode tabs, Research home, progress view, report reader.
- **Remove/hide:** `AssistantModeSelect` agent/custom/auto, DevTools agent panels, `Allow page actions`, agent structure settings.
- Tauri capabilities: split **chrome** vs **browser** same as desktop (`ARCHITECTURE.md`); verify Android capability model.

---

## 6. Security & privacy (must hold)

Carry forward `ARCHITECTURE.md` trust rules:

- **Browser WebView is untrusted** — no Tauri IPC permissions on page WebView.
- Page text for research is **untrusted data** — delimited blocks in prompts; never system instructions.
- No cloud LLM; no telemetry in v1 spec.
- Play Data safety form: disclose local model, optional feature download, web access for research sources, on-device storage.
- GGUF downloads: HTTPS + hash only; warn on user-provided URLs if ever enabled.
- Research reports stored locally under app data; optional clear in settings.

---

## 7. Gradle / project structure (target)

```
picosurf/
  src-tauri/                    # existing Rust + Tauri
  src/                          # React — add mobile layouts + mode routing
  android/                      # Tauri-generated + customized
    app/                        # BASE MODULE
      build.gradle.kts
    research_feature/           # DYNAMIC FEATURE MODULE (name TBD)
      build.gradle.kts
      src/main/                 # feature entry, optional Android-specific glue
  docs/
    ANDROID-RESEARCH-BUILD-SPEC.md  # this file
```

Implementation tasks:

1. Confirm **Tauri 2 Android** supports dynamic feature modules or document workaround.
2. Move llama build artifacts to **feature module** ABI splits (`arm64-v8a` minimum).
3. Conditional compilation: `#[cfg(feature = "research")]` or separate crate `picosurf-research` linked only in feature module if needed.
4. Base APK must **not** link llama (avoid loading native code until feature installed).

---

## 8. IPC / commands (Android v1 surface)

**Base (always available):**

- Browser navigate, back, forward, reload, state
- Settings get/set (browse subset)
- History/downloads if shipped
- `research_feature_status` — installed / downloading / not installed
- `research_feature_request_install` — triggers Play delivery

**Feature module (after install):**

- `ai_task` → research only
- `models_list`, `models_download`, `models_load`, `models_unload`, …
- Research limits get/set
- `omnibox_interpret` → research/summarize/save subset **without** page-task/agent

**Remove or no-op on Android:**

- `ai_confirm` (agent confirmation)
- Agent flows CRUD
- `browser_inspect` for agent (optional debug only)
- Clean view optional

---

## 9. Performance & limits (mobile defaults)

Suggest conservative defaults (tunable in settings):

| Setting | Suggested mobile default | Desktop ref |
|---------|--------------------------|-------------|
| `maxQueries` | 3 | 5 |
| `maxPages` | 4–6 | 8 |
| `maxRuntimeSecs` | 90–120 | 120 |
| `maxExtractChars` | 1200–1800 | 1800 |
| Model RAM | Catalogue marks `minRamBytes`; filter “fits this device” | same |

Thermal / battery: show warning on long research; allow cancel (`ai_stop`).

---

## 10. Testing checklist

- [ ] Fresh install: Browse works, no native llama in base APK (verify APK Analyzer / no load before feature).
- [ ] Enable Research: Play module downloads; failure/retry paths.
- [ ] Model download: verify SHA failure, resume, delete model.
- [ ] End-to-end research: goal → search → 2+ sources → report with citations.
- [ ] Airplane mode: Browse OK; Research fails gracefully at start or fetch.
- [ ] Rotate / background: cancel or resume policy documented.
- [ ] Low storage: feature + model download errors.
- [ ] WebView: DDG/Google search extractors on real device.
- [ ] Security: browser WebView cannot invoke Tauri commands.

---

## 11. Play Console & release

- **Category:** Tools or Productivity.
- **Content rating:** questionnaire with user-generated web content + optional AI.
- **Privacy policy URL:** cover local processing + web fetches for research.
- **Screenshots:** Browse mode + Research report (not agent).
- **App size:** highlight small initial install; disclose optional module + model downloads.

---

## 12. Implementation phases (suggested order)

### Phase 0 — Spike

- Tauri Android hello-world on device/emulator.
- Single WebView navigate + `evaluateJavascript` running `extract.js` snippet.
- llama.cpp builds for `aarch64-linux-android` (or via Tauri mobile toolchain).

### Phase 1 — Browse-only base

- Mode shell with Browse functional; Research tab shows “Install research pack”.
- Ship base AAB to internal testing track.

### Phase 2 — Play Feature + research pipeline

- Dynamic feature module with research Rust + hidden WebView fetch.
- Report rendering; no model yet → mock or skip synthesize.

### Phase 3 — Models + full research

- Model catalogue UI + download + load in feature module.
- Full synthesis; parity test against desktop sample goals.

### Phase 4 — Polish

- History, share report, RAM-aware model list, help/privacy copy, store listing.

---

## 13. Open decisions (resolve before coding)

| # | Question | Notes |
|---|----------|-------|
| 1 | Tauri 2 + dynamic feature official path? | Read current Tauri mobile docs; may need native Gradle fork. |
| 2 | One WebView vs two for Browse/Research fetch? | Affects cookies and memory. |
| 3 | Report renderer: WebView HTML vs native Compose/React Native WebView? | Reuse desktop HTML report for speed. |
| 4 | Keep `ai_generate` chat in Browse v1? | Spec says research focus; chat optional. |
| 5 | Minimum Android version / ABI | Recommend API 26+, **arm64-v8a** only for v1. |
| 6 | Ad block in Browse v1? | Defer unless easy WebViewClient hook. |

---

## 14. Sample acceptance goals (QA strings)

Use these in Research mode with a small loaded model:

1. “Find the top 3 privacy-focused browsers and compare them.”
2. “What are recent reviews saying about local LLM inference on phones?”
3. “Compare renewable energy adoption in UAE vs Saudi Arabia.” (region-aware planning)

Expect: local report, numbered sections, source list with domains, no agent clicks, no cloud API.

---

## 15. References in this repo

| Path | Relevance |
|------|-----------|
| `ARCHITECTURE.md` | Trust boundaries, capabilities, research overview |
| `README.md` | Product wording, build requirements (Windows today) |
| `src-tauri/src/research/` | Research pipeline implementation |
| `src-tauri/src/models/` | Model download + verify |
| `src-tauri/src/search/` | Search URL + parsing |
| `src-tauri/src/browser/extract.js` | Visible text + element harvest |
| `src-tauri/src/settings.rs` | `ResearchLimits`, search settings |
| `src/components/AssistantModeSelect.tsx` | **Do not port** agent/custom/auto to Android v1 |

---

## 16. Instruction for future implementer

When building from this spec:

1. Read `ARCHITECTURE.md` and preserve **chrome vs browser** trust separation on Android.
2. Implement **base Browse first**, then **Play dynamic feature** for research + llama, then **model downloads**.
3. Do **not** port agent loop, custom flows, or WebView2-only agent features unless explicitly added to a later spec revision.
4. Prefer **reusing Rust research/models/search** over rewriting pipeline in Kotlin.
5. Update this document’s **Status** section and **Open decisions** as choices are made.

---

*Document version: 1.0 — PicoSurf Android Browse + Research (Play Feature + in-app models).*
