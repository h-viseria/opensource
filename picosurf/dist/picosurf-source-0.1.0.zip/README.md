# PicoSurf

**Browse freely. Think locally.**

A lightweight, privacy-first browser with a local AI that helps you search, explore, understand and remember the web.

- **No cloud AI required** — models run on your device with llama.cpp
- **No AI API key** — download a catalogue model once, use it locally
- **No per-query token bill**
- **No giant browser engine bundled** — uses the system WebView2 runtime

Just a small browser with a brain of its own.

## Homepage

Marketing site (static HTML, PicoERP design tokens):

```bash
cd C:\projects\picosurf\homepage
python -m http.server 8766 --bind 127.0.0.1
```

Open `http://127.0.0.1:8766` (requires the sibling [`erp`](../erp) repo for CSS at `../erp/css/`).

On GitHub Pages: `https://picoai.org/picosurf/`

## What it does

Tell PicoSurf what you're looking for:

- *"Find the top 5 milk brands in UAE and compare them."*
- *"Find five good research papers about local LLM inference."*
- *"Open this page and summarize it."*

PicoSurf can search, navigate, extract, compare and summarize using local AI and the browser itself. The browser remains the tool; AI makes it smarter.

**Your data stays local.** History, downloads metadata, saved pages, and AI context are stored on this device. Websites cannot read them.

Part of the **PicoAI** philosophy: *Small software. Local intelligence. Private by default.*

## Requirements

- Windows 10 or 11
- WebView2 (preinstalled on Windows 11; PicoSurf prompts if it is missing)
- Node.js 20+
- Rust stable with the MSVC toolchain (`rustup`)
- Visual Studio 2022/2026 Build Tools with the "Desktop development with C++" workload
- LLVM (for llama.cpp bindgen). `scripts\dev.ps1` looks for `C:\Program Files\LLVM\bin`. Install with `winget install LLVM.LLVM` if missing.

If `rustup` fails while renaming `ld.lld.exe`, Windows Defender is usually quarantining the linker. Add an exclusion for `%USERPROFILE%\.rustup` and `%USERPROFILE%\.cargo`, then run `rustup-init` again.

## Run

Use the helpers so the Visual Studio linker, CMake, and libclang are on PATH:

```powershell
cd C:\projects\picosurf
powershell -ExecutionPolicy Bypass -File .\scripts\dev.ps1
```

Release exe (first llama.cpp compile can take many minutes; cargo prints the cmake command in red, that is not a failure). Close any other PicoSurf `tauri`/`cargo` process first so MSBuild is not writing the same files:

```powershell
cd C:\projects\picosurf
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
```

If that script says the C++ compiler is missing, open **Visual Studio Installer**, modify **Build Tools 2026**, enable **Desktop development with C++** (MSVC tools + Windows SDK), wait until the install is complete, then run the script again.

Do not use a normal PowerShell window for `npm run tauri dev` or `npm run tauri build`. Without this environment Cargo fails with `linker link.exe not found` or `is cmake not installed?`, which can look like a crash because of the red error dump.

The raw exe from `src-tauri/target/release/picosurf.exe` can be copied and run without an installer. It does not need Administrator. Models are not bundled.

## Stack

- **UI:** React + TypeScript (chrome WebView only)
- **Shell:** Tauri 2 + Rust
- **Browser:** System WebView2 (separate untrusted WebView)
- **AI:** llama.cpp in-process, GGUF models downloaded over HTTPS with SHA-256 verification
- **No** Ollama, Python runtime, cloud LLM, or bundled Chromium

## Source bundle (offline copy)

To ship source without `node_modules`, `target/`, or other generated folders:

```powershell
python scripts\pack_source.py all
```

This writes `releases\picosurf-source-<version>.zip` and `releases\picosurf-source-installer.py`.
Copy **both** to the target machine (or run `python scripts\pack_source.py all --embed` for a single self-contained `.py`).

On another machine:

```powershell
python picosurf-source-installer.py C:\build\picosurf
cd C:\build\picosurf
npm ci
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
```

## Layout

See `ARCHITECTURE.md` for trust boundaries and IPC. The chrome UI and the visited page are separate WebViews. Pages cannot call Tauri commands.

## License

To be chosen when publishing to GitHub.
