# Run PicoSurf in a shell that can see the MSVC linker, CMake, and libclang.
# Usage: powershell -ExecutionPolicy Bypass -File scripts\dev.ps1

$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
. (Join-Path $PSScriptRoot "env.ps1")
npm run tauri dev
