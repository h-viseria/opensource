# Load MSVC, CMake, and libclang into this PowerShell session.
# Used by scripts\dev.ps1 and scripts\build.ps1.

$ErrorActionPreference = "Stop"

$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path $vswhere)) {
  Write-Host "Visual Studio Installer was not found. Install Build Tools from https://visualstudio.microsoft.com/visual-cpp-build-tools/"
  exit 1
}

$vsPath = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $vsPath) {
  $vsPath = & $vswhere -latest -products * -property installationPath
}

$vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvars64.bat"
if (-not (Test-Path $vcvars)) {
  Write-Host @"
Visual Studio Build Tools is installed, but the C++ compiler is missing (no link.exe / vcvars64.bat).

PowerShell is not crashing. Cargo cannot find the MSVC linker.

Fix:
1. Open Visual Studio Installer
2. Modify 'Visual Studio Build Tools 2026'
3. Check 'Desktop development with C++'
4. On the right, keep:
   - MSVC v143/v145 C++ x64/x86 build tools
   - Windows 10/11 SDK
5. Click Modify and wait until it finishes (status must be complete)
6. Close and reopen this terminal, then run this script again
"@
  $installer = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\setup.exe"
  if (Test-Path $installer) {
    Start-Process $installer
    Write-Host "Opened Visual Studio Installer."
  }
  exit 1
}

Write-Host "Loading MSVC environment from $vcvars"
cmd /c "`"$vcvars`" >nul && set" | ForEach-Object {
  if ($_ -match "^(.*?)=(.*)$") {
    Set-Item -Path "Env:$($matches[1])" -Value $matches[2]
  }
}

if (-not (Get-Command link.exe -ErrorAction SilentlyContinue)) {
  Write-Host "vcvars ran, but link.exe is still not on PATH. Re-run Visual Studio Installer and finish the C++ workload."
  exit 1
}

Write-Host "link.exe: $((Get-Command link.exe).Source)"

# vcvars does not put Visual Studio's CMake/Ninja on PATH. llama-cpp-sys-2 needs both.
$cmakeCandidates = @(
  (Join-Path $vsPath "Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin"),
  "C:\Program Files\CMake\bin",
  "C:\Program Files (x86)\CMake\bin"
)
$cmakeBin = $cmakeCandidates | Where-Object { Test-Path (Join-Path $_ "cmake.exe") } | Select-Object -First 1
if ($cmakeBin) {
  $env:PATH = "$cmakeBin;$env:PATH"
  $env:CMAKE = Join-Path $cmakeBin "cmake.exe"
  Write-Host "cmake: $env:CMAKE"
} elseif (-not (Get-Command cmake.exe -ErrorAction SilentlyContinue)) {
  Write-Host "cmake.exe was not found. Open Visual Studio Installer, modify Build Tools, and enable the C++ CMake tools component."
  exit 1
}

# Visual Studio's MSBuild MultiToolTask races on .tlog files when compiling llama.cpp
# (`MSB4018` / "CL.*.write.*.tlog ... used by another process"). Ninja avoids that.
$ninjaCandidates = @(
  (Join-Path $vsPath "Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja"),
  "C:\Program Files\Ninja",
  "C:\Program Files\CMake\bin"
)
$ninjaBin = $ninjaCandidates | Where-Object { Test-Path (Join-Path $_ "ninja.exe") } | Select-Object -First 1
if ($ninjaBin) {
  $env:PATH = "$ninjaBin;$env:PATH"
  $env:CMAKE_GENERATOR = "Ninja"
  $env:MSBUILDDISABLENODEREUSE = "1"
  # cmake-rs injects both Release and Debug MSVC flags; Ninja try_compile then fails in rc.exe.
  $env:CMAKE_TRY_COMPILE_TARGET_TYPE = "STATIC_LIBRARY"
  Write-Host "ninja: $(Join-Path $ninjaBin 'ninja.exe')"
} else {
  Write-Host "ninja.exe was not found; llama.cpp may hit MSBuild file-lock errors under Visual Studio 2026."
}

function Clear-LlamaCppVisualStudioCache {
  $roots = @(
    (Join-Path (Get-Location) "src-tauri\target\release\build"),
    (Join-Path (Get-Location) "src-tauri\target\debug\build")
  )
  foreach ($root in $roots) {
    if (-not (Test-Path $root)) { continue }
    Get-ChildItem $root -Directory -Filter "llama-cpp-sys-2-*" -ErrorAction SilentlyContinue | ForEach-Object {
      $cache = Join-Path $_.FullName "out\build\CMakeCache.txt"
      if (-not (Test-Path $cache)) { return }
      $text = Get-Content $cache -Raw -ErrorAction SilentlyContinue
      if ($text -match "(?m)^CMAKE_GENERATOR:INTERNAL=Visual Studio") {
        Write-Host "Removing Visual Studio cmake output so Ninja can reconfigure: $($_.FullName)"
        Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
      }
    }
  }
}

Clear-LlamaCppVisualStudioCache

$llvmCandidates = @(
  "C:\Program Files\LLVM\bin",
  (Join-Path $env:USERPROFILE ".local\llvm\bin")
)
$llvmBin = $llvmCandidates | Where-Object { Test-Path (Join-Path $_ "libclang.dll") } | Select-Object -First 1
if ($llvmBin) {
  $env:PATH = "$llvmBin;$env:PATH"
  $env:LIBCLANG_PATH = $llvmBin
  Write-Host "libclang: $llvmBin"
} elseif (-not $env:LIBCLANG_PATH) {
  Write-Host "LLVM/clang was not found. Phase 3 needs libclang to compile llama.cpp."
  Write-Host "Install LLVM (approve the UAC prompt): winget install LLVM.LLVM"
  exit 1
}
