# Release-build PicoSurf with the MSVC linker, CMake, and libclang on PATH.
# Usage: powershell -ExecutionPolicy Bypass -File scripts\build.ps1
#
# Do not run `npm run tauri build` in a plain PowerShell window. Cargo will fail
# with `is cmake not installed?` even though Visual Studio already has cmake.exe.
# Close any other PicoSurf cargo/tauri build before running this.

$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
. (Join-Path $PSScriptRoot "env.ps1")
npm run tauri build
