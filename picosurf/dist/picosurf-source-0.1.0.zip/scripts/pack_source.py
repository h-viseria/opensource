#!/usr/bin/env python3
"""
Pack PicoSurf source (no node_modules, target/, dist/, models/, etc.) into a zip and/or
a single-file installer script.

Usage (from repo root or anywhere):

  python scripts/pack_source.py pack
  python scripts/pack_source.py installer
  python scripts/pack_source.py all

  python releases/picosurf-source-installer.py C:\\build\\picosurf
  (Keep picosurf-source-<version>.zip next to the installer, or use --embed for one file.)

After extract:

  cd C:\\build\\picosurf
  powershell -ExecutionPolicy Bypass -File .\\scripts\\build.ps1

Requires: Python 3.9+ (stdlib only). Git optional but recommended for accurate file lists.
"""

from __future__ import annotations

import argparse
import base64
import fnmatch
import json
import os
import subprocess
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

# Safety net if Git is unavailable (matches root .gitignore intent).
EXTRA_SKIP_FILES = frozenset({"build-err.txt", "build-out.txt"})

ALWAYS_SKIP_DIR_NAMES = frozenset(
    {
        "node_modules",
        "target",
        "dist",
        "dist-ssr",
        "models",
        "webview2",
        "gen",
        "WixTools",
        "nsis",
        "releases",
        ".git",
        "__pycache__",
        ".idea",
        "logs",
    }
)

INSTALLER_TEMPLATE = r'''#!/usr/bin/env python3
"""PicoSurf source installer — extracts a full source tree (no third-party caches).

Usage:
  python picosurf-source-installer.py <destination_folder> [--zip path/to/archive.zip]

Keep {{ZIP_BASENAME}} in the same folder as this script, or pass --zip explicitly.

Example:
  python picosurf-source-installer.py C:/build/picosurf

Then build:
  cd C:/build/picosurf
  npm ci
  powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1

See README.md in the extracted folder for prerequisites (Node, Rust, VS C++ tools, LLVM).
"""

from __future__ import annotations

import argparse
import base64
import io
import sys
import zipfile
from pathlib import Path

DEFAULT_ZIP_NAME = "{{ZIP_BASENAME}}"
{{EMBED_BLOCK}}


def resolve_archive(installer: Path, zip_arg: str | None) -> Path:
    if zip_arg:
        path = Path(zip_arg).expanduser().resolve()
        if not path.is_file():
            raise SystemExit(f"Zip not found: {path}")
        return path
    if EMBEDDED_ZIP_B64:
        return Path()  # sentinel: use embedded bytes
    for candidate in (
        installer.parent / DEFAULT_ZIP_NAME,
        installer.with_suffix(".zip"),
    ):
        if candidate.is_file():
            return candidate
    raise SystemExit(
        f"Source zip not found. Place {DEFAULT_ZIP_NAME} next to this script,\n"
        f"or run: python {installer.name} <dest> --zip path/to/{DEFAULT_ZIP_NAME}"
    )


def read_zip_bytes(archive: Path, installer: Path) -> bytes:
    if EMBEDDED_ZIP_B64:
        return base64.b64decode(EMBEDDED_ZIP_B64)
    return archive.read_bytes()


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract PicoSurf source tree.")
    parser.add_argument("destination", help="Empty or new folder for the source tree")
    parser.add_argument("--zip", dest="zip_path", help="Path to picosurf-source zip")
    args = parser.parse_args()

    dest = Path(args.destination).expanduser()
    try:
        dest = dest.resolve()
    except OSError:
        dest = dest.absolute()

    installer = Path(__file__).resolve()
    archive = resolve_archive(installer, args.zip_path)
    payload = read_zip_bytes(archive, installer)

    if dest.exists():
        if not dest.is_dir():
            raise SystemExit(f"Destination exists and is not a folder: {dest}")
        if any(dest.iterdir()):
            raise SystemExit(
                f"Destination folder is not empty: {dest}\n"
                "Choose an empty folder or a new path."
            )
    else:
        dest.mkdir(parents=True, exist_ok=True)

    print(f"Extracting to {dest} …")
    with zipfile.ZipFile(io.BytesIO(payload), "r") as zf:
        zf.extractall(dest)

    build_script = dest / "scripts" / "build.ps1"
    if not build_script.is_file():
        raise SystemExit(
            f"Extract finished but {build_script} is missing — archive may be corrupt."
        )

    print("Done.")
    print()
    print("Next steps:")
    print(f"  cd {dest}")
    print(r"  npm ci")
    print(r"  powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1")


if __name__ == "__main__":
    main()
'''


@dataclass
class IgnoreRules:
    dir_exact: set[str] = field(default_factory=set)
    dir_prefix: list[str] = field(default_factory=list)
    file_globs: list[str] = field(default_factory=list)
    path_globs: list[str] = field(default_factory=list)

    def load_gitignore(self, path: Path, prefix: str = "") -> None:
        if not path.is_file():
            return
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("!"):
                continue
            pattern = line.replace("\\", "/")
            if prefix:
                pattern = f"{prefix.rstrip('/')}/{pattern.lstrip('/')}"

            if pattern.endswith("/"):
                self.dir_prefix.append(pattern.rstrip("/"))
                continue
            if "/" in pattern:
                self.path_globs.append(pattern)
            elif "*" in pattern or "?" in pattern:
                self.file_globs.append(pattern)
            else:
                self.dir_exact.add(pattern)

    def ignored(self, rel_posix: str) -> bool:
        rp = rel_posix.replace("\\", "/").lstrip("./")
        parts = rp.split("/")
        for part in parts:
            if part in ALWAYS_SKIP_DIR_NAMES:
                return True
        if parts and parts[0] in self.dir_exact:
            return True
        for prefix in self.dir_prefix:
            if rp == prefix or rp.startswith(prefix + "/"):
                return True
        base = parts[-1] if parts else rp
        for glob in self.file_globs:
            if fnmatch.fnmatch(base, glob):
                return True
        for glob in self.path_globs:
            if fnmatch.fnmatch(rp, glob):
                return True
        if base.startswith("Microsoft.WebView2.FixedVersionRuntime"):
            return True
        if base == ".DS_Store" or base in ("Thumbs.db", "Desktop.ini"):
            return True
        return False


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_version(root: Path) -> str:
    pkg = root / "package.json"
    if pkg.is_file():
        try:
            data = json.loads(pkg.read_text(encoding="utf-8"))
            version = data.get("version")
            if isinstance(version, str) and version:
                return version
        except json.JSONDecodeError:
            pass
    return "0.0.0"


def load_ignore_rules(root: Path) -> IgnoreRules:
    rules = IgnoreRules()
    rules.load_gitignore(root / ".gitignore")
    rules.load_gitignore(root / "src-tauri" / ".gitignore", prefix="src-tauri")
    rules.dir_prefix.extend(
        [
            "releases",
            ".vscode",
        ]
    )
    rules.file_globs.extend(["*.local", "*.log", "npm-debug.log*"])
    return rules


def git_list_files(root: Path) -> list[str] | None:
    if not (root / ".git").is_dir():
        return None
    probe = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        cwd=root,
        capture_output=True,
        text=True,
    )
    if probe.returncode != 0:
        return None
    result = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        cwd=root,
        capture_output=True,
    )
    if result.returncode != 0:
        return None
    raw = result.stdout
    if not raw:
        return []
    return [p.decode("utf-8", errors="surrogateescape") for p in raw.split(b"\0") if p]


def walk_files(root: Path, rules: IgnoreRules) -> list[str]:
    found: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            d
            for d in dirnames
            if d not in ALWAYS_SKIP_DIR_NAMES and not rules.ignored(
                str(Path(dirpath).relative_to(root) / d).replace("\\", "/")
            )
        ]
        for name in filenames:
            full = Path(dirpath) / name
            rel = full.relative_to(root).as_posix()
            if rules.ignored(rel):
                continue
            found.append(rel)
    found.sort()
    return found


def collect_relative_paths(root: Path, rules: IgnoreRules) -> list[str]:
    from_git = git_list_files(root)
    if from_git is not None:
        paths = [p.replace("\\", "/") for p in from_git if p]
    else:
        paths = walk_files(root, rules)

    extra_skip_prefixes = ("releases/",)
    cleaned: list[str] = []
    for rel in paths:
        if rel.startswith(extra_skip_prefixes):
            continue
        if rules.ignored(rel):
            continue
        if Path(rel).name in EXTRA_SKIP_FILES:
            continue
        full = root / rel
        if not full.is_file():
            continue
        cleaned.append(rel)
    return sorted(set(cleaned))


def create_zip(root: Path, zip_path: Path, paths: list[str], dry_run: bool) -> None:
    if dry_run:
        return

    zip_path.parent.mkdir(parents=True, exist_ok=True)
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel in paths:
            zf.write(root / rel, rel)

    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"Wrote {zip_path} ({size_mb:.2f} MiB, {len(paths)} files)")


def render_installer(zip_basename: str, embed: bool, zip_path: Path | None) -> str:
    if embed:
        if zip_path is None or not zip_path.is_file():
            raise SystemExit("--embed requires an existing zip file")
        b64 = base64.b64encode(zip_path.read_bytes()).decode("ascii")
        embed_block = f'EMBEDDED_ZIP_B64 = """{b64}"""\n'
    else:
        embed_block = 'EMBEDDED_ZIP_B64 = ""\n'
    return (
        INSTALLER_TEMPLATE.replace("{{ZIP_BASENAME}}", zip_basename).replace(
            "{{EMBED_BLOCK}}", embed_block
        )
    )


def create_installer(
    zip_path: Path,
    installer_path: Path,
    dry_run: bool,
    embed: bool = False,
) -> None:
    if dry_run:
        mode = "single-file (embedded)" if embed else "companion zip"
        print(f"Would write {installer_path} ({mode}, uses {zip_path.name})")
        return
    if not zip_path.is_file():
        raise SystemExit(f"Zip not found: {zip_path}")

    installer_path.parent.mkdir(parents=True, exist_ok=True)
    text = render_installer(zip_path.name, embed=embed, zip_path=zip_path)
    installer_path.write_text(text, encoding="utf-8", newline="\n")
    size_mb = installer_path.stat().st_size / (1024 * 1024)
    label = "embedded zip" if embed else f"uses {zip_path.name} alongside script"
    print(f"Wrote {installer_path} ({size_mb:.2f} MiB, {label})")


def cmd_pack(args: argparse.Namespace) -> None:
    root = Path(args.root).resolve()
    rules = load_ignore_rules(root)
    paths = collect_relative_paths(root, rules)
    out = Path(args.out)
    if not out.is_absolute():
        out = root / out
    if args.dry_run:
        if args.max_list:
            for rel in paths[: args.max_list]:
                print(rel)
            if len(paths) > args.max_list:
                print(f"... and {len(paths) - args.max_list} more")
        else:
            for rel in paths:
                print(rel)
        print(f"\n{len(paths)} file(s) would be archived.")
        return
    create_zip(root, out, paths, dry_run=False)


def cmd_installer(args: argparse.Namespace) -> None:
    root = Path(args.root).resolve()
    zip_path = Path(args.zip)
    if not zip_path.is_absolute():
        zip_path = root / zip_path
    out = Path(args.out)
    if not out.is_absolute():
        out = root / out
    create_installer(zip_path, out, dry_run=args.dry_run, embed=args.embed)


def cmd_all(args: argparse.Namespace) -> None:
    root = Path(args.root).resolve()
    version = read_version(root)
    rules = load_ignore_rules(root)
    paths = collect_relative_paths(root, rules)
    zip_path = root / "releases" / f"picosurf-source-{version}.zip"
    installer_path = root / "releases" / f"picosurf-source-installer.py"
    if args.out:
        zip_path = Path(args.out)
        if not zip_path.is_absolute():
            zip_path = root / zip_path
    if args.installer_out:
        installer_path = Path(args.installer_out)
        if not installer_path.is_absolute():
            installer_path = root / installer_path

    create_zip(root, zip_path, paths, dry_run=args.dry_run)
    create_installer(
        zip_path,
        installer_path,
        dry_run=args.dry_run,
        embed=args.embed,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Pack PicoSurf source for offline install.")
    parser.add_argument(
        "--root",
        default=str(repo_root()),
        help="Repository root (default: parent of scripts/)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    pack = sub.add_parser("pack", help="Create a source zip only")
    pack.add_argument(
        "--out",
        default="",
        help="Output zip path (default: releases/picosurf-source-<version>.zip)",
    )
    pack.add_argument("--dry-run", action="store_true", help="List files only, do not write zip")
    pack.add_argument("--max-list", type=int, default=0, help="With --dry-run, cap printed lines")
    pack.set_defaults(func=cmd_pack)

    inst = sub.add_parser("installer", help="Embed an existing zip into a single .py installer")
    inst.add_argument("--zip", required=True, help="Input zip from pack")
    inst.add_argument("--out", default="releases/picosurf-source-installer.py")
    inst.add_argument(
        "--embed",
        action="store_true",
        help="Embed zip as base64 in the .py file (single file to copy; ~33%% larger)",
    )
    inst.add_argument("--dry-run", action="store_true")
    inst.set_defaults(func=cmd_installer)

    all_cmd = sub.add_parser("all", help="Create zip and installer (default for release)")
    all_cmd.add_argument("--out", default="", help="Override zip output path")
    all_cmd.add_argument("--installer-out", default="", help="Override installer output path")
    all_cmd.add_argument(
        "--embed",
        action="store_true",
        help="Embed zip inside the installer script (single-file distribution)",
    )
    all_cmd.add_argument("--dry-run", action="store_true")
    all_cmd.set_defaults(func=cmd_all)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.command == "pack" and not args.out:
        root = Path(args.root).resolve()
        args.out = f"releases/picosurf-source-{read_version(root)}.zip"
    args.func(args)


if __name__ == "__main__":
    main()
