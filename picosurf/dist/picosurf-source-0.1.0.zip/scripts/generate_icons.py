"""Generate simple PicoSurf PNG and ICO icons without extra packages."""

from __future__ import annotations

import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "src-tauri" / "icons"


def png(width: int, height: int, pixels: bytes) -> bytes:
    def chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    raw = b""
    stride = width * 4
    for y in range(height):
        raw += b"\x00" + pixels[y * stride : (y + 1) * stride]
    return b"".join(
        [
            b"\x89PNG\r\n\x1a\n",
            chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)),
            chunk(b"IDAT", zlib.compress(raw, 9)),
            chunk(b"IEND", b""),
        ]
    )


def paint(size: int) -> bytes:
    pixels = bytearray(size * size * 4)
    cx = cy = size / 2
    radius = size * 0.42
    for y in range(size):
        for x in range(size):
            dx = x + 0.5 - cx
            dy = y + 0.5 - cy
            dist = (dx * dx + dy * dy) ** 0.5
            i = (y * size + x) * 4
            if dist <= radius:
                wave = 0.55 + 0.45 * ((x / size) ** 0.8)
                pixels[i] = int(45 * wave)
                pixels[i + 1] = int(160 * wave)
                pixels[i + 2] = int(140 * wave)
                pixels[i + 3] = 255
                if abs(dy - 4 * (dx / radius) ** 3 + radius * 0.12) < size * 0.06 and dist < radius * 0.78:
                    pixels[i] = 232
                    pixels[i + 1] = 244
                    pixels[i + 2] = 240
            else:
                pixels[i + 3] = 0
    return bytes(pixels)


def ico(png_bytes: bytes, size: int) -> bytes:
    header = struct.pack("<HHH", 0, 1, 1)
    entry = struct.pack("<BBBBHHII", size if size < 256 else 0, size if size < 256 else 0, 0, 0, 1, 32, len(png_bytes), 22)
    return header + entry + png_bytes


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    for size, name in ((32, "32x32.png"), (128, "128x128.png"), (256, "icon.png")):
        data = png(size, size, paint(size))
        (ROOT / name).write_bytes(data)
        if size == 256:
            (ROOT / "icon.ico").write_bytes(ico(data, size))


if __name__ == "__main__":
    main()
